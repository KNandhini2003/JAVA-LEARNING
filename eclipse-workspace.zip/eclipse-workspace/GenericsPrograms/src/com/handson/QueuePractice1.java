/*package com.handson;
import java.util.Queue;

public class QueuePractice1 {

	
	public static void main(String[] args) {

	Queue<Integer> integerQueue = new PriorityQueue();
	integerQueue.add(10);
	integerQueue.add(20);
	integerQueue.add(30);
	integerQueue.add(40);
	System.out.println("Added elements:"+integerQueue);
	System.out.println("Head Remove element"
			+ ":"+integerQueue.poll());
	System.out.println("elements:"+integerQueue);
	System.out.println("Access Peek element"
			+ ":"+integerQueue.peek());
	
	System.out.println("Check queue Status"
			+ ":"+integerQueue.isEmpty());
	
	System.out.println("Size:"+integerQueue.size());
	System.out.println("Elements:");
	System.out.println(integerQueue);
//	for(int a:integerQueue) {
//	System.out.println(a);
//	}
//	
//	Integer[] array = integerQueue.toArray
//			(new Integer[0]);
//	  
//    System.out.println("Array from integerStack:");
//    for (int element : array) {
//        System.out.println(element);
//    }
    //comparator
   
	integerQueue.clear();
	
	System.out.println("Size after "
			+ "clear:"+integerQueue.size());
	

	
	}
  
	    }
*/

//import java.util.*;
//public class QueuePractice;
//{
//	public static void main(String[] args) {
//		System.out.println("Hello World");
//		Queue<Integer> integerQueue = new PriorityQueue();
//	integerQueue.add(10);
//	integerQueue.add(20);
//	integerQueue.add(30);
//	integerQueue.add(40);
//	System.out.println("Added elements:"+integerQueue);
//	System.out.println("Head Remove element"
//			+ ":"+integerQueue.poll());
//	System.out.println("elements:"+integerQueue);
//	System.out.println("Access Peek element"
//			+ ":"+integerQueue.peek());
//	
//	System.out.println("Check queue Status"
//			+ ":"+integerQueue.isEmpty());
//	
//	System.out.println("Size:"+integerQueue.size());
//	System.out.println("Elements:");
//	System.out.println(integerQueue);
//
//   
// 
//	}
//}
