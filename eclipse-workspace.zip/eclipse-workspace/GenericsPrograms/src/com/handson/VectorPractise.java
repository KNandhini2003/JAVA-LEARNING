package com.handson;
import java.util.*;
public class VectorPractise {

	public static void main(String [] args) {
		Vector<String> flowerVector = new Vector<>();

        System.out.println("Adding Elements:");
        flowerVector.add("Rose");
        flowerVector.add("Lily");
        flowerVector.add("Tulip");
        flowerVector.add("Lily");
        flowerVector.add("Daisy");
        System.out.println("Initial flowerVector: " + flowerVector);
		System.out.println("Remove 2 pos:"+ flowerVector.remove(2));
		System.out.println("Remove 1st "
				+ "occurance of Lily:" + flowerVector.remove("Lily"));
		System.out.println(flowerVector);
		System.out.println("print 2nd position:"+flowerVector.get(2));
		System.out.println("replace first pos:"
				+ ""+flowerVector.set(1,"Sunflower"));
		System.out.println("check tulip:"+flowerVector.contains("Tulip"));
		System.out.println("last occurance:"
				+ ""+flowerVector.lastIndexOf("Daily"));
		System.out.println("Isempty:"+flowerVector.isEmpty());
		System.out.println("Elements:");
		for(String f:flowerVector) {
		System.out.println(f);}
		List<String> subList = flowerVector.subList(0,2);
		System.out.println("SubList:"+subList);
		 String[] array = flowerVector.toArray(new String[flowerVector.size()]);
	        System.out.println("\nArray from flowerVector:");
	        for (String element : array) {
	            System.out.println(element);
	        }
	        
		System.out.println("Size of"
				+ " flowerVector:"+flowerVector.size());
		System.out.println("Capacity of "
				+ "flowerVector:"+flowerVector.capacity());
		flowerVector.add("Orchid");
		flowerVector.add("Carnation");
		
		System.out.println(flowerVector);
		System.out.println("Capacity after"
				+ " adding:"+flowerVector.capacity());
		System.out.println("remove at index 3:"+flowerVector.remove(3));
		System.out.println("Size of "
				+ "flowerVector:"+flowerVector.size());
		
	}
}
