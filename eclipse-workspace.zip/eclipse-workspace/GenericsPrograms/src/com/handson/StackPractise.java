package com.handson;
import java.util.*;
public class StackPractise {

	public static void main(String [] args) {
		
		Stack<Integer> integerStack = new Stack<Integer>();
		integerStack.add(10);
		integerStack.add(20);
		integerStack.add(30);
		integerStack.add(40);
		System.out.println("Added Element:"+integerStack);
		System.out.println("Remove Elements:"+integerStack.pop());
		System.out.println("Accessing Elements:"+integerStack.peek());
		System.out.println("Search 30"+ integerStack.search(30));
		System.out.println("Empty check:" + integerStack.isEmpty());
		System.out.println("Size of stack:"+integerStack.size());
		System.out.println("Capacity of stack:"+integerStack.capacity());
		
		ListIterator<Integer> listIterator = integerStack.listIterator();
		while(listIterator.hasNext()) {
			System.out.print(listIterator.next());
		}
		System.out.println(integerStack);
		integerStack.add(30);
		integerStack.add(60);
		integerStack.add(36);
		integerStack.add(80);
		
		List<Integer> sublist = integerStack.subList(2, 4);
		System.out.println(sublist); 
		
		
		Integer[] array = integerStack.toArray(new Integer[0]);
	        System.out.println("Array from integerStack:");
	        for (int element : array) {
	            System.out.println(element);
	        }
		System.out.println("Clear Stack:");
		integerStack.clear();
		System.out.println("IsEmpty :" +integerStack.isEmpty());
		
	}
}
