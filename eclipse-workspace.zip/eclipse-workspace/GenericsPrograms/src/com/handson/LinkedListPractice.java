package com.handson;
import java.util.*;
public class LinkedListPractice {

	public static void main(String [] args) {
		LinkedList<Integer> integerList = new 
				LinkedList<Integer>();
		
		System.out.println("Add elements:");
		integerList.add(10);
		integerList.add(20);
		integerList.add(30);
		integerList.add(40);
		System.out.println("Added elements:" + integerList);
		System.out.println("Remove elements:");
		System.out.println("at the second position "
		+ "from the integerList:" + integerList.remove(2) );
		System.out.println("first occurrence 20:"+
		integerList.remove(Integer.valueOf(20))); 
		System.out.println("elements:" + integerList);
		System.out.println("Accessing elements:");
		integerList.add(100);
		System.out.println("2nd Position:"+integerList.get(2));
		System.out.println("integerList with the value 50:");
		System.out.println(integerList.set(0,50));
		System.out.println("Searching and Checking:");
		System.out.println(integerList.contains(30));
		System.out.println("last occurance of "
				+ "40:"+integerList.lastIndexOf(40));
		System.out.println("check is empty:");
		System.out.println(integerList.isEmpty());
		integerList.add(70);
		integerList.add(79);
		integerList.add(73);
		ListIterator<Integer> listIterator = integerList.listIterator();
		while(listIterator.hasNext()) {
			System.out.print(listIterator.next());
		}
		System.out.println(integerList);
		List<Integer> sublist = integerList.subList(2, 4);
		System.out.println(sublist);
		
		Integer[] array = integerList.toArray(new Integer[0]);
        System.out.println("\nArray from integerList:");
        for (int element : array) {
            System.out.println(element);
        }
        
        System.out.println("Size:"+integerList.size());
	        integerList.clear();
	        System.out.println("after clear Size:"+integerList.size());
	        
	}
}
