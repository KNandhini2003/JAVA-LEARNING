package com.handson;

import java.util.*;

public class ListPractice {

	public static void main(String [] args) {
		
		ArrayList<String> stringList = new ArrayList<String>();
		stringList.add("apple");
		stringList.add("banana");
		stringList.add("orange");
		stringList.add("grape");
		System.out.println("Added Elements:"+stringList);
		System.out.println("Remove element at "
				+ "indes 2:"+ stringList.remove(2));
		System.out.println("Remove first "
		+ "Occurance of banana:"+ stringList.remove("banana"));
		System.out.println("Access Elements:");
		System.out.println("Element in index 1:"+stringList.get(1));
		System.out.println("Repalace element with"
				+ " pear at 0 index:"+stringList.set(0,"pear"));
		
		System.out.println("Search and check:");
		System.out.println("Check contains "
				+ "orange :" + stringList.contains("orange"));
		
		System.out.println("print the index of the last occurrence"
				+ " of grape:"+ stringList.lastIndexOf("grape"));
		
		System.out.println("Check if the list is"
				+ " empty:"+ stringList.isEmpty());
		
		System.out.println("List Operation:");
		
		ArrayList<String> newList = new ArrayList<String>();
		
		newList.add("kiwi");
		newList.add("pineapple");
		newList.add("melon");
		System.out.println("Newly added list :"+newList);
		
		
		System.out.println(""
		+ "elements from newList to stringList \n"
	+ "starting from index 2. \n:"+ 
		stringList.addAll(2,newList));
		System.out.println(stringList);
		
		System.out.println("Size and Capacity:");
		System.out.println("size of the stringList:"+ stringList.size());
		stringList.clear();
		System.out.println("Cleared arrayList:");
		System.out.println("size of the stringList:"+ stringList.size());
		
		System.out.println("Iteration and Conversion:");
		
		stringList.addAll(newList);
        Iterator<String> iterator = stringList.iterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }
		List<String> subList = stringList.subList(1,3);
		System.out.println("SubList:" + subList);
        
		System.out.println("the stringList to "
				+ "an array  :"+ stringList.toString());
		
        String[] array = stringList.toArray(new String[stringList.size()]);
        System.out.println("\nArray from stringList:");
        for (String element : array) {
            System.out.println(element);
        }
		System.out.println("Sorting and Ordering:");
		
		Collections.sort(stringList);
		System.out.println("Sorting:");
		System.out.println(stringList);
		
		System.out.println("stringList equals newList"
				+ " and print the result." + stringList.equals(newList));
		
		
		System.out.println("the hash code of"
				+ " stringList." + stringList.hashCode());
		
		System.out.println("Original Order:");
		System.out.println(stringList);
		System.out.println("Reverse Order:");
	        stringList.sort(Comparator.reverseOrder());
	        System.out.println(stringList);
	    }       
	        
	}














