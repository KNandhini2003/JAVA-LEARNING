package com.handson;
import java.util.*;
public class ArrayDequePractise {


		public static void main(String[] args) {
		
	        ArrayDeque<Integer> integerDeque = new ArrayDeque<>();
//	 		Queue<Character> ASCII = new PriorityQueue<>(new Ascii());
			
		    integerDeque.add(12);
		    integerDeque.add(24);
		    integerDeque.add(45);
		    integerDeque.add(67);
		    integerDeque.add(87);
		    integerDeque.add(43);
		    
		System.out.println("Added elements:"+integerDeque);
		  System.out.println("Adding elements at both ends");
	        integerDeque.addFirst(100); 
	        integerDeque.addLast(200);
		
	    System.out.println("Added elements:"+integerDeque);
	    
	    System.out.println("Remove & retrieve 1st:"+integerDeque.pollFirst());
	    System.out.println("Remove & retrieve last:"+integerDeque.pollLast());
	    System.out.println("Not remove & retrieve 1st:"+integerDeque.peekFirst());
	    System.out.println("Not remove & retrieve last:"+integerDeque.peekLast());
	    
	    System.out.println("elements:"+integerDeque);
	    System.out.println("check empty:"+integerDeque.isEmpty());
		integerDeque.add(300);
		integerDeque.add(400);
		integerDeque.add(500);
		integerDeque.add(600);
		integerDeque.add(700);
		integerDeque.add(800);
		integerDeque.add(900);
	    System.out.println("Dynamic resize:"+integerDeque.size());
	    integerDeque.remove(900);
	    integerDeque.remove(600);
	    integerDeque.remove(700);
	    System.out.println("Dynamic resize:"+integerDeque.size());
	    
	    System.out.println("elements:"+integerDeque);
	    
	    System.out.println("ArrayDeque to array:");
	    Integer [] array =integerDeque.toArray(new Integer[0]);
	    for(int i:array){
	        System.out.println("elements:"+i);
	        
	    }
	    System.out.println("Clear elements:");
	    integerDeque.clear();
	    System.out.println("ArrayDeque isEmpty:"+integerDeque.isEmpty());
	}
	}

