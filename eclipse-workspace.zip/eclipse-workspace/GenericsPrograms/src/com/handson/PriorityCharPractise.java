/*
package com.handson;

public class PriorityCharPractise {
	static class Ascii implements Comparator<Character> {
        @Override
        public int compare(Character a, Character b) {
           return b.compareTo(a);
        }
    	}
	public static void main(String[] args) {
		System.out.println("Hello World");
		Queue<Character> charQueue = new PriorityQueue();
		Queue<Character> ASCII = new PriorityQueue<>(new Ascii());
		
	    charQueue.add('a');
	    charQueue.add('b');
	    charQueue.add('c');
	    charQueue.add('d');
	System.out.println("Added elements:"+charQueue);
	System.out.println("Head Remove element"
			+ ":"+charQueue.poll());
	System.out.println("elements:"+charQueue);
	System.out.println("Access Peek element"
			+ ":"+charQueue.peek());
	
	System.out.println("Check queue Status"
			+ ":"+charQueue.isEmpty());
	
	System.out.println("Size:"+charQueue.size());
	System.out.println("Elements:");
	System.out.println(charQueue);
	System.out.println("Iteration");
        for (int a : charQueue) {
            System.out.println(a);
        }
   System.out.println("Conversion");
   Object [] obj = charQueue.toArray();
     System.out.println(Arrays.toString(obj));
    
        ASCII.addAll(charQueue);
        System.out.println("ASCII:"+ASCII);
	    charQueue.clear();
	
	System.out.println("Size after "
			+ "clear:"+charQueue.size());
	

}
}
*/
