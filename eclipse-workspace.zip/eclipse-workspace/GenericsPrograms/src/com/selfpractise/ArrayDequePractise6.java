package com.selfpractise;

import java.util.ArrayDeque;
import java.util.Iterator;

public class ArrayDequePractise6 {
	public static void main ( String [] args) {
		ArrayDeque<Character> characterDeque = new ArrayDeque<>();
//		Queue<Character> ASCII = new PriorityQueue<>(new Ascii());
	
				characterDeque.add('A');
				characterDeque.add('B');
				characterDeque.add('C');
				characterDeque.add('D');
				characterDeque.add('E');
				characterDeque.add('F');
    
			System.out.println("Added elements:" + characterDeque);
			System.out.println("Adding elements at both ends");
			characterDeque.addFirst('X'); 
			characterDeque.addLast('Y');

			System.out.println("Added elements:"+characterDeque);

			System.out.println("Remove & retrieve 1st:" + characterDeque.pollFirst());
			System.out.println("Remove & retrieve last:" + characterDeque.pollLast());
			System.out.println("Not remove & retrieve 1st:" + characterDeque.peekFirst());
			System.out.println("Not remove & retrieve last:" + characterDeque.peekLast());

			System.out.println("elements:"+characterDeque);
			System.out.println("elements:"+characterDeque);
			System.out.println("check empty:"+characterDeque.isEmpty());

			System.out.println("Dynamic resize:"+characterDeque.size());
			
			System.out.println("Dynamic resize:"+characterDeque.size());

			System.out.println("elements:"+characterDeque);

			System.out.println("ArrayDeque to array:");
			Character [] array =characterDeque.toArray(new Character[0]);
			for(char i:array)
			{
				System.out.println(i);
			}	
			System.out.println("Iterator:");
			Iterator<Character> descIterator = characterDeque.descendingIterator();
	        while (descIterator.hasNext()) {
	            System.out.print(descIterator.next());
	        }
	        
		System.out.println("Clear elements:");
		characterDeque.clear();
		System.out.println("ArrayDeque isEmpty:"+characterDeque.isEmpty());
		}
}












