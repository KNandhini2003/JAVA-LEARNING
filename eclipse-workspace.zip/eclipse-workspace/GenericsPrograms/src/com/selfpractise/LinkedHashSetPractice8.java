package com.selfpractise;
import java.util.*;
public class LinkedHashSetPractice8 {
			public static void main(String[] args) {
				LinkedHashSet<String> wordSet = new  LinkedHashSet<String>();
				 	wordSet.add("dog");
			        wordSet.add("cat");
			        wordSet.add("bird");
			        wordSet.add("fish");
			        wordSet.add("rabbit");
			        wordSet.add("turtle");
			        wordSet.add("horse");
			   
			        System.out.println("Remove elements:"
						+ "" + wordSet.remove("bird"));
			       
				    
				    System.out.println("Contains:"+
				    		wordSet.contains("fish"));
				    System.out.println("Size:"+wordSet.size());
				    
				    System.out.println("check empty:"+wordSet.size());
				    System.out.print("Iteration:");
				    for(String str: wordSet) {
				    System.out.println(str);
				    }
				    System.out.print("Convertion:");
				    String[] arr = wordSet.toArray(new String[0]);
				    
				    System.out.println(Arrays.toString(arr));
				
				    System.out.print("HashCode:"+wordSet.hashCode());
				    System.out.print("Cleared");
				    		wordSet.clear();
				    
				
			}
		}
