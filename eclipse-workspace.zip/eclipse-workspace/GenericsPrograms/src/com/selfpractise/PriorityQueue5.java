/*package com.selfpractise;

public class PriorityQueue5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PriorityQueue<Character> queue = new PriorityQueue<>();
	       PriorityQueue<Character> newQueue = new PriorityQueue<>(new Ascii());
	       queue.add('A');
	       queue.add('B');
	       queue.add('C');
	       queue.add('D');
	       queue.add('E');
	       queue.add('F');
	       System.out.println("Added Elements:"+queue);
	       System.out.println("Remove & retrieve head:"+queue.poll());
	       System.out.println("retrieve head:"+queue.peek());
	       System.out.println("Queue empty:"+queue.isEmpty());
	       System.out.println("No.of.Elements in Queue:"+queue.size());
	       newQueue.addAll(queue);
	       System.out.println("Added Elements:"+queue);
	       System.out.println("Clear");
	       System.out.println();
	       System.out.println();
	       
		}
		static class Ascii implements Comparator<Character>{
		    public int compare(Character a,Character b){
		       return b.compareTo(a); 
		    }
		}
	}
}

*/
