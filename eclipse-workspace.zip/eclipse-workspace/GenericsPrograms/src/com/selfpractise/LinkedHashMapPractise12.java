package com.selfpractise;
import java.util.*;
public class LinkedHashMapPractise12 {

	public static void main(String [] args) {
		LinkedHashMap<String,String> vehicleTypeMap =
				new LinkedHashMap<String,String>();
		
        vehicleTypeMap.put("car", "sedan");
        vehicleTypeMap.put("truck", "pickup");
        vehicleTypeMap.put("motorcycle", "sportbike");
        vehicleTypeMap.put("van", "minivan");
        vehicleTypeMap.put("suv", "crossover");
        LinkedHashMap<String, String> copyMap = 
        		new LinkedHashMap<>(vehicleTypeMap);
        System.out.println("CopyMap:"+copyMap);
        System.out.println("Motorcycle category:"
        		+ ""+copyMap.get("motorcycle"));
        System.out.println("Remove van:"+copyMap.remove("van"));
        System.out.println("Check suv:"+copyMap.containsKey("suv"));
        System.out.println("Check pickup:"+copyMap.containsValue("suv"));
        System.out.println("Is Empty:"+copyMap.isEmpty());
        System.out.println(copyMap);
        System.out.print("Iterator");
	    for(Map.Entry<String, String> entry: copyMap.entrySet()) {
			System.out.println(entry.getKey() +""+entry.getValue());
		}
	  
	    System.out.println("Retrieve values:");
	    for(Map.Entry<String, String> value : copyMap.entrySet()) {
	    	System.out.println(value.getValue());
	    }
	    System.out.println("Retrieve Keys:");
	    for(Map.Entry<String, String> value : copyMap.entrySet()) {
	    	System.out.println(value.getKey());
	    }
	}
}
