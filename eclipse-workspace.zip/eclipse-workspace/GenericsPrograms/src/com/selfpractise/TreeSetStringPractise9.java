package com.selfpractise;
import java.util.*;
public class TreeSetStringPractise9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet<String> stringSet = new TreeSet<String>();
		stringSet.add("apple");
        stringSet.add("banana");
        stringSet.add("cherry");
        stringSet.add("date");
        stringSet.add("kiwi");
        stringSet.add("orange");
        stringSet.add("grape");
        System.out.println("Elements:"+stringSet);
        System.out.println("Remove:"+stringSet.remove("date"));
        System.out.println("Contains:"+stringSet.contains("banana"));
        System.out.println("IsEmpty:"+stringSet.isEmpty());
        System.out.println("Size:"+stringSet.size());
        Iterator<String> iterator = stringSet.iterator();
        while(iterator.hasNext())
        {
        System.out.println(iterator.next());
        }
        
        System.out.println("First lowest element:"+stringSet.first());
        System.out.println("Last highest element:"+stringSet.last());
        System.out.println("First lowest element:"+stringSet.pollFirst());
        System.out.println("Last highest element:"+stringSet.pollLast());
        
	}

}
