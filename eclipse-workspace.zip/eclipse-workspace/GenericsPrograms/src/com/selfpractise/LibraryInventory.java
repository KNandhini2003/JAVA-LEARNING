package com.selfpractise;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Comparator;

class Book1 {
    private String title;
    private String author;
    private int availableCopies;

    public Book1(String title, String author, int availableCopies) {
        this.title = title;
        this.author = author;
        this.availableCopies = availableCopies;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public int getAvailableCopies() {
        return availableCopies;
    }

    public void lend() {
        if (availableCopies > 0) {
            availableCopies--;
        }
    }

    public void returnBook() {
        availableCopies++;
    }

    @Override
    public String toString() {
        return "\"" + title + "\"" + " by " + author 
                + " (Copies available: " + availableCopies + ")";
    }
}

public class LibraryInventory {
    private ArrayList<Book1> inventory;

    public LibraryInventory() {
        this.inventory = new ArrayList<>();
    }

    public void addBook(String title, String author, int copies) {
        inventory.add(new Book1(title, author, copies));
    }

    public boolean removeBook(String title) {
        Iterator<Book1> it = inventory.iterator();
        while (it.hasNext()) {
            Book1 book = it.next();
            if (book.getTitle().equalsIgnoreCase(title)) {
                it.remove();
                return true;
            }
        }
        return false;
    }

    public boolean containsBook(String title) {
        for (Book1 book : inventory) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                return true;
            }
        }
        return false;
    }

    public boolean isEmpty() {
        return inventory.isEmpty();
    }

    public void listBooks() {
        for (Book1 book : inventory) {
            System.out.println(book.toString());
        }
    }

    public void sortBooksByTitle() {
        inventory.sort(Comparator.comparing(Book1::getTitle));
    }

    public void sortBooksByAuthor() {
        inventory.sort(Comparator.comparing(Book1::getAuthor));
    }

    public int getSize() {
        return inventory.size();
    }

    public void increaseCapacity(int amount) {
        inventory.ensureCapacity(inventory.size() + amount);
    }

    public void iterateAndPrint() {
        for (Book1 book : inventory) {
            System.out.println(book);
        }
    }

    public String[] toArray() {
        String[] bookArray = new String[inventory.size()];
        for (int i = 0; i < inventory.size(); i++) {
            bookArray[i] = inventory.get(i).toString();
        }
        return bookArray;
    }

    public Iterator<Book1> getIterator() {
        return inventory.iterator();
    }

    public void lendBook(String title) {
        for (Book1 book : inventory) {
            if (book.getTitle().equalsIgnoreCase(title) && book.getAvailableCopies() > 0) {
                book.lend();
                break;
            }
        }
    }

    public void returnBook(String title) {
        for (Book1 book : inventory) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                book.returnBook();
                break;
            }
        }
    }

    public static void main(String[] args) {
        LibraryInventory library = new LibraryInventory();

        library.addBook("Learning Python", "maran", 3);
        library.addBook("Effective Java", "Jeni", 4);
        library.addBook("Apple", "Andre", 5);
  

        System.out.println("List of books:");
        library.listBooks();

        System.out.println("\nContains 'Harry Potter': " + library.containsBook("Harry Potter"));



        library.sortBooksByTitle();
        System.out.println("\nBooks sorted by title:");
        library.listBooks();

        library.sortBooksByAuthor();
        System.out.println("\nBooks sorted by author:");
        library.listBooks();

        System.out.println("\nAfter lending 'Effective Java':");
        library.lendBook("Effective Java");
        library.listBooks();

        System.out.println("\nAfter returning 'Effective Java':");
        library.returnBook("Effective Java");
        library.listBooks();

        System.out.println("\nNumber of books: " + library.getSize());

        String[] bookArray = library.toArray();
        System.out.println("\nInventory as array:");
        for (String title : bookArray) {
            System.out.println(title);
        }
    }
}
