package com.selfpractise;

import java.util.*;

public class LinkedListPractice {

    private LinkedList<Student> students;

    public LinkedListPractice() {
        students = new LinkedList<>();
    }

    public void addStudent(String name, int age, String grade) {
        students.add(new Student(name, age, grade));
    }

    public boolean removeStudent(String name) {
        Iterator<Student> iterator = students.iterator();
        while (iterator.hasNext()) {
            if (iterator.next().getName().equals(name)) {
                iterator.remove();
                return true;
            }
        }
        return false;
    }

    public void removeStudentsByAge(int age) {
        Iterator<Student> iterator = students.iterator();
        while (iterator.hasNext()) {
            if (iterator.next().getAge() == age) {
                iterator.remove();
            }
        }
    }

    public boolean containsStudent(String name) {
        for (Student student : students) {
            if (student.getName().equals(name)) {
                return true;
            }
        }
        return false;
    }

    public boolean isEmpty() {
        return students.isEmpty();
    }

    public void listStudents() {
        for (Student student : students) {
            System.out.println(student.getName());
        }
    }

    public int getTotalStudents() {
        return students.size();
    }

    public void iterateAndPrint() {
        for (Student student : students) {
            System.out.println("Name: " + student.getName() + ", Age: " + student.getAge());
        }
    }

    public String[] toArray() {
        String[] namesArray = new String[students.size()];
        for (int i = 0; i < students.size(); i++) {
            namesArray[i] = students.get(i).getName();
        }
        return namesArray;
    }

    public Iterator<Student> getSpecialIterator() {
        return students.iterator();
    }

    public Iterator<Student> getDescendingIterator() {
        return students.descendingIterator();
    }

    public void sortByName() {
        students.sort(Comparator.comparing(Student::getName));
    }

    public void sortByAge() {
        students.sort(Comparator.comparingInt(Student::getAge));
    }

    public void updateStudentAge(String name, int newAge) {
        for (Student student : students) {
            if (student.getName().equals(name)) {
                student.setAge(newAge);
                break;
            }
        }
    }

    public void updateStudentGrade(String name, String newGrade) {
        for (Student student : students) {
            if (student.getName().equals(name)) {
                student.setGrade(newGrade);
                break;
            }
        }
    }

    public void clearStudents() {
        students.clear();
    }

    static class Student {
        private String name;
        private int age;
        private String grade;

        public Student(String name, int age, String grade) {
            this.name = name;
            this.age = age;
            this.grade = grade;
        }

        public String getName() {
            return name;
        }

        public int getAge() {
            return age;
        }

        public String getGrade() {
            return grade;
        }

        public void setAge(int age) {
            this.age = age;
        }

        public void setGrade(String grade) {
            this.grade = grade;
        }
    }

    public static void main(String[] args) {
        LinkedListPractice practice = new LinkedListPractice();

        practice.addStudent("Meena", 20, "A");
        practice.addStudent("Ram", 22, "B");
        practice.addStudent("Sam", 21, "C");
        practice.addStudent("Tara", 23, "A");


        System.out.println("List of students:");
        practice.listStudents();

        System.out.println("Total students: " + practice.getTotalStudents());

        System.out.println("\nRemoving student 'Sam'");
        practice.removeStudent("Sam");
        practice.listStudents();

        System.out.println("\nTotal students after removal: " + practice.getTotalStudents());
    }
}
