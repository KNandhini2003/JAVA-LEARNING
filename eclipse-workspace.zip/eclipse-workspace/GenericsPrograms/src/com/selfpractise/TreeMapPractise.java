package com.selfpractise;
import java.util.*;
public class TreeMapPractise {

	public static void main(String[] args) {
		TreeMap<String,Integer> studentMap = new
				TreeMap<String,Integer>();
		studentMap.put("Alice", 20);
		studentMap.put("Bob", 22);
		studentMap.put("Charlie", 18);
		studentMap.put("David", 25);
		studentMap.put("Eva", 21);
		System.out.println("Remove:"+studentMap.remove("Charlie"));
		System.out.println("Contains:"
		+studentMap.containsValue("Bob"));
		System.out.println("Check empty:"+studentMap.isEmpty());
		System.out.println();
		for(Map.Entry<String, Integer> entry: studentMap.entrySet()) {
			System.out.println(entry.getKey() +""+entry.getValue());
		}
		Map.Entry<String, Integer> max = studentMap.lastEntry();
		Map.Entry<String, Integer> min = studentMap.firstEntry();
		System.out.println("Entry with max key value:"+max.getKey());
		System.out.println("Entry with min key value:"+min.getKey());
		System.out.println("Polling first:"+studentMap.pollFirstEntry());
		System.out.println("Polling last:"+studentMap.pollLastEntry());
		
	}

}
