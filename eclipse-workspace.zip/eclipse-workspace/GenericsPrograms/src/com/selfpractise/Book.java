package com.selfpractise;

public class Book {

	public String getTitle() {
		// TODO Auto-generated method stub
		return null;
	}

}
