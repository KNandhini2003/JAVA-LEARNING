package com.selfpractise;
import java.util.*;
public class HashSetPractice7 {

	public static void main(String[] args) {
		HashSet<String> stringSet = new  HashSet<String>();
		 	stringSet.add("apple");
	        stringSet.add("banana");
	        stringSet.add("orange");
	        stringSet.add("grape");
	        HashSet<String> additionalSet = new  HashSet<String>();    
	        additionalSet.addAll(stringSet);   
	        System.out.println("Remove elements:"
				+ "" + stringSet.remove("banana"));
	        HashSet<String> removalSet = new  HashSet<String>();    
		    removalSet.removeAll(stringSet);
		    
		    System.out.println("Check empty"
		    		+ ":"+removalSet.isEmpty());
		    System.out.println("Contains:"+
		    		stringSet.contains("orange"));
		    System.out.println("Size:"+stringSet.size());
		    
		    System.out.println("check empty:"+stringSet.size());
		    System.out.print("Iteration:");
		    for(String str: stringSet) {
		    System.out.println(str);
		    }
		    System.out.print("Convertion:");
		    String[] arr = stringSet.toArray(new String[0]);
		    
		    System.out.println(Arrays.toString(arr));
		System.out.println();
		HashSet<String> retainSet = new HashSet<String>();
		retainSet.add("apple");
		retainSet.add("grapes");
		stringSet.retainAll(retainSet);
		System.out.println("After retaining"
				+ " elements: " + stringSet);
		
	}
}
