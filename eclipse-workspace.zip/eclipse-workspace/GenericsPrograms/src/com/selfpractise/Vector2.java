package com.selfpractise;
import java.util.*;

class Product {
    private String name;
    private double price;

    public Product(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    @Override
    public String toString() {
        return "Product{name='" + name + "', price=" + price + "}";
    }
}

public class Vector2 {
    private List<Product> products;

    public Vector2() {
        products = new ArrayList<>();
    }

    public void addProduct(String name, double price) {
        products.add(new Product(name, price));
    }

    public boolean removeProduct(String name) {
        Iterator<Product> iterator = products.iterator();
        while (iterator.hasNext()) {
            if (iterator.next().getName().equals(name)) {
                iterator.remove();
                return true;
            }
        }
        return false;
    }

    public boolean containsProduct(String name) {
        for (Product product : products) {
            if (product.getName().equals(name)) {
                return true;
            }
        }
        return false;
    }

    public boolean isEmpty() {
        return products.isEmpty();
    }

    public void listProducts() {
        for (Product product : products) {
            System.out.println(product);
        }
    }

    public int getTotalProducts() {
        return products.size();
    }

    public static void main(String[] args) {
        Vector2 productManager = new Vector2();
        
  
        productManager.addProduct("Laptop", 1000.00);
        productManager.addProduct("Phone", 500.00);
        
        System.out.println("Products in the list:");
        productManager.listProducts();
   
        productManager.removeProduct("Phone");
        System.out.println("\nAfter removing 'Phone':");
        productManager.listProducts();
    
        System.out.println("\nContains 'Laptop': " + productManager.containsProduct("Laptop"));
    
        System.out.println("Is the list empty: " + productManager.isEmpty());
     
        System.out.println("Total products: " + productManager.getTotalProducts());
    }
}
