package com.selfpractise;

import java.util.HashMap;
import java.util.Map;

public class HashMapPractise11 {


	public static void main(String[] args) {
		
		HashMap<String,Integer> wordCountMap =
				new HashMap<>();
			wordCountMap.put("apple", 5);
	        wordCountMap.put("banana", 8);
	        wordCountMap.put("cherry", 3);
	        wordCountMap.put("date", 6);
	        wordCountMap.put("grape", 4);
	        
	    HashMap<String,Integer> copyMap = new 
	    		HashMap<>(wordCountMap);
	    
	    System.out.println("Date:"+wordCountMap.get("date"));
	    System.out.println("Remove word Cherry:" + 
	    wordCountMap.remove("cherry"));
	    System.out.println("Check banana:"+wordCountMap.containsKey("banana"));
	    System.out.print("check 4 :"+ wordCountMap.containsValue(4));
	    System.out.println("Check empty:"+wordCountMap.isEmpty());
	    System.out.print("Iterator");
	    for(Map.Entry<String, Integer> entry: wordCountMap.entrySet()) {
			System.out.println(entry.getKey() +""+entry.getValue());
		}
	    System.out.println("Print");
	    System.out.print(wordCountMap);
	    
	}
	
}
