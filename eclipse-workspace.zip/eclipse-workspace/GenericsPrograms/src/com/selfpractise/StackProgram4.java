package com.selfpractise;

import java.util.*;

class Book2 {
    private String title;
    private String author;
    private int publicationYear;

    public Book2(String title, String author, int publicationYear) {
        this.title = title;
        this.author = author;
        this.publicationYear = publicationYear;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public int getPublicationYear() {
        return publicationYear;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public void setPublicationYear(int publicationYear) {
        this.publicationYear = publicationYear;
    }

    @Override
    public String toString() {
        return "Book{title='" + title + "', author='" + author + "', publicationYear=" + publicationYear + "}";
    }
}

public class StackProgram4 {
    private Stack<Book2> bookStack;

    public StackProgram4() {
        bookStack = new Stack<>();
        bookStack.push(new Book2("The Great Gatsby", "F. Scott Fitzgerald", 1925));
        bookStack.push(new Book2("To Kill a Mockingbird", "Harper Lee", 1960));
        bookStack.push(new Book2("1984", "George Orwell", 1949));
    }

    public void pushBook(String title, String author, int publicationYear) {
        bookStack.push(new Book2(title, author, publicationYear));
    }

    public Book2 popBook() {
        if (!bookStack.isEmpty()) {
            return bookStack.pop();
        }
        return null;
    }

    public Book2 peekBook() {
        if (!bookStack.isEmpty()) {
            return bookStack.peek();
        }
        return null;
    }

    public boolean containsBook(String title) {
        for (Book2 book : bookStack) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                return true;
            }
        }
        return false;
    }

    public boolean isEmpty() {
        return bookStack.isEmpty();
    }

    public void listBooks() {
        for (Book2 book : bookStack) {
            System.out.println(book);
        }
    }

    public int getTotalBooks() {
        return bookStack.size();
    }

    public void iterateAndPrint() {
        for (Book2 book : bookStack) {
            System.out.println(book.getTitle());
        }
    }

    public void updateBookAuthor(String title, String newAuthor) {
        for (Book2 book : bookStack) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                book.setAuthor(newAuthor);
                break;
            }
        }
    }

    public void updateBookPublicationYear(String title, int newYear) {
        for (Book2 book : bookStack) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                book.setPublicationYear(newYear);
                break;
            }
        }
    }

    public void clearBooks() {
        bookStack.clear();
    }

    public static void main(String[] args) {
        StackProgram4 stack = new StackProgram4();
        stack.pushBook("Brave New World", "Aldous Huxley", 1932);
        System.out.println("All books in the stack:");
        stack.listBooks();
        System.out.println("\nTop book: " + stack.peekBook());
        System.out.println("\nContains 'To Kill a Mockingbird': " + stack.containsBook("To Kill a Mockingbird"));
        System.out.println("Is the stack empty: " + stack.isEmpty());
        System.out.println("Total books: " + stack.getTotalBooks());
        System.out.println("\nIterating over the stack:");
        stack.iterateAndPrint();
        stack.updateBookAuthor("1984", "Eric Arthur Blair");
        stack.updateBookPublicationYear("1984", 1950);
        System.out.println("\nAfter updates:");
        stack.listBooks();
        System.out.println("\nPopped book: " + stack.popBook());
        stack.clearBooks();
        System.out.println("Total books after clearing: " + stack.getTotalBooks());
    }
}
