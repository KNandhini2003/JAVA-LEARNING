package Handson_13BST;
import java.util.*;

class Node {
    int key;
    public Node left;
    public Node right;

    Node(int key) {
        this.key = key;
        this.left = null;
        this.right = null;
    }
}

public class BinaryTree {
    public Node root;

    public Node createNode(int key) {
        return new Node(key);
    }

    public Node insertLevelOrder(int key) {
        if (root == null) {
            root = new Node(key);
            return root;
        }
        Queue<Node> queue = new LinkedList<>();
        queue.add(root);
        while (!queue.isEmpty()) {
            Node temp = queue.poll();
            if (temp.left == null) {
                temp.left = new Node(key);
                return root;
            } else {
                queue.add(temp.left);
            }
            if (temp.right == null) {
                temp.right = new Node(key);
                return root;
            } else {
                queue.add(temp.right);
            }
        }
        return root;
    }

    public void inOrderTraversal(Node root) {
        if (root != null) {
            inOrderTraversal(root.left);
            System.out.print(root.key + " ");
            inOrderTraversal(root.right);
        }
    }

    public void preOrderTraversal(Node root) {
        if (root != null) {
            System.out.print(root.key + " ");
            preOrderTraversal(root.left);
            preOrderTraversal(root.right);
        }
    }

    public void postOrderTraversal(Node root) {
        if (root != null) {
            postOrderTraversal(root.left);
            postOrderTraversal(root.right);
            System.out.print(root.key + " ");
        }
    }

    public boolean search(Node root, int searchData) {
        if (root == null)
            return false;
        if (root.key == searchData)
            return true;
        return search(root.left, searchData) || search(root.right, searchData);
    }

    public void levelOrderTraversal(Node root) {
        if (root == null)
            return;
        Queue<Node> queue = new LinkedList<>();
        queue.add(root);
        while (!queue.isEmpty()) {
            Node temp = queue.poll();
            System.out.print(temp.key + " ");
            if (temp.left != null) {
                queue.add(temp.left);
            }
            if (temp.right != null) {
                queue.add(temp.right);
            }
        }
    }

    public void depthElementOfTree(Node root) {
        if (root == null)
            return;
        Queue<Node> queue = new LinkedList<>();
        queue.add(root);
        Node temp = null;
        while (!queue.isEmpty()) {
            temp = queue.poll();
            if (temp.left != null) {
                queue.add(temp.left);
            }
            if (temp.right != null) {
                queue.add(temp.right);
            }
        }
        if (temp != null) {
            System.out.print(temp.key);
        }
    }

    public void deleteNode(Node root, int key) {
        if (root == null)
            return;
        Queue<Node> queue = new LinkedList<>();
        queue.add(root);
        Node temp = null;
        Node keyNode = null;
        while (!queue.isEmpty()) {
            temp = queue.poll();
            if (temp.key == key)
                keyNode = temp;
            if (temp.left != null)
                queue.add(temp.left);
            if (temp.right != null)
                queue.add(temp.right);
        }

        if (keyNode != null) {
            if (keyNode.left == null && keyNode.right == null) {
                deleteLeafNode(root, keyNode);
            } else if (keyNode.left != null && keyNode.right != null) {
                int deepestNode = temp.key;
                deleteLeafNode(root, temp);
                keyNode.key = deepestNode;
            } else {
                if (keyNode.left != null) {
                    replaceNodeWithChild(root, keyNode, keyNode.left);
                } else {
                    replaceNodeWithChild(root, keyNode, keyNode.right);
                }
            }
        }
    }

    public void replaceNodeWithChild(Node root, Node deleteNode, Node child) {
        if (root == deleteNode) {
            root.key = child.key;
            root.left = child.left;
            root.right = child.right;
            return;
        }
        Queue<Node> queue = new LinkedList<>();
        queue.add(root);
        Node temp;
        while (!queue.isEmpty()) {
            temp = queue.poll();
            if (temp.left != null) {
                if (temp.left == deleteNode) {
                    temp.left = child;
                    return;
                }
                queue.add(temp.left);
            }
            if (temp.right != null) {
                if (temp.right == deleteNode) {
                    temp.right = child;
                    return;
                }
                queue.add(temp.right);
            }
        }
    }

    public void deleteLeafNode(Node root, Node deleteNode) {
        if (root == deleteNode) {
            root = null;
            return;
        }
        Queue<Node> queue = new LinkedList<>();
        queue.add(root);
        Node temp = null;
        while (!queue.isEmpty()) {
            temp = queue.poll();
            if (temp.left != null) {
                if (temp.left == deleteNode) {
                    temp.left = null;
                    return;
                }
                queue.add(temp.left);
            }
            if (temp.right != null) {
                if (temp.right == deleteNode) {
                    temp.right = null;
                    return;
                }
                queue.add(temp.right);
            }
        }
    }

    public void binaryTreePath(Node root) {
        if (root == null)
            return;
        Queue<Node> queue = new LinkedList<>();
        queue.add(root);
        String l = "";
        l = l + queue.peek().key + " ";
        String r = "";
        r = r + queue.peek().key + " ";
        Node temp = null;
        while (!queue.isEmpty()) {
            temp = queue.poll();
            if (temp.left != null) {
                queue.add(temp.left);
                l = l + temp.left.key + " ";
            }
            if (temp.right != null) {
                queue.add(temp.right);
                r = r + temp.right.key + " ";
            }
        }
        l = l.replace(" ", "->");
        r = r.replace(" ", "->");
        System.out.println("Left path: " + l);
        System.out.println("Right path: " + r);
    }

    public int height(Node root) {
        if (root == null) {
            return 0;
        }
        int leftHeight = height(root.left);
        int rightHeight = height(root.right);
        return Math.max(leftHeight, rightHeight) + 1;
    }

    public int maxDepth(Node root) {
        if (root == null) {
            return 0;
        }
        int leftTree = maxDepth(root.left);
        int rightTree = maxDepth(root.right);
        return Math.max(leftTree, rightTree) + 1;
    }

    public int findMax(Node root) {
        if (root == null) {
            return Integer.MIN_VALUE;
        }
        int max = root.key;
        int leftMax = findMax(root.left);
        int rightMax = findMax(root.right);
        if (leftMax > max) {
            max = leftMax;
        }
        if (rightMax > max) {
            max = rightMax;
        }
        return max;
    }

    public int findMin(Node root) {
        if (root == null) {
            return Integer.MAX_VALUE;
        }
        int min = root.key;
        int leftMin = findMin(root.left);
        int rightMin = findMin(root.right);
        if (leftMin < min) {
            min = leftMin;
        }
        if (rightMin < min) {
            min = rightMin;
        }
        return min;
    }

    public boolean isFullBinaryTree(Node root) {
        if (root == null) {
            return true;
        }
        if (root.left == null && root.right == null) {
            return true;
        }
        if (root.left != null && root.right != null) {
            return isFullBinaryTree(root.left) && isFullBinaryTree(root.right);
        }
        return false;
    }

    public boolean isCompleteBinaryTree(Node root) {
        if (root == null) {
            return true;
        }
        Queue<Node> queue = new LinkedList<>();
        queue.add(root);
        boolean end = false;

        while (!queue.isEmpty()) {
            Node currentNode = queue.poll();
            if (currentNode == null) {
                end = true;
            } else {
                if (end) {
                    return false;
                }
                queue.add(currentNode.left);
                queue.add(currentNode.right);
            }
        }
        return true;
    }

    public boolean isBalanced(Node root) {
        if (root == null)
            return true;
        if (Math.abs(height(root.left) - height(root.right)) > 1)
            return false;
        return isBalanced(root.left) && isBalanced(root.right);
    }

    int calculateRightDepth(Node node) {
        int depth = 0;
        while (node != null) {
            depth++;
            node = node.right;
        }
        return depth;
    }

    int calculateLeftDepth(Node node) {
        int depth = 0;
        while (node != null) {
            depth++;
            node = node.left;
        }
        return depth;
    }

    public int totalNodes(Node root) {
        if (root == null)
            return 0;
        int leftDepth = calculateLeftDepth(root);
        int rightDepth = calculateRightDepth(root);
        if (leftDepth == rightDepth)
            return (1 << leftDepth) - 1;
        return 1 + totalNodes(root.left) + totalNodes(root.right);
    }

    private int maxSum;
    private List<Integer> maxSumPath;

    public List<Integer> findMaxSumPath(Node root) {
        maxSum = Integer.MIN_VALUE;
        maxSumPath = new ArrayList<>();
        findMaxSumPathHelper(root, new ArrayList<>(), 0);
        return maxSumPath;
    }
    
    private void findMaxSumPathHelper(Node node, List<Integer> currentPath, int currentSum) {
        if (node == null) {
            return;
        }
        currentPath.add(node.key);
        currentSum += node.key;
        if (node.left == null && node.right == null) {
            if (currentSum > maxSum) {
                maxSum = currentSum;
                maxSumPath = new ArrayList<>(currentPath);
            }
        } else {
            findMaxSumPathHelper(node.left, currentPath, currentSum);
            findMaxSumPathHelper(node.right, currentPath, currentSum);
        }
        currentPath.remove(currentPath.size() - 1);
    }
    
    public boolean checkTwoTreeMirror(Node n1 , Node n2) {
    	if(n1 == null && n2 == null ) {
    		return true;
    	}
    	if(n1.key == n2.key && n1 != null && n2 != null) {
    		return checkTwoTreeMirror(n1.left , n2.left) && 
    		checkTwoTreeMirror(n1.right , n2.right);
    	}
    	else {
    		return false;
    	}
    }

    public int convertToSumTree(Node root) {
        if (root == null) {
            return 0;
        }

        int leftSum = convertToSumTree(root.left);
        int rightSum = convertToSumTree(root.right);

        int oldVal = root.key;
        root.key = leftSum + rightSum;

        return root.key + oldVal;
    }

    public void convertToSumTreeMain(Node root) {
        convertToSumTree(root);
    }
    public void merge(Node n1 , Node n2) {
    	if(n1 == null || n2 == null)
    		return ;
    	n1.key += n1.key + n2.key;
    	if(n1.left != null && n2.left != null) {
    		merge(n1.left,n2.left);
    	}
    	else if(n1.left == null 
    			&&n2.left != null)
    		n1.left = new Node(n2.left.key);
    		merge(n1.left,n2.left);
    	
    	if(n1.right != null && n2.right != null) {
    		merge(n1.right,n2.right);
    	}
    	else if(n1.right == null && 
    			n2.right != null) {
    		n1.right = new Node(n2.right.key);
    		merge(n1.left,n2.left);
    		
    	}
    }
    public void levelOrderTraverse(Node root) {
        List<List<Integer>> result = new ArrayList<>();
        if (root == null) {
            return ;
        }

        Queue<Node> queue = new LinkedList<>();
        queue.add(root);

        while (!queue.isEmpty()) {
            int levelSize = queue.size();
            List<Integer> currentLevel = new ArrayList<>();

            for (int i = 0; i < levelSize; i++) {
                Node currentNode = queue.poll();
                currentLevel.add(currentNode.key);

                if (currentNode.left != null) {
                    queue.add(currentNode.left);
                }
                if (currentNode.right != null) {
                    queue.add(currentNode.right);
                }
            }

            result.add(currentLevel);
        }

       System.out.print(result);
    }
    public int  countgoodNodes(Node node) {
    	return goodNodes(node,Integer.MIN_VALUE);
    	}
    public int goodNodes(Node root , int max) {
    	if(root == null)
    		return 0;
    	int count = 0;
    	if(root.key >= max) {
    		count = 1;
    		max = root.key;
    	}
    	count += goodNodes(root.left,max);
    	count += goodNodes(root.right,max);
    	return count;
    }
    public void getLeftView(Node node) {
    	ArrayList<Integer> a = new ArrayList<Integer>();
    	a = leftView(node,0,a);
    	System.out.println(a);
    }
    public ArrayList<Integer> leftView(Node node,int lev,
    		ArrayList<Integer> arr) {
    	if(node == null)
    		return arr;
    	if(lev == arr.size()) {
    		arr.add(node.key);
    	}
    	leftView(node.left,lev+1,arr);
    	leftView(node.right,lev+1,arr);
    	
    	return arr;
    }
    public void printLeftSubtree(Node node) {
        if (node == null || node.left == null) {
            System.out.println("Left subtree is empty");
            return;
        }
        System.out.print("Left subtree: ");
        printInOrder(node.left);
        System.out.println();
    }
    public void printRightSubtree(Node node) {
        if (node == null || node.right == null) {
            System.out.println("Right subtree is empty");
            return;
        }
        System.out.print("Right subtree:");
        printInOrder(node.right);
        System.out.println();
    }
    private void printInOrder(Node node) {
        if (node == null) {
            return;
        }
        printInOrder(node.left);
        System.out.print(node.key + " ");
        printInOrder(node.right);
    }
}
    




























