package Handson_13BST;
import Handson_13BST.BinarySearchTree;
public class TwoSum13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	BinarySearchTree t = new
			BinarySearchTree();
	t.root = new Node(5);
	t.root.left = new Node(3);
	t.root.right = new Node(6);
	t.root.left.left = new Node(-1);
	t.root.left.right = new Node(4);
	t.root.right.right= new Node(7);
	
	t.root = new Node(2);
	t.root.left = new Node(1);
	t.root.right = new Node(3);
//	t.root.right.left = new Node(3);
//	t.root.right.right = new Node(6);
	t.inOrderTraversal(t.root);
	System.out.println(t.twoSum(t.root, -2));
	}

}
