package Handson_13BST;

public class ValidateBinaryTree {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	BinarySearchTree t = new BinarySearchTree();
	BinarySearchTree t2 = new BinarySearchTree();
	t.root = new Node(5);
	t.root.left = new Node(1);
	t.root.right = new Node(4);
	t.root.right.left = new Node(3);
	t.root.right.right = new Node(6);
	System.out.print(t.isBST(t.root));
	t2.root = new Node(1);
	t2.root.right = new Node(1);
	t2.root.right.right= new Node(6);
	
	System.out.print(t2.isBST(t2.root));
	}

}
