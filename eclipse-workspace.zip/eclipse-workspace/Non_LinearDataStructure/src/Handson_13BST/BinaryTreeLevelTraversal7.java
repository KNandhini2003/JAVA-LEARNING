package Handson_13BST;

public class BinaryTreeLevelTraversal7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Handson_13BST.BinaryTree tree1 = 
		new Handson_13BST.BinaryTree();  
	    tree1.root = new Node(3);
	    tree1.root.left = new Node(9);
	    tree1.root.right = new Node(20);
	    tree1.root.right.left = new Node(15);
	    tree1.root.right.right = new Node(7);
	    
	    tree1.levelOrderTraverse(tree1.root);
	}

}
