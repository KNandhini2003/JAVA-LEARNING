package Handson_13BST;

public class MaxPath {
 //private static int maxPath = Integer.MIN_VALUE; // Class member variable
		 //   private static ArrayList<Integer> maxPathNodes = new ArrayList<>(); // To store the nodes of the max path

		 public static void main(String[] args) {
//		        Node root = ... // Initialize your binary tree here
//		        ArrayList<Integer> currentPath = new ArrayList<>();
//		        findMaxSumPath(root, 0, currentPath);
//		        System.out.println("Max path sum: " + maxPath);
//		        System.out.println("Nodes in the max path: " + maxPathNodes);
//		    }
	}

}
