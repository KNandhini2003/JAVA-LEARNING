package Handson_13BST;

public class LeftViewOfTree {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Handson_13BST.BinaryTree tree
		= new Handson_13BST.BinaryTree();
	tree.root = new Node(2);
	tree.root.left = new Node(35);
	tree.root.right = new Node(10);
	tree.root.left.left = new Node(2);
	tree.root.left.right = new Node(3);
	tree.root.right.right = new Node(5);
	tree.root.right.left = new Node(2);
	tree.getLeftView(tree.root);
	}

}
