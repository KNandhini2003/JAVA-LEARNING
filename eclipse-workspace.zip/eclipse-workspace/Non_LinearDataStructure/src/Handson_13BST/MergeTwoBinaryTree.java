package Handson_13BST;

public class MergeTwoBinaryTree {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Handson_13BST.BinaryTree tree1 = new Handson_13BST.BinaryTree();  
        tree1.root = new Node(1);
        tree1.root.left = new Node(-2);
        tree1.root.right = new Node(1);
        tree1.root.left.left = new Node(3);
        tree1.root.left.right = new Node(1);
        tree1.root.right.left = new Node(-1);
        tree1.root.right.right = new Node(-1);
        
        Handson_13BST.BinaryTree tree2 = new Handson_13BST.BinaryTree();
        tree2.root = new Node(5);
        tree2.root.left = new Node(-1);
        tree2.root.right = new Node(1);
        tree2.root.left.left = new Node(-8);
        tree2.root.left.right = new Node(4);
        tree2.root.right.left = new Node(6);
        tree2.root.right.right = new Node(-1);
        
        tree1.merge(tree1.root, tree2.root);
        tree1.inOrderTraversal(tree1.root);
	}

}
