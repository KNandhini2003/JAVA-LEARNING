package Handson_13BST;
import Handson_13BST.BinaryTree;
public class ConvertBinaryTreeSumTree {
	public static void main(String [] args) {
	BinaryTree tree1 = new BinaryTree();
	 tree1.root = new Node(1);
     tree1.root.left = new Node(-2);
     tree1.root.right = new Node(1);
     tree1.root.left.left = new Node(3);
     tree1.root.left.right = new Node(1);
     tree1.root.right.left = new Node(-1);
     tree1.root.right.right = new Node(-1);

     tree1.convertToSumTreeMain(tree1.root);
	}
}
