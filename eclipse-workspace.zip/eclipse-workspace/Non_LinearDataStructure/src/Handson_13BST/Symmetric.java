package Handson_13BST;


//import BinaryTreeStructure.Node;
public class Symmetric {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BinaryTree tree = new
				BinaryTree();
		tree.root = new Node(1);
		tree.root.left = new Node(2);
		tree.root.right = new Node(2);
		tree.root.left.left = new Node(3);
		tree.root.right.left = new Node(4);
		tree.root.left.right = new Node(4);
		tree.root.right.right = new Node(3);
		BinaryTree tree1 = new
				BinaryTree();
		tree1.root = new Node(1);
		tree1.root.left = new Node(2);
		tree1.root.right = new Node(2);
		tree1.root.left.left = new Node(3);
		tree1.root.right.left = new Node(4);
		tree1.root.left.right = new Node(4);
		tree1.root.right.right = new Node(3);
		System.out.print(tree.checkTwoTreeMirror(tree.root, tree1.root));
		
		
	}

}
