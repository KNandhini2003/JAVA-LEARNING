package Graph;
import java.util.*;
public class TopologicalSort {
	int numberOfVertices;
	int topo[][] = new int[numberOfVertices][numberOfVertices];
	TopologicalSort(int n) {
		numberOfVertices = n;
	}
	public void insert(int mainVertices,int subVertices) {
		if(mainVertices > numberOfVertices || subVertices > numberOfVertices ||
		   mainVertices < 0 || subVertices < 0	||
		   mainVertices == numberOfVertices || subVertices == numberOfVertices )
			return;
		System.out.println(mainVertices);
		System.out.println(subVertices);
		
		topo[mainVertices][subVertices] = 1;
		
	}
	public void display() {
		for(int i = 0 ; i < numberOfVertices ; i++) {
			for(int j = 0 ; j < numberOfVertices ; j++) {
				System.out.print(topo[i][j] + " ");
			}
		}
	}
	public void topoSort(int startVertex) {
		boolean visited[] = new boolean[numberOfVertices];
		Stack<Integer> stack = new Stack<>();
		int found = 0,k = 0,j = 0;
		for(int i = 0 ; i < numberOfVertices ; i++) {
			for (j = 0 ; j < numberOfVertices ; j++) {
					loop:
						if(!visited[j]) {
							for( k = 0 ; k < numberOfVertices ; k++ ) {
								if(topo[j][k] == 1)
									break loop;
							}
						}
								
			}
					if(k == numberOfVertices) {
					stack.push(j);
					if(!visited[j]) {
						visited[j] = true;
					}
			}
			
	}
		System.out.println(stack);
	}
	public static void main(String[] args) {
		
		TopologicalSort graph = new TopologicalSort(6);
	      graph.insert(5, 2);
	        graph.insert(5, 0);
	        graph.insert(4, 0);
	        graph.insert(4, 1);
	        graph.insert(2, 3);
	        graph.insert(3, 1);

	        graph.display();
	        graph.topoSort(0);
		
	}

}
