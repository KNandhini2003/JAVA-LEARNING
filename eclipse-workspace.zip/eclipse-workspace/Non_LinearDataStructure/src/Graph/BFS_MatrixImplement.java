package Graph;
import java.util.*;
public class BFS_MatrixImplement {
	int size;
	int matrix [][];
	
	BFS_MatrixImplement(int s){
		size = s;
		matrix = new int[size][size];
	}
	public void insert(int mainVertex,int subVertex) {
		if(mainVertex > size || subVertex > size ||
				mainVertex < 0 || subVertex < 0)
			return;
		
		matrix[mainVertex][subVertex] = 1;
	}
	public void BFS_Traversal(int startIndex) {
		if(startIndex < 0 || startIndex > size || startIndex == size)
			return;
		boolean visited[] = new boolean[size];
		Queue<Integer> queue = new LinkedList<>();
		queue.add(startIndex);
		visited[startIndex] = true;
		while(!queue.isEmpty()) {
			int i = queue.poll();
			System.out.print(i + " ");
			for(int j = 0 ; j < size; j++) {
				if(matrix[i][j] == 1 && !visited[j]) {
					visited[j] = true;
					queue.add(j);
				}
			}
		}
		
	}
	public static void main(String [] args) {
		BFS_MatrixImplement graph = new BFS_MatrixImplement(5);
		   graph.insert(0, 1);
	        graph.insert(0, 4);
	        graph.insert(1, 0);
	        graph.insert(1, 4);
	        graph.insert(1, 2);
	        graph.insert(1, 3);
	        graph.insert(2, 1);
	        graph.insert(2, 3);
	        graph.insert(3, 1);
	        graph.insert(3, 4);
	        graph.insert(3, 2);
	        graph.insert(4, 3);
	        graph.insert(4, 0);
	        graph.insert(4, 1);

	        graph.BFS_Traversal(1);
		
	}
	
}
