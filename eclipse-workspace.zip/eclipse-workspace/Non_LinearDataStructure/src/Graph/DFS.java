package Graph;
import java.util.*;
public class DFS {
		int numberOfVertices;
		LinkedList<Integer> arrayOfList[];
		
		DFS(int numberOfVertices){
			this.numberOfVertices = numberOfVertices;
			arrayOfList = new LinkedList[numberOfVertices];
			
			for(int i = 0 ; i < numberOfVertices ; i++) {
				arrayOfList[i] = new LinkedList<>();
			}
		}
		public void insert(int mainVertex,int subVertices) {
			arrayOfList[mainVertex].add(subVertices);
		}
		public void DFS_Traversal(int startVertex) {
			boolean visited[] = new boolean[numberOfVertices];
			Stack<Integer> stack = new Stack<>();
			
			stack.push(startVertex);
			visited[startVertex] = true;
			
			while(!stack.isEmpty()) {
				int vertex = stack.pop();
				System.out.print(vertex+ " ");
				Iterator<Integer> list = arrayOfList[vertex].listIterator();
						while(list.hasNext()) {
								int listElements = list.next();
								if(!visited[listElements]) {
									visited[listElements] = true;
									stack.push(listElements);
								}
								
						}
				}
	
		}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		DFS graph = new DFS(5);
		
        graph.insert(0, 1);
        graph.insert(0, 4);
        graph.insert(1, 0);
        graph.insert(1, 4);
        graph.insert(1, 2);
        graph.insert(1, 3);
        graph.insert(2, 1);
        graph.insert(2, 3);
        graph.insert(3, 1);
        graph.insert(3, 4);
        graph.insert(3, 2);
        graph.insert(4, 3);
        graph.insert(4, 0);
        graph.insert(4, 1);
       
        graph.DFS_Traversal(0);
	}

}
