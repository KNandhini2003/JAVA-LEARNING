package Graph;
import java.util.*;
public class DFS_MatrixImplement {

	int size;
	int matrix[][];
	DFS_MatrixImplement(int s){
		size = s;
		matrix = new int[size][size];
	}
	public void insert(int mainVertex,int subVertex) {
		if(mainVertex < 0 || subVertex < 0 ||
		   mainVertex > size || subVertex > size||
		   mainVertex == size || subVertex == size)
			return;
		matrix[mainVertex][subVertex] = 1;
			
	}
	public void DFS_Traversal(int startVertex) {
		if(startVertex == size || startVertex > size || startVertex < 0)
			return;
		Stack<Integer> stack = new Stack<Integer>();
		boolean visited[] = new boolean[size];
		stack.push(startVertex);
		visited[startVertex] = true;
		while(!stack.isEmpty()) {
			int i = stack.pop();
			System.out.print(i + " ");
			for(int j = 0 ; j < size ; j++) {
				if(matrix[i][j]==1 && !visited[j]) {
					visited[j] = true;
					stack.push(j);
				}
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DFS_MatrixImplement graph = new DFS_MatrixImplement(5);
		   graph.insert(0, 1);
	        graph.insert(0, 4);
	        graph.insert(1, 0);
	        graph.insert(1, 4);
	        graph.insert(1, 2);
	        graph.insert(1, 3);
	        graph.insert(2, 1);
	        graph.insert(2, 3);
	        graph.insert(3, 1);
	        graph.insert(3, 4);
	        graph.insert(3, 2);
	        graph.insert(4, 3);
	        graph.insert(4, 0);
	        graph.insert(4, 1);

	        graph.DFS_Traversal(1);
		
	
	}

}
