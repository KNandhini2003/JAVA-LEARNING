package Graph;

public class TopologicalSort1 {
	package Graph;
	import java.util.*;

	public class TopologicalSort {
	    int numberOfVertices;
	    int[][] topo;

	    // Constructor to initialize the graph with n vertices
	    TopologicalSort(int n) {
	        numberOfVertices = n;
	        topo = new int[numberOfVertices][numberOfVertices];
	    }

	    // Method to insert an edge from mainVertices to subVertices
	    public void insert(int mainVertices, int subVertices) {
	        if (mainVertices >= numberOfVertices || subVertices >= numberOfVertices ||
	            mainVertices < 0 || subVertices < 0) {
	            System.out.println("Invalid vertices");
	            return;
	        }
	        topo[mainVertices][subVertices] = 1;
	    }

	    // Method to display the adjacency matrix
	    public void display() {
	        for (int i = 0; i < numberOfVertices; i++) {
	            for (int j = 0; j < numberOfVertices; j++) {
	                System.out.print(topo[i][j] + " ");
	            }
	            System.out.println();
	        }
	    }

	    // Method to perform topological sort using Kahn's Algorithm
	    public void topoSort() {
	        int[] inDegree = new int[numberOfVertices];
	        Queue<Integer> queue = new LinkedList<>();
	        List<Integer> topoOrder = new ArrayList<>();

	        // Calculate in-degrees
	        for (int i = 0; i < numberOfVertices; i++) {
	            for (int j = 0; j < numberOfVertices; j++) {
	                if (topo[j][i] == 1) {
	                    inDegree[i]++;
	                }
	            }
	        }

	        // Add vertices with in-degree 0 to the queue
	        for (int i = 0; i < numberOfVertices; i++) {
	            if (inDegree[i] == 0) {
	                queue.add(i);
	            }
	        }

	        // Process the queue
	        while (!queue.isEmpty()) {
	            int vertex = queue.poll();
	            topoOrder.add(vertex);

	            for (int i = 0; i < numberOfVertices; i++) {
	                if (topo[vertex][i] == 1) {
	                    inDegree[i]--;
	                    if (inDegree[i] == 0) {
	                        queue.add(i);
	                    }
	                }
	            }
	        }

	        // Check for cycle
	        if (topoOrder.size() != numberOfVertices) {
	            System.out.println("The graph contains a cycle");
	            return;
	        }

	        // Print the topological order
	        System.out.println("Topological Order:");
	        for (int vertex : topoOrder) {
	            System.out.print(vertex + " ");
	        }
	        System.out.println();
	    }

	    public static void main(String[] args) {
	        TopologicalSort graph = new TopologicalSort(6);
	        graph.insert(5, 2);
	        graph.insert(5, 0);
	        graph.insert(4, 0);
	        graph.insert(4, 1);
	        graph.insert(2, 3);
	        graph.insert(3, 1);

	        graph.display();
	        graph.topoSort();
	    }
	}
