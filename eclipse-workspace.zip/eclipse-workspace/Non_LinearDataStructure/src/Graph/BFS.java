package Graph;
import java.util.*;
public class BFS {
	public  int numberOfVertices;
	public   LinkedList<Integer> arrayOfList[];
	
	BFS(int numberOfVertices){
		this.numberOfVertices = numberOfVertices;
		arrayOfList= new LinkedList[numberOfVertices];
		for(int i = 0 ; i < numberOfVertices ; i++) {
			arrayOfList[i] = new LinkedList<>();
		}
	}
		public  void insert(int mainVertices , int subVertices) {
			arrayOfList[mainVertices].add(subVertices);
		}
		public  void BFS_Traversal(int startVertices) {
			boolean visited[] = new boolean[numberOfVertices];
			Queue<Integer> queue = new LinkedList<>();
			
			queue.add(startVertices);
			visited[startVertices] = true;
			
			while(!queue.isEmpty()) {
				int QueueVertex = queue.poll();
				System.out.print(QueueVertex);
				Iterator<Integer> list = arrayOfList[QueueVertex].listIterator();
				while(list.hasNext()) {
					int listElement = list.next();
					if(!visited[listElement]) {
						visited[listElement] = true;
						queue.add(listElement);
					}
				}
			}
		}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  BFS graph = new BFS(5);

	        graph.insert(0, 1);
	        graph.insert(0, 4);
	        graph.insert(1, 0);
	        graph.insert(1, 4);
	        graph.insert(1, 2);
	        graph.insert(1, 3);
	        graph.insert(2, 1);
	        graph.insert(2, 3);
	        graph.insert(3, 1);
	        graph.insert(3, 4);
	        graph.insert(3, 2);
	        graph.insert(4, 3);
	        graph.insert(4, 0);
	        graph.insert(4, 1);

	        graph.BFS_Traversal(0);

	}

}
