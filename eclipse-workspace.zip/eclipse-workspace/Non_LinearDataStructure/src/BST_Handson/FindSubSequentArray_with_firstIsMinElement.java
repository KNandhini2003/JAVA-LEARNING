package BST_Handson;
import java.util.*;
public class FindSubSequentArray_with_firstIsMinElement {

	public static void main(String []args) {
		Scanner sc = new Scanner(System.in);
		int arr[] = { 1,2,3};
//		int arr[] = {1};
		int sum = 0;
		for(int i = 0 ; i < arr.length ; i++) {
			int c = 1;
			for(int j = i+1 ; j < arr.length ; j++) {
				if(arr[i] <= arr[j]) {
					c++;
				}
			}
			sum += c;
		}
		System.out.println(sum);
	
		int c = arr.length;
	for(int i = 0 ; i < arr.length-1 ; i++) {
		if(arr[i] <arr[i+1]) {
			c++;
		}
	}
	System.out.println(c);
	}
}
