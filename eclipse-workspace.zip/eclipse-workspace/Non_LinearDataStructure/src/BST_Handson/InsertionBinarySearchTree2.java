package BST_Handson;

import java.util.Scanner;


//import Binary
public class InsertionBinarySearchTree2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter no of elements:");
	BinarySearchTree tree = new 
			BinarySearchTree();
	int n = sc.nextInt();
	System.out.println("Create Binary Tree:");
	for(int i = 0 ; i < n ; i++) {
		tree.insert(sc.nextInt());
	}
	System.out.println("Enter a element to insert:");
	tree.insert(sc.nextInt());
	tree.levelOrderTraversal(tree.root);
	
	}
	

}
