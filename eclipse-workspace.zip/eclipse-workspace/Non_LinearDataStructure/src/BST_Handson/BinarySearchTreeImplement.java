package BST_Handson;

public class BinarySearchTreeImplement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	BinarySearchTree tree = new BinarySearchTree();
//	tree.insert(50);
//	tree.insert(30);
//	tree.insert(70);
//	tree.insert(20);
//	tree.insert(40);
//	tree.insert(60);
//	tree.insert(80);
//	tree.insert(10);
	tree.insert(10);
	tree.insert(20);
	tree.insert(30);
	tree.insert(40);
	tree.insert(50);
	tree.insert(60);
	tree.insert(70);
	tree.insert(80);
	System.out.println("\nInOrder:");
	tree.inOrderTraversal(tree.root);
	tree.delete(20);
	tree.delete(70);
	
	System.out.println("\nInOrder:");
	tree.inOrderTraversal(tree.root);
	
	System.out.println("\nPreOrder:");
	tree.preOrderTraversal(tree.root);
	
	System.out.println("\nPostOrder:");
	tree.postOrderTraversal(tree.root);
	System.out.println();
	}

}
