package BST_Handson;
import java.util.*;
public class ConsecutiveWordRemoval {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String arr = "ab aa aa bcd ab";
		String a[] = arr.split(" ");
		Stack<String> stack = new Stack<>();
		for(int i = 0 ; i < a.length ; i++) {
			if(!stack.isEmpty() && stack.peek() == a[i]) {
				
			}
			stack.add(a[i]);
		}
	}

}
