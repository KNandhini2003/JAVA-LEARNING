package BST_Handson;

import java.util.Scanner;

public class BST_Traversal4 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter no of elements:");
	BinarySearchTree tree = new 
			BinarySearchTree();
	int n = sc.nextInt();
	System.out.println("Create Binary Tree:");
	for(int i = 0 ; i < n ; i++) {
		tree.insert(sc.nextInt());
	}
	System.out.println("In-Order:");
	tree.inOrderTraversal(tree.root);
	System.out.println("\nPre-Order:");
	tree.preOrderTraversal(tree.root);
	System.out.println("\nPost-Order:");
	tree.postOrderTraversal(tree.root);
	}
}
