package BST_Handson;

public class StringCheckParentheses {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	String str = ")))(())";
	String str1 = "";
	String str2 = "";
	for(int i = 0 ; i < str.length() ; i++) {
		str1 = str.substring(0, i+1);
		str2 = str.substring(i+1 , str.length());
		if(open(str1) == close(str2)) {
			System.out.println(i+1);
			break;
		}
	}
	}
	public static int open(String str) {
		int count = 0;
		for(char c : str.toCharArray()) {
			if(c == '(')
				count++;
		}
		return count;
	}

	public static int close(String str) {
		int count = 0;
		for(char c : str.toCharArray()) {
			if(c == ')')
				count++;
		}
		return count;
	}
	

}
