package BST_Handson;

import java.util.Scanner;

public class MinimumElementBST7 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter no of elements:");
		BinarySearchTree tree = new 
				BinarySearchTree();
		int n = sc.nextInt();
		System.out.println("Create Binary Tree:");
		for(int i = 0 ; i < n ; i++) {
			tree.insert(sc.nextInt());
		}
		System.out.println(tree.findMin());
	}
	
	
}
