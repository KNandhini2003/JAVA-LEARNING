package BST_Handson;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class CheckBinaryTreeIsBSTOrNot {
	public static void main(String [] args) {
	Scanner sc = new Scanner(System.in);
	/*System.out.println("Enter no of elements:");
	BinaryTreeStructure.BinaryTree tree = new 
			BinaryTreeStructure.BinaryTree();
	int n = sc.nextInt();
	System.out.println("Create Binary Tree:");
	for(int i = 0 ; i < n ; i++) {
		tree.insertLevelOrder(sc.nextInt());
	}
	*/
	BinarySearchTree tree1 = new 
			BinarySearchTree();

	tree1.root = new Node(2);
	tree1.root.left = new Node(1);
	tree1.root.right = new Node(3);
	tree1.root.right.right = new Node(5);
	System.out.println(tree1.checkBalanceBST(tree1.root));
	 
	tree1.root = new Node(2);
	tree1.root.right = new Node(7);
	tree1.root.right.right = new Node(6);
	tree1.root.right.right.right = new Node(9);
	System.out.println(tree1.checkBalanceBST
			(tree1.root));
	 
	}
}


