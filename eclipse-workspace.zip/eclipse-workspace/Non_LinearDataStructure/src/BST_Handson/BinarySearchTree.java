package BST_Handson;
import java.util.Stack;

import BinaryTreeStructure.BinaryTree;

import java.util.*;
import java.util.Queue;
class Node{
	int key;
	public Node left,right;
	Node(int key){
		this.left = null;
		this.key= key;
		this.right = null;		
	}
}
public class BinarySearchTree {
	public Node root;
	public Node createNode(int key) {
		return new Node(key);
	}
	
	public void insert(int key) {
		Node newNode = createNode(key);
		if(root == null) {
			root = newNode;
			return;
		}
		Node currentRoot = root;
		while(true) {
			if(key < currentRoot.key ) {
				if(currentRoot.left == null) {
					currentRoot.left = newNode;
					return;
				}
				else
					currentRoot = currentRoot.left;
			}
			else {
				if(currentRoot.right == null) {
					currentRoot.right = newNode;
					return;
				}
				else
					currentRoot = currentRoot.right;
			}
		}
	}
	public void inOrderTraversal(Node root) {
		if(root != null) {
			inOrderTraversal(root.left);
			System.out.print(root.key + " ");
			inOrderTraversal(root.right);
		}
	}
	public void preOrderTraversal(Node root) {
		if(root != null) {
			System.out.print(root.key + " ");
			preOrderTraversal(root.left);
			preOrderTraversal(root.right);
		}
	}
	public void postOrderTraversal(Node root) {
		if(root != null) {
				postOrderTraversal(root.left);
				postOrderTraversal(root.right);
				System.out.print(root.key + " ");
		}
	}
	
	public void delete(int key) {
		if(root == null)
			return;
		Node parent = null;
		Node current = root;
		while(current != null && current.key != key) {
			parent = current;
			if(key < current.key)
				current = current.left;
			else
				current = current.right;
		}//We found the node
		if(current == null)
			return ;//no key found
		
		//leaf node
		if(current.left == null && current.right == null) {
			if(current == root)
				root = null;
			else {
				if(parent.left == current) {
					parent.left = null;
				}
				else {
					parent.right = null;
				}
			}
		}
		//leaf Node
		
		//Single Child
		else if(current.left == null || current.right == null) {
			Node child = (current.left !=  null)  ? 
					current.left : current.right;
			if(current == root) {
				root = child;
			}
			else {
				if(parent.left == current)
					parent.left = child;
				else
					parent.right = child;
			}
		}
		//Single Child
		//Two Children
		else {
			Node successor = findMin(current.right);
			current.key = successor.key;
			delete(successor.key);
		}
		
		//Two Children
		
	}
	public Node findMin(Node node) {
		Node current = node;
		while(current.left != null) {
			current = current.left;
		}
		return current;
	}
	
	public boolean search(int key) {
	    Node cur = root;
	    while (cur != null) {
	        if (key < cur.key) {
	            cur = cur.left;
	        } else if (key > cur.key) {
	            cur = cur.right;
	        } else {
	            return true; 
	        }
	    }
	    return false;
	}
	  public Node searchNode(int key) {
	        Node current = root;
	        while (current != null) {
	            if (key == current.key) {
	                return current;
	            } else if (key < current.key) {
	                current = current.left;
	            } else {
	                current = current.right;
	            }
	        }
	        return null;
	    }

    public void levelOrderTraversal(Node root) {
        if (root == null)
            return;
        Queue<Node> queue = new LinkedList<>();
        queue.add(root);
        while (!queue.isEmpty()) {
            Node temp = queue.poll();
            System.out.print(temp.key + " ");
            if (temp.left != null) {
                queue.add(temp.left);
            }
            if (temp.right != null) {
                queue.add(temp.right);
            }
        }
    }
  
    public int findMin() {
        if (root == null) {
           return -1;
        }
        Node current = root;
        while (current.left != null) {
            current = current.left;
        }
        return current.key;
    }

    public int findMax() {
        if (root == null) {
            return -1;
        }
        Node current = root;
        while (current.right != null) {
            current = current.right;
        }
        return current.key;
    }
   /* public int kThLargestElement(int k) {
        if (root == null) {
            return -1;
        }
        
        Stack<Node> stack = new Stack<>();
        Node current = root;
        int count = 0;

        while (!stack.isEmpty() || current != null) {
             while (current != null) {
                stack.push(current);
                current = current.right;
            }

             current = stack.pop();
            count++;

             if (count == k) {
                return current.key;
            }
             current = current.left;
        }

        return -1; 
        }
        */
    
    
    private void inorderTraversal(Node root, 
    		List<Integer> result) {
        if (root == null) return;
        inorderTraversal(root.left, result);
        result.add(root.key);
        inorderTraversal(root.right, result);
    }

    // Function to find the median of the BST
    public int findMedianOfBST(Node root) {
        List<Integer> sortedValues =
        		new ArrayList<>();
        inorderTraversal(root, sortedValues);
        
        int n = sortedValues.size();
        if (n % 2 == 1) {
            // If odd, return the middle element
            return sortedValues.get(n / 2);
        } else {
            // If even, return the average of the two middle elements
            int mid1 = sortedValues.get(n / 2 - 1);
            int mid2 = sortedValues.get(n / 2);
            return (mid1 + mid2) / 2; // Ensure average is an integer
        }
    }
  /*  public void makeBalance(BinaryTree n) {
    	if(n == null)
    		return;
    	Node node = nzzzzzzzzzzzzzzzzzzzz;
//    	BinarySearchTree t = new BinarySearchTree();
    	ArrayList<Integer> arr = new ArrayList<Integer>();
//    	Node newNode = node;
    	while(node != null) {
    		if(node.left != null) {
    			arr.add(node.left.key);
    			node = node.left;
    		}
    		if(node.right != null) {
    			arr.add(node.right.key);
    			node = node.right;
    		}
    	}
    	for(int i : arr) {
    		insert(i);
    	}
    	
    }
    public static boolean isBST(Node node) {
        return isBSTUtil(node, Integer.MIN_VALUE, Integer.MAX_VALUE);
    }

    private static boolean isBSTUtil(Node node, int min, int max) {
       
        if (node == null) {
            return true;
        }
        if (node.key <= min || node.key >= max) {
            return false;
        }

        // Otherwise check the subtrees recursively tightening the min/max constraints
        return isBSTUtil(node.left, min, node.key) 
        		&& isBSTUtil(node.right, node.key, max);
    }
    */
    /* public boolean checkBinaryTree(Node node) {
   	Node cur = node;
    	if(cur == null)
    		return true;
    	while(cur != null) {
    		if(cur.left!=null &&  cur.left.key > node.key ) {
    			return false;
    		}
    		
    		else if( cur.right != null && 
    				cur.right.key < node.key) {
    			return false;
    		}
    		else {
    			cur = cur.left;
    			cur = cur.right;
    		}
    	}
    	return true;
    }
    }
    */
    public boolean checkBalanceBST(Node node) {
    	ArrayList<Integer> a = new
    			ArrayList<Integer>();
    	inOrder(node,a);
    	ArrayList<Integer> b = (ArrayList)a.clone();
    	Collections.sort(a);
//    	System.out.println(a);
//    	
//    	System.out.println(b);
    	
    	for(int i = 0 ; i < a.size() ; i++) {
    		if(a.get(i) != b.get(i))
    			return false;
    	}
    	return true;
    }
    public void inOrder
    (Node node , ArrayList<Integer> arr) {
    	if(node == null) {
    		return ;
    	}
    	inOrder(node.left,arr);
    	arr.add(node.key);
    	inOrder(node.right,arr);
    	
    }
    public int size(Node node) {
    	Node cur = node;
    	int c = 0;
    	while(cur.left != null) {
    		c++;
    		cur = cur.left;
    	}
    	cur = node.right;
    	while( cur.right != null) {
    		c++;
    		cur = cur.right;
    	}
    	return c;
    }
    public int kThLargestElement(Node root , int k) {
    	ArrayList<Integer> l = new
    			ArrayList<Integer>();
    	inOrder(root,l);
     return l.get(l.size() - k);
    }
    public int median(Node root ) {
    	ArrayList<Integer> l = 
    			new ArrayList<>();
    	inOrder(root,l);
    	int mid = l.size()/2;
    	if(l.size() % 2 == 0) {
    		return (l.get(mid ) + l.get(mid-1))/2;
    	}
    	else {
    		return l.get(mid);
    	}
//    	
    }
    public Node makeBalanceBST(ArrayList<Integer> arr,
    		int start , int end) {
    	if(start > end)
    		return null;
    	int mid = start + (end - start)/2;
    	Node newNode = new Node(arr.get(mid));
    	newNode.left = makeBalanceBST(arr,start,mid-1);
    	newNode.right = makeBalanceBST(arr,mid+1,end);
    	return newNode;
    }
    public void buildBalanceTree(Node root) {
    	ArrayList<Integer> arr = new 
    			ArrayList<Integer>();
    	inOrder(root,arr);
    	Node balanceTree = makeBalanceBST
    			(arr,0,arr.size()-1);
    	levelOrderTraversal(balanceTree);
    }
    public void left(Node root1) {
    	Node root = root1;
    	while(root.left != null) {
    		System.out.print(root.left + " ");
    		root = root.left;
    	}
    }
    public void symmetric(Node root) {
        if (root == null)
            return;
        Queue<Node> queue = new LinkedList<>();
        queue.add(root.left);
        queue.add(root.right);
        Node temp = root;
        while (!queue.isEmpty()) {
          
            if (temp.left != null) {
                queue.add(temp.left);
            }
            if (temp.right != null) {
                queue.add(temp.right);
            }
        }
    }
 
 
}




