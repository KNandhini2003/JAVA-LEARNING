package BST_Handson;

public class NormalBST_BalancedBST {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BinarySearchTree tree = new BinarySearchTree();
		/*tree.root = new Node(30);
		tree.root.left = new Node(20);
		tree.root.left.left = new Node(10);
		tree.buildBalanceTree(tree.root);*/
		
		tree.root = new Node(4);
		tree.root.left = new Node(3);
		tree.root.left.left = new Node(2);
		tree.root.left.left.left = new Node(1);
		
		tree.buildBalanceTree(tree.root);
		
	}

}
