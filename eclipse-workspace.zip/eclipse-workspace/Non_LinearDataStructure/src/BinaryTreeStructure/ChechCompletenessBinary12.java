package BinaryTreeStructure;

import java.util.Scanner;

public class ChechCompletenessBinary12 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter no of elements:");
		BinaryTree tree = new BinaryTree();
		int n = sc.nextInt();
		System.out.println("Create Binary Tree:");
		for(int i = 0 ; i < n ; i++) {
			tree.insertLevelOrder(sc.nextInt());
		}
		tree.binaryTreePath(tree.root);
		tree.isCompleteBinaryTree(tree.root);
		
	}
}
