package BinaryTreeStructure;

import java.util.*;
public class StringPermutation {

	    public static void main(String[] args) {
	        String input = "AB"; // Example input
	        generatePermutations(input);
	    }

	    public static void generatePermutations(String string) {
	        ArrayList<String> permutations = new ArrayList<>();
	        int length = string.length();

	        // Generate all combinatio3ns of length 1 to n
	        for (int i = 1; i <= length; i++) {
	            generateCombinations(string, "", i, permutations);
	        }

	        // Print the results
	        for (String perm : permutations) {
	            System.out.print(perm + " ");
	        }
	    }
	    //A AA AAA AAB AAC AB ABA ABB ABC AC ACA ACB ACC B BA BAA BAB BAC BB BBA BBB BBC 
//	    BC BCA BCB BCC C CA CAA CAB CAC CB CBA CBB CBC CC CCA CCB CCC 
	    public static void generateCombinations(String string, String prefix,
	    		int length, ArrayList<String> permutations) {
	        if (length == 0) {
	            permutations.add(prefix);
	            System.out.println(permutations);
	            return;
	        }

	        for (int i = 0; i < string.length(); i++) {
	            generateCombinations(string, prefix + string.charAt(i), length - 1, permutations);
	            System.out.println(prefix);
	        }
	    }
	}
