package BinaryTreeStructure;

import java.util.Scanner;

public class BalancedBinaryTree {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter number of elements:");
        int n = sc.nextInt();
        sc.nextLine();  
        System.out.println("Create Binary Tree:");
        String input = sc.nextLine();
        String[] values = input.split(",");

        BinaryTree tree = new BinaryTree();
        for (String value : values) {
            value = value.trim();
            if (!value.equals("null")) {
                tree.insertLevelOrder(Integer.parseInt(value));
            }
        }

        System.out.println(tree.isBalanced(tree.root));
    }
}
