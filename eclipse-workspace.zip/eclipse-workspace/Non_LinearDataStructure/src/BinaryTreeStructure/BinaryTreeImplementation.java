package BinaryTreeStructure;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;


public class BinaryTreeImplementation {

	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Queue<Integer> q = new LinkedList<Integer>();
       
        System.out.println("Enter 1 for insertion:");
        System.out.println("Enter 2 for InOrder Traversal:");
        System.out.println("Enter 3 for PreOrder Traversal:");
        System.out.println("Enter 4 for PostOrder Traversal:");
        System.out.println("Enter 5 for LevelOrder Traversal:");
        System.out.println("Enter 6 to search an element:");
        System.out.println("Enter 7 to Exist:");
        boolean found1 = true;
        BinaryTree tree = new BinaryTree();
        while (found1) {
            System.out.println("Enter the option:");
            int option = sc.nextInt();
            switch (option) {
                case 1:
                    System.out.println("Enter a value to insert:");
                    tree.insertLevelOrder(sc.nextInt());
                    break;
                case 2:
                    if (tree.root == null) {
                        System.out.println("Tree is empty.");
                    } else {
                        System.out.println("InOrder Traversal:");
                        tree.inOrderTraversal(tree.root);
                        System.out.println();
                    }
                    break;
                case 3:
                    if (tree.root == null) {
                        System.out.println("Tree is empty.");
                    } else {
                        System.out.println("PreOrder Traversal:");
                        tree.preOrderTraversal(tree.root);
                        System.out.println();
                    }
                    break;
                case 4:
                    if (tree.root == null) {
                        System.out.println("Tree is empty.");
                    } else {
                        System.out.println("PostOrder Traversal:");
                        tree.postOrderTraversal(tree.root);
                        System.out.println();
                    }
                    break;
                case 5:
                    if (tree.root == null) {
                        System.out.println("Tree is empty.");
                    } else {
                        System.out.println("LevelOrder Traversal:");
                        tree.levelOrderTraversal(tree.root);
                        System.out.println();
                    }
                    break;
                case 6:
                    System.out.println("Enter a value to search:");
                    int searchValue = sc.nextInt();
                    boolean found = tree.search(tree.root, searchValue);
                    if (found) {
                        System.out.println(searchValue + " is found in the tree.");
                    } else {
                        System.out.println(searchValue + " is not found in the tree.");
                    }
                    break;
                case 7:
                	found1 = false;
                	break;
                default:
                    System.out.println("Invalid option. Please enter a valid option.");
                    break;
                    
            }
        }
    }
}