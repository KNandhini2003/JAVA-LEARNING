package BinaryTreeStructure;

import java.util.Scanner;

public class FullBinaryTree11 {
	 public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);
	        System.out.println("Enter number of elements:");
	        BinaryTree tree = new BinaryTree();
	        int n = sc.nextInt();
	        sc.nextLine();
	        System.out.println("Create Binary Tree:");
	        for (int i = 0; i < n; i++) {
	            String value = sc.next();
	            if (value.equals("null")) {
	                continue;
	            } else {
	                tree.insertLevelOrder(Integer.parseInt(value));
	            }
	        }
	        System.out.println("Full Binary Tree"
	        		+ ":"+ (tree.isFullBinaryTree(tree.root)?1:0));
	 }
}
