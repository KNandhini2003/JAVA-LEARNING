package BinaryTreeStructure;
import java.util.*;


public class BinaryTree{
   
	public class Node {
	    int key;
	    Node left;
	    Node right;

	    Node(int key) {
	        this.key = key;
	        this.left = null;
	        this.right = null;
	    }
//	    public getleft(int key) {
//	    	return left;
//	    }
	}
	
	Node root;
    public Node createNode(int key) {
		return new Node(key);
	}
	
    public Node insertLevelOrder(int key) {
        if (root == null) {
            root = new Node(key);
            return root;
        }
        Queue<Node> queue = new LinkedList<>();
        queue.add(root);
        while (!queue.isEmpty()) {
            Node temp = queue.poll();
            if (temp.left == null) {
                temp.left = new Node(key);
                return root;  
            } else {
                queue.add(temp.left);
            }
            if (temp.right == null) {
                temp.right = new Node(key);
                return root; 
            } else {
                queue.add(temp.right);
            }
        }
        return root;
    }

    public void inOrderTraversal(Node root) {
        if (root != null) {
            inOrderTraversal(root.left);
            System.out.print(root.key + " ");
            inOrderTraversal(root.right);
        }
    }

    public void preOrderTraversal(Node root) {
        if (root != null) {
            System.out.print(root.key + " ");
            preOrderTraversal(root.left);
            preOrderTraversal(root.right);
        }
    }

    public void postOrderTraversal(Node root) {
        if (root != null) {
            postOrderTraversal(root.left);
            postOrderTraversal(root.right);
            System.out.print(root.key + " ");
        }
    }

    public boolean search(Node root, int searchData) {
        if (root == null)
            return false;
        if (root.key == searchData)
            return true;
        return search(root.left, searchData) || search(root.right, searchData);
    }

    public void levelOrderTraversal(Node root) {
        if (root == null)
            return;
        Queue<Node> queue = new LinkedList<>();
        queue.add(root);
        while (!queue.isEmpty()) {
            Node temp = queue.poll();
            System.out.print(temp.key + " ");
            if (temp.left != null) {
                queue.add(temp.left);
            }
            if (temp.right != null) {
                queue.add(temp.right);
            }
        }
    }

    public void depthElementOfTree(Node root) {
        if (root == null)
            return;
        Queue<Node> queue = new LinkedList<>();
        queue.add(root);
        Node temp = null;
        while (!queue.isEmpty()) {
            temp = queue.poll();
            if (temp.left != null) {
                queue.add(temp.left);
            }
            if (temp.right != null) {
                queue.add(temp.right);
            }
        }
        if (temp != null) {
            System.out.print(temp.key);
        }
    }

    public void deleteNode(Node root, int key) {
        if (root == null)
            return;
        Queue<Node> queue = new LinkedList<>();
        queue.add(root);
        Node temp = null;
        Node keyNode = null;
        while (!queue.isEmpty()) {
            temp = queue.poll();
            if (temp.key == key)
                keyNode = temp;
            if (temp.left != null)
                queue.add(temp.left);
            if (temp.right != null)
                queue.add(temp.right);
        }

        // keyNode is found
        if (keyNode != null) {
            if (keyNode.left == null && keyNode.right == null) {
                // case1: leaf node deletion
                deleteLeafNode(root, keyNode);
            } else if (keyNode.left != null && keyNode.right != null) {
                // case2: Node has two children
                int deepestNode = temp.key;
                deleteLeafNode(root, temp);
                keyNode.key = deepestNode;
            } else {
                // case3: node has one child
                if (keyNode.left != null) {
                    replaceNodeWithChild(root, keyNode, keyNode.left);
                } else {
                    replaceNodeWithChild(root, keyNode, keyNode.right);
                }
            }
        }
    }

    public void replaceNodeWithChild(Node root, Node deleteNode, Node child) {
        if (root == deleteNode) {
            root.key = child.key;
            root.left = child.left;
            root.right = child.right;
            return;
        }
        Queue<Node> queue = new LinkedList<>();
        queue.add(root);
        Node temp;
        while (!queue.isEmpty()) {
            temp = queue.poll();
            if (temp.left != null) {
                if (temp.left == deleteNode) {
                    temp.left = child;
                    return;
                }
                queue.add(temp.left);
            }
            if (temp.right != null) {
                if (temp.right == deleteNode) {
                    temp.right = child;
                    return;
                }
                queue.add(temp.right);
            }
        }
    }

    public void deleteLeafNode(Node root, Node deleteNode) {
        if (root == deleteNode) {
            root = null;
            return;
        }
        Queue<Node> queue = new LinkedList<>();
        queue.add(root);
        Node temp = null;
        while (!queue.isEmpty()) {
            temp = queue.poll();
            if (temp.left != null) {
                if (temp.left == deleteNode) {
                    temp.left = null;
                    return;
                }
                queue.add(temp.left);
            }
            if (temp.right != null) {
                if (temp.right == deleteNode) {
                    temp.right = null;
                    return;
                }
                queue.add(temp.right);
            }
        }
    }
    public void binaryTreePath(Node root) {
        if (root == null)
            return;
        Queue<Node> queue = new LinkedList<>();
        queue.add(root);
        String l = "";
       l = l + queue.peek().key + " ";
        String r = "";
        r = r + queue.peek().key + " ";
        Node temp = null;
        while (!queue.isEmpty()) {
            temp = queue.poll();
            if (temp.left != null) {
                queue.add(temp.left);
                l = l + temp.left.key + " ";
            }
            if (temp.right != null) {
                queue.add(temp.right);
                r = r + temp.right.key + " ";
            }
        }
        l = l.replace(" " , "->");
        r = r.replace(" ", "->");
        System.out.println("Left path: " + l);
        System.out.println("Right path: " + r);
    }
    public int height(Node root) {
    	//height : node to leaf
    	if(root == null) {
    		return 0;
    	}
    		int leftHeight = height(root.left);
    		int rightHeight = height(root.right);
    		return Math.max(leftHeight,rightHeight) + 1;
      }
    public int maxDepth(Node root) {
    	if(root == null) {
    		return 0;
    	}
    	int leftTree = maxDepth(root.left);
    	int rightTree = maxDepth(root.right);
    	return Math.max(leftTree,rightTree)+1;
    }
    public int findMax(Node root) {
        if (root == null) {
            return Integer.MIN_VALUE;
        }
        int max = root.key;
        int leftMax = findMax(root.left);
        int rightMax = findMax(root.right);
        if (leftMax > max) {
            max = leftMax;
        }
        if (rightMax > max) {
            max = rightMax;
        }
        return max;
    }

    public int findMin(Node root) {
        if (root == null) {
            return Integer.MAX_VALUE;
        }
        int min = root.key;
        int leftMin = findMin(root.left);
        int rightMin = findMin(root.right);
        if (leftMin < min) {
            min = leftMin;
        }
        if (rightMin < min) {
            min = rightMin;
        }
        return min;
    }
    public boolean isFullBinaryTree(Node root) {
        // An empty tree is considered a full binary tree
        if (root == null) {
            return true;
        }

        // If leaf node, it's a full binary tree
        if (root.left == null && root.right == null) {
            return true;
        }

        // If both left and right are not null, and
        // both left and right subtrees are full binary trees
        if (root.left != null && root.right != null) {
            return isFullBinaryTree(root.left) && isFullBinaryTree(root.right);
        }

        return false;
    }

    public boolean isCompleteBinaryTree(Node root) {
        if (root == null) {
            return true;
        }

        Queue<Node> queue = new LinkedList<>();
        queue.add(root);
        boolean end = false; // flag to indicate the encounter of the first missing child

        while (!queue.isEmpty()) {
            Node currentNode = queue.poll();

            if (currentNode == null) {
                end = true; // after encountering a null, all subsequent nodes should also be null
            } else {
                if (end) {
                    return false; // if we encounter a non-null node after a null node, it's not complete
                }

                queue.add(currentNode.left);
                queue.add(currentNode.right);
            }
        }

        return true;
    }
    public boolean isBalanced(Node root) {
    	if(root == null)
    		return true;
    	if(Math.abs(height(root.left) - height(root.right)) > 1)
    		return false;
    	return isBalanced(root.left) && isBalanced(root.right);
    	
    }
    int calculateRightDepth(Node node) {
        int depth = 0;
        while (node != null) {
            depth++;
            node = node.right;
        }
        return depth;
    }
    int calculateLeftDepth(Node node) {
        int depth = 0;
        while (node != null) {
            depth++;
            node = node.left;
        }
        return depth;
    }
    boolean isPerfectBinaryTree(Node root) {
        if (root == null) {
            return true;
        }
        int leftDepth = calculateLeftDepth(root);
        int rightDepth = calculateRightDepth(root);
        return leftDepth == rightDepth;
    }
    
    public boolean symmetryCheck(Node n1 ,Node n2) {
    	if(n1 == null && n2 == null)
    		return true;
    	if(n1 != null && n2 != null && n1.key == n2.key) {
    		return symmetryCheck(n1.left , n2.right) && symmetryCheck(n1.right ,n2.left);
    	}
    	return false;
    }
    
}
























