package BinaryTreeStructure;

 class Node2 {
    int key;
    Node2 left;
    Node2 right;

    Node2(int key) {
        this.key = key;
        this.left = null;
        this.right = null;
    }
}

public class UnbalancedBinaryTreeCreation {

    public Node2 root;

      public void insertUnbalanced(Node2 parent, int key, boolean isLeft) {
        if (parent == null) {
            root = new Node2(key);
        } else if (isLeft) {
            parent.left = new Node2(key);
        } else {
            parent.right = new Node2(key);
        }
    }

    public void inOrderTraversal(Node2 root) {
        if (root != null) {
            inOrderTraversal(root.left);
            System.out.print(root.key + " ");
            inOrderTraversal(root.right);
        }
    }

    public boolean isBalanced(Node2 root) {
        if (root == null) {
            return true;
        }
        if (Math.abs(height(root.left) - height(root.right)) > 1) {
            return false;
        }
        return isBalanced(root.left) && isBalanced(root.right);
    }

    public int height(Node2 root) {
        if (root == null) {
            return 0;
        }
        int leftHeight = height(root.left);
        int rightHeight = height(root.right);
        return Math.max(leftHeight, rightHeight) + 1;
    }
    public static void main(String[] args) {
    	UnbalancedBinaryTreeCreation tree =
    			new UnbalancedBinaryTreeCreation();
        
        // Manually create an unbalanced tree
        tree.root = new Node2(1);                // root
        tree.insertUnbalanced(tree.root, 2, true);   // left child of root
        tree.insertUnbalanced(tree.root, 3, false);  // right child of root
        tree.insertUnbalanced(tree.root.left, 4, true); // left child of node 2
        tree.insertUnbalanced(tree.root.left, 5, false); // right child of node 2
        tree.insertUnbalanced(tree.root.right, 6, true); // left child of node 3

        // Further unbalancing by adding more nodes to the left side
        tree.insertUnbalanced(tree.root.left.left, 7, true); // left child of node 4
        tree.insertUnbalanced(tree.root.left.left.left, 8, true); // left child of node 7

        // The resulting tree is unbalanced as the left subtree is deeper than the right subtree
        System.out.println("In-order traversal of the unbalanced tree:");
        tree.inOrderTraversal(tree.root);
        System.out.println();
        
        System.out.println("Is the tree balanced? " + tree.isBalanced(tree.root));
    }

}
