/*package BinaryTreeStructure;

import java.util.*;

class Node1 {
    int key;
    Node1 left, right;

    Node1(int key) {
        this.key = key;
        this.left = null;
        this.right = null;
    }
}

public class SizeOfBinaryTree5 {
    Node1 root;

    public void insertLevelOrder(int key) {
        Node1 newNode1 = new Node1(key);
        if (root == null) {
            root = newNode1;
            return;
        }

        Queue<Node1> queue = new LinkedList<>();
        queue.add(root);

        while (!queue.isEmpty()) {
            Node1 temp = queue.poll();

            if (temp.left == null) {
                temp.left = newNode1;
                return;
            } else {
                queue.add(temp.left);
            }

            if (temp.right == null) {
                temp.right = newNode1;
                return;
            } else {
                queue.add(temp.right);
            }
        }
    }

    public int countNodes(Node1 root) {
        if (root == null) {
            return 0;
        }

        Queue<Node1> queue = new LinkedList<>();
        queue.add(root);
        int count = 0;

        while (!queue.isEmpty()) {
            Node1 temp = queue.poll();
            count++;

            if (temp.left != null) {
                queue.add(temp.left);
            }

            if (temp.right != null) {
                queue.add(temp.right);
            }
        }

        return count;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter number of elements:");
        SizeOfBinaryTree5 tree = new SizeOfBinaryTree5();
        int n = sc.nextInt();
        sc.nextLine(); // Consume the remaining newline character
        System.out.println("Create Binary Tree:");
        for (int i = 0; i < n; i++) {
            String value = sc.next();
            if (value.equals("N")) {
                continue;
            } else {
                tree.insertLevelOrder(Integer.parseInt(value));
            }
        }

         int count = tree.countNodes(tree.root);
        System.out.println("Number of nodes in the tree: " + count);
    }

}
*/