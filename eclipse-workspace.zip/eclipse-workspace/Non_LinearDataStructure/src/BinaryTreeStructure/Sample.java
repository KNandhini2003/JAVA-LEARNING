//package BinaryTreeStructure;
//
//public class Sample {
//	public static void main(String [] args) {
//		int i;
//		i = 10;
//		if(i == 20 || 30)
//		{
//			System.out.println("True");
//		}
//		else
//		{
//			System.out.println("False");
//		}
//	
//}
//}
