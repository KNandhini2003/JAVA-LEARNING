package BinaryTreeStructure;

import java.util.Scanner;

public class TreeTraversal3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter no of elements:");
		BinaryTree tree = new BinaryTree();
		int n = sc.nextInt();
		System.out.println("Create Binary Tree:");
		for(int i = 0 ; i < n ; i++) {
			tree.insertLevelOrder(sc.nextInt());
		}
		System.out.println("InOrder:");
		tree.inOrderTraversal(tree.root);
		System.out.println("\nPreOrder:");
		tree.preOrderTraversal(tree.root);
		System.out.println("\nPostOrder:");
		tree.postOrderTraversal(tree.root);
		
	}

}
