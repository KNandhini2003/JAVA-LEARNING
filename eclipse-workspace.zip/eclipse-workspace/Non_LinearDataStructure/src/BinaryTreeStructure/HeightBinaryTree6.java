package BinaryTreeStructure;

import java.util.Scanner;

public class HeightBinaryTree6 {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter number of elements:");
        BinaryTree tree = new BinaryTree();
        int n = sc.nextInt();
        sc.nextLine(); 
        System.out.println("Create Binary Tree:");
        for (int i = 0; i < n; i++) {
            int value = sc.nextInt();
            if (value == -1) {
                continue;
            } else {
                tree.insertLevelOrder(value);
            }
        }

         int h = tree.height(tree.root);
        System.out.println("height of tree: " + h);
        sc.close();
	}
}
