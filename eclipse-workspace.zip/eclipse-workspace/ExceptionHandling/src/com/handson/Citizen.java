package com.handson;
import java.util.*;
class NoMatchException extends Exception {  
	
	NoMatchException(String s) {  
		super(s);  
	}  
	
} 
public class Citizen{  
  static void validate(String country)throws NoMatchException {  
  if(!country.equalsIgnoreCase("india"))
		  throw new NoMatchException("not eligible");  
  else  
   System.out.println("Eligible");  
}      
  public static void main(String args[]) {  
	  
      try {
    	  
    	Scanner input = new Scanner(System.in); 
    	System.out.println("Enter a aadhar number:");
    	int num = input.nextInt();
    	System.out.println("Enter a name:");
    	String name = input.next();
      	System.out.println("Enter a country:");
    	String country = input.next();

		validate(country);  
    	System.out.println("Enter a city:");
    	String city = input.next();
  
    	
      }
     
	  catch(Exception m) {
		System.out.println("Exception occured: "+m);
	  }  
  
      System.out.println("Visit India");  
  }  
} 
