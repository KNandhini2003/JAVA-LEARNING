/*Accept Username and password values from the User . Throw user defined exceptions – “InvalidUsernameException” or “InvalidPasswordException” if the username and password are invalid .
Please check with Stored username and password for validity.
If valid, print a message “Welcome ‘username’, else print a message Invalid username or password.
A username is considered valid if all the following constraints are satisfied:
a)  	The username consists of 6 to 30 characters inclusive. If the username
consists of less than 6 or greater than 30 characters, then it is an invalid username.
b) 	The username can only contain alphanumeric characters and underscores (_). Alphanumeric characters describe the character set consisting of lowercase characters [a – z], uppercase characters [A – Z], and digits [0 – 9].
c)  	The first character of the username must be an alphabetic character, i.e., either lowercase character [a – z] or uppercase character [A – Z].
A password is considered valid if all the following constraints are satisfied:
a)  	It contains at least one lowercase English character.
b) 	It contains at least one uppercase English character.
c)  	It contains at least one special character. The special characters are: !@#$%^&*()-+
d) 	Its length is at least 8.
e)   	It contains at least one digit.

*/

package com.handson;

import java.util.Scanner;

class InvalidUsernameException extends Exception{
	InvalidUsernameException(String s){
		super(s);
	}
}
class InvalidPasswordException extends Exception{
	InvalidPasswordException(String s){
		super(s);
	}
}

public class User {
		
		public static void validateN(String name ) 
				throws InvalidUsernameException {
			if(name.length() < 6 || name.length () > 30 )
				throw new InvalidUsernameException("Invalid UserName");
			if(!Character.isAlphabetic(name.charAt(0)))
				throw new InvalidUsernameException("Start with Alpabet");
			 if (!name.matches("[a-zA-Z0-9_]+")) {
	            throw new InvalidUsernameException("not valid.");
	        }	
		    else {
		    	System.out.println("Welcome "+ name +"!!!");
		    }
		}
		
		public static void validateP(String password ) 
				throws InvalidPasswordException {
			
		    if (password.length() < 8) {
	            throw new InvalidPasswordException(" at least 8 characters.");
	        }
	        if (!password.matches(".*[a-z].*")) {
	            throw new InvalidPasswordException("contain at least one lowercase letter.");
	        }
	        if (!password.matches(".*[A-Z].*")) {
	            throw new InvalidPasswordException("contain at least one uppercase letter.");
	        }
	        if (!password.matches(".*[0-9].*")) {
	            throw new InvalidPasswordException("contain at least one digit.");
	        }
	        if (!password.matches(".*[!@#$%^&*()\\-+].*")) {
	            throw new InvalidPasswordException("contain at least one special character.");
	        }
		}

	public static void main(String [] args) {
		try {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter a Username:");
		String name = input.next();
		validateN(name);
		System.out.println("Enter a Password:");
		String password = input.next();
		validateP(password);
		input.close();
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
	}
}
