/*
Create a calculator Application which does basic operations 
like addition, subtraction, multiplication and division with  the following criteria 
a. Input must be in number format. No character or  string inputs are not accepted. 
b. For division, denominator should not be zero. c.
For multiplication, multiplier and multiplicand  should not be 0 or 1. 
Create user defined exceptions wherever it is  necessary and handle it appropriately.
*/

package com.handson;

import java.util.Scanner;

class MultiplicationException extends Exception {
    MultiplicationException(String s) {
        super(s);
    }
} 
class DivisionByZeroException extends Exception {
    DivisionByZeroException(String s) {
        super(s);
    }
}
class NumberMisMatchException extends Exception {  
	
	NumberMisMatchException(String s) {  
		super(s);  
	}  
	
} 
public class Calculator {
//	  static void validate(int  n1)throws NumberMisMatchException {  
//		  if(!Character.isDigit(n1))
//				  throw new NumberMisMatchException("Enter a valid number");  
//		  else  
//		   System.out.println("Correct number."); 
//	  }   
		  
	  public static void main(String args[]) { 
		  try {
			Scanner input = new Scanner(System.in);
			System.out.println("Enter a number 1:");
			int n1 = input.nextInt();
//			validate(n1);
			System.out.println("Enter a number 2:");
			int n2 = input.nextInt();
			System.out.println("Enter a operations:\n 1.Add \n 2.Sub \n 3.Multiplication \n 4.Division");
//			validate(n2);
			int o = input.nextInt();
			switch(o)
			{
			case 1:
				System.out.println("Addition:" + (n1 + n2));
				break;
			
		  	case 2:
		  			System.out.println("Sub:" + (n1 / n2));
		  			break;
		  
	  		case 3:
	  		   if (n1 == 0 || n1 == 1 || n2 == 0 || n2 == 1) {
                   throw new MultiplicationException("Multiplier and multiplicand should not be 0 or 1.");
               }
	  		   else {
	  			System.out.println("Multiplication:" + (n1 * n2));
	  			break;}
	  
	  		case 4:
                if (n2 == 0) {
                    throw new DivisionByZeroException("Denominator should not be zero.");
                }
                System.out.println("Division: " + (n1 / n2));
                break;
			
			default:
				System.out.println("Operator not found.");
			
			}
		  }
		  catch(Exception e) {
			  System.out.println(e);
		  }
		  finally {
			  System.out.println("Calculated Successfully!!!");
		  }
		  
	  }
}

