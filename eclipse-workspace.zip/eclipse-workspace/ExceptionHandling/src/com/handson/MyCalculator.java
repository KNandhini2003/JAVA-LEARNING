package com.handson;

import java.util.Scanner;




//.....
class CalException  extends Exception{
	CalException(String s) {  
		super(s);  
	} 
}
	
public class MyCalculator {
    public static long power(int n, int p) throws Exception {

        return (long) Math.pow(n, p);
    }

    public static void main(String[] args) {
    	Scanner input = new Scanner(System.in);
    	try {
        System.out.println("Enter a number n:");
        int n = input.nextInt();
        System.out.println("Enter a number p:");
        int p = input.nextInt();
        
        if (n < 0 || p < 0) {
            throw new CalException("n or p should not be negative");
        }
        if (n == 0 || p == 0) {
            throw new CalException("n and p should not be zero");
        }
        else
        		System.out.println(power(n,p));
    	}
        catch (Exception e) {
            System.out.println(e.getMessage());
        }
    	input.close();
    }
}
