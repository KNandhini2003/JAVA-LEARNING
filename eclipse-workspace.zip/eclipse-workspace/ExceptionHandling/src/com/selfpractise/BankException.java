package com.selfpractise;

import java.util.*;

class PayOutOfBoundsException1 extends Exception {
    public PayOutOfBoundsException1(String message) {
        super(message);
    }
}

public class BankException {
		
	    private static final double limit = 30000;
	    private double currentBalance = 8000;
	    
	    public void checkForDebit(double amount) throws PayOutOfBoundsException1 {
	        if (amount > limit) {
	            throw new PayOutOfBoundsException1("Transaction amount exceeds the maximum.");
	        }
	        if (amount > currentBalance) {
	            throw new PayOutOfBoundsException1("Insufficient funds. Current balance is " + currentBalance);
	        }
	    }

	    public void withdrawAmount(double amount) throws PayOutOfBoundsException1 {
	        checkForDebit(amount);
	        currentBalance -= amount;
	        System.out.println("Transaction successful: " + amount);
	        System.out.println("Remaining balance: " + currentBalance);
	    }

	    public static void main(String[] args) {
	    	BankException account = new BankException();
	    	System.out.println("Enter a amount:");
	    	try {
	    	Scanner input = new Scanner(System.in);
	 	    double amount = input.nextDouble();
	            account.withdrawAmount(amount);
	        } 
	    	catch (Exception e) {
	            System.out.println(e);
	        }
	    	
	    }
}
	
