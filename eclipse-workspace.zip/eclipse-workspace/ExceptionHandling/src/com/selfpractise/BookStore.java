package com.selfpractise;

import java.util.InputMismatchException;
import java.util.*;
class UserException extends Exception {

    UserException(String str) {
        super(str);
    }
}

public class BookStore {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int quantity;
        String[] books = {"Cprogram " ,"Python", "Java","R"};
        double price;
        boolean qual = true;
        boolean pri = true;
        while (qual) {
        		try {
        			System.out.println("Enter the quantity of books: ");
        			quantity = input.nextInt();
        			qual = false;

        			}	 
        		catch (InputMismatchException e) {
                System.out.println("enter a valid number for the quantity.");
                input.nextLine();
        		}
        }
        while (pri) {
        	try {
        		System.out.println("Enter the price of the book: ");
        		price = input.nextDouble();
        		if (price < 0)
        			throw new UserException("Please enter a positive value.");
        			pri = false;

            }catch (InputMismatchException e) {

                System.out.println("enter a valid price.");
                input.nextLine();

            } catch (Exception e) {
            		System.out.println(e.getMessage());

            }

        }
        		try {
        			System.out.println("Enter the books: "+ Arrays.toString(books));
        			
        			System.out.print("Enter the index to access the book: ");
        			int index = input.nextInt();
        			System.out.println("Book at index " + index + ": " + books[index]);

                } catch (InputMismatchException e) {

                    System.out.println("enter a valid index.");

                    input.nextLine(); 

                } catch (IndexOutOfBoundsException e) {
                    System.out.println("within the range 0 to 4" );
                }
    }
}
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    