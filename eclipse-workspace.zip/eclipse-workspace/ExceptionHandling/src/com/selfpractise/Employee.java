package com.selfpractise;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

class InvalidEmpNumberException extends Exception {
    InvalidEmpNumberException(String s) {
        super(s);
    }
}

class InvalidDateOfJoinException extends Exception {
    InvalidDateOfJoinException(String s) {
        super(s);
    }
}

class Employee {
    private int empCode;
    private String name;
    private LocalDate dateOfBirth;
    private LocalDate dateOfAppointment;

    public Employee(int empCode, String name, LocalDate dateOfBirth, LocalDate dateOfAppointment) {
        this.empCode = empCode;
        this.name = name;
        this.dateOfBirth = dateOfBirth;
        this.dateOfAppointment = dateOfAppointment;
    }

    @Override
    public String toString() {
        long yearsOfExperience = LocalDate.now().getYear() - dateOfAppointment.getYear();
        return "Employee Code: " + empCode + "\nName: " + name + "\nDate of Birth: " + dateOfBirth +
                "\nDate of Appointment: " + dateOfAppointment + "\nYears of Experience: " + yearsOfExperience;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        try {
            System.out.println("Enter Employee Code:");
            int empCode = input.nextInt();
            input.nextLine(); 

            if (empCode <= 0) {
                throw new InvalidEmpNumberException("Employee code must be a positive integer.");
            }

            System.out.println("Enter Employee Name:");
            String name = input.nextLine();

            System.out.println("Enter Date of Birth(yyyy-MM-dd):");
            LocalDate dateOfBirth = LocalDate.parse(input.nextLine(), formatter);

            System.out.println("Enter Date of Appointment(yyyy-MM-dd):");
            LocalDate dateOfAppointment = LocalDate.parse(input.nextLine(), formatter);

            if (dateOfAppointment.isBefore(dateOfBirth)) {
                throw new InvalidDateOfJoinException("cannot be before date of birth.");
            }

            Employee employee = new Employee(empCode, name, dateOfBirth, dateOfAppointment);
            System.out.println("Employee created successfully:\n" + employee);
        } catch (InvalidEmpNumberException | InvalidDateOfJoinException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("An unexpected error occurred: " + e.getMessage());
        } 
    }
}
