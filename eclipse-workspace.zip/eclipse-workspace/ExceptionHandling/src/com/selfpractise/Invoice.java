package com.selfpractise;

import java.util.Scanner;

class InputMisMatchException extends Exception{
	InputMisMatchException(String s){
		super(s);
	}
}
class IllegalArgumentException extends Exception{
	IllegalArgumentException(String s){
		super(s);
	}
}

public class Invoice {
	int no;
	String description;
	int items;
	double price;
	Invoice(int no , String description , 
			int items , double price){
		this.no = no;
		this.description = description;
		this.items = items;
		this.price = price;
		
	}
    public static void main(String[] args) {
    	
    	try {
    		
    		Scanner input = new Scanner(System.in);
        System.out.println("Enter a part number :");
        int no = input.nextInt();
        if (no <= 0) {
            throw new IllegalArgumentException("Part number must be greater than 0.");
        }
        
        System.out.println("Enter a part description:");
        String description = input.next();
        if (description.isEmpty()) {
            throw new IllegalArgumentException("Part description is empty.");
        }
        System.out.println("Enter a quanity of items :");
        int items = input.nextInt();
        if (items <= 0) {
            throw new IllegalArgumentException("Quantity must be greater than 0.");
        }
        System.out.println("Enter a price per items :");
        double price = input.nextDouble();
        if (price <= 0) {
            throw new IllegalArgumentException("item  greater than 0.");
        }
        
    	
    	 Invoice invoice = new Invoice(no, description, items, price);
         System.out.println("Invoice created successfully:");
         System.out.println("Part Number: " + invoice.no);
         System.out.println("Description: " + invoice.description);
         System.out.println("Quantity: " + invoice.items);
         System.out.println("Price per Item: " + invoice.price);
    	
    	}
    	catch (Exception e) {
        System.out.println("An unexpected error occurred: " + e.getMessage());
    	}
    	
    }
    
}
