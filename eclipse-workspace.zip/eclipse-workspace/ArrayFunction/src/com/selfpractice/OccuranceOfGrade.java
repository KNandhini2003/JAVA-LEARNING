package com.selfpractice;

import java.util.Scanner;

public class OccuranceOfGrade {

	public static void main(String []args ) {
		Scanner input=new Scanner(System.in);
		
		System.out.println("Enter a size of array:");
		int size = input.nextInt();
		int array[] = new int[size];
		System.out.println("Enter a array elements:");
	
		for(int i = 0 ; i<size; i++) {
			
			array[i] = input.nextInt();
		}
		display(array,size);
		input.close();
	}
	static void display(int array[],int size) {
		int c=0;
		for(int i = 0 ; i<size; i++) {
			if(array[i]  == 90) 
				c++;
		}
		System.out.println("The grade 90 appears "+c+" times in the array");
		
	}
}
