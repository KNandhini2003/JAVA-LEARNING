package com.selfpractice;

import java.util.*;
public class RotateArray {

	    static void display(int size, int array[],int rotate) {
	        int arr[]=new int[size];
	        int j=0;
	        for (int i = rotate; i < size; i++) {
	           arr[j]=array[i];
	           j++;
	        }
	        for (int i = 0; i < rotate; i++) {
	        	arr[j]=array[i];
	        	j++;
	        }

	        System.out.println("After rotation");
	        for (int i = 0; i < size; i++) {
	        	System.out.print(arr[i]+" ");
	        }

	    }

	    public static void main(String[] args) {

	        Scanner input = new Scanner(System.in);

	        System.out.println("Enter the size of array:");
	        int size = input.nextInt();
	        int array[] = new int[size];
	        System.out.println("Enter the array elements:");

	        for (int i = 0; i < size; i++) {
	            array[i] = input.nextInt();
	        }
	        System.out.println("Enter the rotate:");
	        int rotate=input.nextInt();
	        display(size, array,rotate);

	        input.close();
	    }

	}


