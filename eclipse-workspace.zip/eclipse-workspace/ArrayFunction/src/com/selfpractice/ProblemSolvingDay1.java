package com.selfpractice;

public class ProblemSolvingDay1 {

}
