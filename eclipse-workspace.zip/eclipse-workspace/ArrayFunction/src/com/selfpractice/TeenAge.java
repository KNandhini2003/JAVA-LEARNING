package com.selfpractice;
import java.util.*;
public class TeenAge {

		public static void main(String[]args) {
			Scanner input=new Scanner(System.in);
			System.out.println("Enter a number_a:");
			int a=input.nextInt();
			System.out.println("Enter a number_b:");
			int b=input.nextInt();
			TeenAge obj=new TeenAge();
			obj.display(a,b);
			input.close();
		}
		public void display(int a ,int b) {
		if(a>=13&&a<=19||b>=13&&b<=19) {
			System.out.println(19);
		}
		else {
			System.out.println(a+b);
		}
		}
}
