package com.selfpractice;

import java.util.Scanner;

public class BinaryConverter {

	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a number:");
		int number=input.nextInt();
		display(number);
		input.close();
	}
	static void display(int number) {
		String binary=" ";
		int split=0;
		while(number!=0) {
			split=number % 2;
			binary=split+binary;
			number/=2;
		}
		System.out.print(binary);
	}
}//11001
