package com.selfpractice;
import java.util.*;
public class TreasurHunt {
		public static void main(String []args ) {
			Scanner input=new Scanner(System.in);
			
			System.out.println("Enter a size of array:");
			int size = input.nextInt();
			int array[] = new int[size];
			System.out.println("Enter a array elements:");
		
			for(int i = 0 ; i<size; i++) {
				
				array[i] = input.nextInt();
			}
			int res=display(array,size);
			System.out.println("Largest treasure in array:"+res);
			input.close();
		}
		static int display(int array[],int size) {
			int max=array[0];
			for(int i = 0 ; i < size ; i++) {
				if(max<array[i]) {
					max = array[i];
				}
			}
			return max;
		}
}
