package com.selfpractice;
import java.util.*;
public class Triangle {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
       
        System.out.println("Enter side1 of triangle:");
        double side1 = input.nextDouble();
        System.out.println("Enter side1 of triangle:");
        double side2 = input.nextDouble();
        System.out.println("Enter side1 of triangle:");
        double side3 = input.nextDouble();
        display(side1,side2,side3);
        input.close();
    }
    static void display(double side1,double side2,double side3) {
        double semiPerimeter = (side1 + side2 + side3) / 2;
        
        double area = Math.sqrt(semiPerimeter * (semiPerimeter - side1) * 
        		(semiPerimeter - side2) * (semiPerimeter - side3));     
        System.out.println("Area of the triangle: " + area);
        
    }
}
