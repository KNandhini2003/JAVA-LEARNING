package com.selfpractice;
import java.util.*;

public class MissingNumberArtifact {

    void display(int size, int array[]) {
        int sum = 0;

        for (int i = 0; i < size; i++) {
            sum += array[i];
        }
        int result = Math.abs(((size * (size + 1)) / 2) - sum);

        System.out.println("Missing element:" + result);

    }

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.println("Enter the size of array:");
        int size = input.nextInt();
        int array[] = new int[size];
        System.out.println("Enter the array elements:");

        for (int i = 0; i < size-1; i++) {
            array[i] = input.nextInt();
        }
        MissingNumberArtifact obj = new MissingNumberArtifact();
        obj.display(size, array);

        input.close();
    }

}
