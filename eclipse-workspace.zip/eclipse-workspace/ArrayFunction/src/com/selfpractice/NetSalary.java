package com.selfpractice;
import java.util.Scanner;

public class NetSalary {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter the Basic Salary:");
        int basicSalary = input.nextInt();
        System.out.println("Enter the Income/Professional Tax:");
        int incomeTax = input.nextInt();
        displayNetSalary(basicSalary, incomeTax);
        input.close();
    }

    static void displayNetSalary(int basicSalary, int incomeTax) {
        double DA, HRA, MA, TA, PF, allowance, deduction, netSalary;
        DA = basicSalary * 0.7;
        HRA = basicSalary * 0.07;
        MA = basicSalary * 0.02;
        TA = basicSalary * 0.04;
        allowance = DA + HRA + MA + TA;
        PF = basicSalary * 0.12;
        deduction = PF + incomeTax;
        netSalary = basicSalary + allowance - deduction;
        System.out.println("Net Salary: " + netSalary);
    }
}
