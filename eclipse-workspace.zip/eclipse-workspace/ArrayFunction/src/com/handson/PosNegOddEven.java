package com.handson;
import java.util.*;

public class PosNegOddEven {
	
	public static void main(String [] args) {
	
		Scanner input = new Scanner(System.in);

		System.out.println("Enter a size of array:");
		int size = input.nextInt();
		int arr[] = new int[size];
		System.out.println("Enter a array elements:");
		for(int i = 0 ; i<size ; i++) {
			
			arr[i] = input.nextInt();
		}
		display(size,arr);
		input.close();
	}
	static public void display(int size,int array[]) {
		
		int positive=0,negative=0,odd=0,even=0,zero=0;
		for(int i = 0 ; i < size ; i++) {
			
			if(array[i]>0) {
				positive++;
			}
			
			if(array[i]<0) {
				negative++;
			}
			
			if(array[i]%2==0) {
				odd++;
			}
			if(array[i]%2!=0) {
				even++;
			}
			if(array[i]==0) {
				zero++;
			}
		}
		System.out.println("number of positive numbers:"+positive);
		System.out.println("number of negative numbers:"+negative);
		System.out.println("number of odd numbers:"+odd);
		System.out.println("number of even numbers: "+even);
		System.out.println("number of 0s:"+zero);
		
		
	}
}



