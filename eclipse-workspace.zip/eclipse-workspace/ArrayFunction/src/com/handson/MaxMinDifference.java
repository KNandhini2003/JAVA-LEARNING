package com.handson;

import java.util.Scanner;

public class MaxMinDifference {
	public static void main(String [] args) {
		
		Scanner input = new Scanner(System.in);

		System.out.println("Enter a size of array:");
		int size = input.nextInt();
		int array[] = new int[size];
		System.out.println("Enter a array elements:");
	
		for(int i = 0 ; i<size; i++) {
		
			array[i] = input.nextInt();
		}
		display(size,array);
		input.close();
	}
	static void display(int size,int array[]) {
		        int minA = 0, minB = 0, maxA = 0, maxB = 0, difference = 0,
		        		min = Integer.MAX_VALUE, max = Integer.MIN_VALUE;
		        for (int i = 0; i < size; i++) {

		            for (int j = i + 1; j < size; j++) {
		                difference = Math.abs(array[i] - array[j]);
		                if (difference < min) {
		                    // minimum
		                    min = difference;
		                    minA = array[i];
		                    minB = array[j];
		                }

		                if (difference > max) {
		                    // maximum
		                    max = difference;
		                    maxA = array[i];
		                    maxB = array[j];
		                }

		            }

		        }
		        System.out.println("Pair with maximum difference: " + maxA + " " + maxB);
		        System.out.println("Maximum difference: " + max);
		        System.out.println("Pair with minimum difference: " + minA + " " + minB);
		        System.out.println("Minimum difference: " + min);

		    }
		}
