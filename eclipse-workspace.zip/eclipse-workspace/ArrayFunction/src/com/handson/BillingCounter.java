package com.handson;

import java.util.Scanner;

public class BillingCounter {
	
	static public void billing(int size,String array[],
			String person) {
		int c=0;
		for(int i=0;i<size;i++) {
			if(array[i].equals(person))
			{
				System.out.println(array[i] + "present in" + i);
				c++;
				break;
			}
		}
		if(c==0) {
			System.out.println("Not present -1");
			
		}
		
	}
	public static void main(String [] args) {
		
		Scanner input = new Scanner(System.in);

		System.out.println("Enter a size of array:");
		int size = input.nextInt();
		String array[] = new String[size];
		System.out.println("Enter a array elements:");
		input.nextLine();
		for(int i = 0 ; i<size ; i++) {
			
			array[i] = input.nextLine();
		}
		System.out.println("Enter a person check whether in array:");
		String person = input.nextLine();
		billing(size,array,person);
		input.close();
	}
}
