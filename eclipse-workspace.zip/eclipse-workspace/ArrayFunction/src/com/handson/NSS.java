package com.handson;

import java.util.Scanner;

public class NSS {
	static void display(int array[],int array1[]){
		for(int i=0;i<array.length;i++) {
			for(int j=0;j<array1.length;j++) {
				if(array[i]==array1[j])
				{
					System.out.println(array[i]);
				}
			}
		}
	}
	public static void main(String [] args) {
		
		Scanner input = new Scanner(System.in);

		System.out.println("Enter a size of array1:");
		int size = input.nextInt();
		int array[] = new int[size];
		System.out.println("Enter a array1 elements:");
	
		for(int i = 0 ; i<size; i++) {
		
			array[i] = input.nextInt();
		}
	//	Scanner input = new Scanner(System.in);

		System.out.println("Enter a size of array2:");
		int size1 = input.nextInt();
		int array1[] = new int[size1];
		System.out.println("Enter a array2 elements:");
	
		for(int i = 0 ; i<size1; i++) {
		
			array1[i] = input.nextInt();
		}
		display(array,array1);
		input.close();
	}
}
