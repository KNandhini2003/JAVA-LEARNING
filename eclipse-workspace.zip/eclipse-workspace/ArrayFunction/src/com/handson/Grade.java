package com.handson;

import java.util.Scanner;

public class Grade {
	public static void main(String [] args) {
	Scanner input=new Scanner(System.in);
	System.out.println("Enter no of students:");

    int student = input.nextInt();
    System.out.println("Enter no of assignment:");

    int assignment = input.nextInt();
    int array[][] = new int[student][assignment];
    
    for(int i=0 ; i < student ; i++) {
    	System.out.println("Stuent"+(i+1)+" "+assignment +"score:");
    	for(int j = 0; j < assignment ; j++) {
    		array[i][j]=input.nextInt();
    	}
    	
    }
	
    display(array,student,assignment);
    input.close();
	}
	static void display(int array[][],int student,int assignments) {
		int average=0;
		for(int i=0 ; i < student ; i++) {
	    	System.out.println("Stuent"+(i+1)+"average:");
	    	for(int j = 0; j < assignments ; j++) {
	    		
	    		average+=array[i][j];
	    	}
	    	System.out.print(average/assignments+"\n");
	    	average=0;
	    }
	}
}
