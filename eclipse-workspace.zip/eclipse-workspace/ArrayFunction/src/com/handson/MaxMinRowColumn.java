package com.handson;
import java.util.*;
public class MaxMinRowColumn {
		public static void main(String[]args) {
			Scanner input=new Scanner(System.in);
			
			System.out.print("Enter a  row  size:");
			int row=input.nextInt();
			System.out.print("Enter a column size:");
			int column=input.nextInt();
			int array[][]=new int[row][column];
			System.out.print("Enter a array of elements:");
			for(int i=0;i<row;i++) {
				for(int j=0;j<column;j++) {
					array[i][j]=input.nextInt();
				}
			}
		
		display(array,row,column);
		input.close();
		}
		static void display(int array[][],int row,int column) {
			System.out.print("Array elements:");
			for(int i=0;i<row;i++) {
				for(int j=0;j<column;j++) {
					System.out.print(array[i][j]+" ");
				}System.out.println();
			}
		
			for(int i=0;i<row;i++) {
				
				int min = Integer.MAX_VALUE, max = Integer.MIN_VALUE;
				for(int j=0;j<column;j++) {
					if(max<array[i][j])
							max=array[i][j];
				}
				System.out.println("maximum element in "+i+"is:"+max);
				for(int j=0;j<column;j++) {
					if(min>array[j][i])
							min=array[j][i];
				}
				System.out.println("minimum element in "+i+"is:"+min);
			}
		}
		
		
}
