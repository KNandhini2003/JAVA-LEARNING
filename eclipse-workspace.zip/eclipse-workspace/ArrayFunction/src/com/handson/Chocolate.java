package com.handson;

import java.util.Scanner;

public class Chocolate {


public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    System.out.println("Enter the number of friends:");
    int friend=input.nextInt();
    int chocolates[] = new int[friend];
    System.out.println("Enter the number of chocolatess each:");
    for (int i = 0; i < friend; i++) {
        chocolates[i] = input.nextInt();
    }
    display(chocolates,friend);
    input.close();
}
static void display(int chocolates[],int friend) { 
    int totalChocolates = 0;
    for (int i = 0; i < chocolates.length; i++) {
        totalChocolates+=chocolates[i];
    }
    String result = (totalChocolates % friend == 0) ? "Yes" : "No";

    // Output the result
    System.out.println(result);

}
}