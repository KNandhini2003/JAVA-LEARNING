package com.handson;

import java.util.*;


public class DuplicateElements {
	
	static void display(int size,int[]array) {
		int n = size;
		for(int i=0 ; i < size ; i++) {
			
			for(int j = i+1 ; j < size ; j++) {
				
				if(array[i]==array[j]) {

					for(int k=j;k<size-1;k++) {
						array[k]=array[k+1];
					}
					
					size--;
			}
		}
	}
		for (int i=0;i<size;i++) {
			System.out.print(array[i]+" ");
		}
		
}
	public static void main(String [] args) {
		
		Scanner input = new Scanner(System.in);

		System.out.println("Enter a size of array:");
		int size = input.nextInt();
		int array[] = new int[size];
		System.out.println("Enter a array elements:");
	
		for (int i = 0 ; i < size; i++) {
			
			array[i] = input.nextInt();
		}
		display(size,array);
		input.close();
		
	}
}
