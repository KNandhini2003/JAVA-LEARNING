package com.handson;

import java.util.Scanner;

public class PairOfElements {
	static void display(int size,int array[]) {
		int c=0;
		for(int i=0;i<size;i++) {
			for(int j=i+1;j<size;j++) {
				if(array[i]+array[j]==10) {
					System.out.println(array[i]+" "+array[j]);
					c=1;
					break;
				}
				
			}
			if(c==1) {
				break;
			}
		}
		if(c==0) {
			System.out.println(-1);
		}
	}
	public static void main(String [] args) {
		
		Scanner input = new Scanner(System.in);

		System.out.println("Enter a size of array:");
		int size = input.nextInt();
		int array[] = new int[size];
		System.out.println("Enter a array elements:");
		
		for(int i = 0 ; i<size; i++) {
			
			array[i] = input.nextInt();
		}
		display(size,array);
		input.close();
	}
}
