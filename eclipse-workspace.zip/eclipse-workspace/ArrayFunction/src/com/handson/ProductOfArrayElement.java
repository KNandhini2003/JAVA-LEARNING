package com.handson;
import java.util.*;
public class ProductOfArrayElement {
	public static void main(String [] args) {
		
			Scanner input = new Scanner(System.in);

			System.out.println("Enter a size of array:");
			int size = input.nextInt();
			int array[] = new int[size];
			System.out.println("Enter a array elements:");
		
			for(int i = 0 ; i<size; i++) {
			
				array[i] = input.nextInt();
			}
			array=display(size,array);
			for(int i = 0 ; i<size; i++) {
				
				System.out.print(array[i]+" ");
				
			}
			input.close();
	}
	static int[]  display(int size,int array[]) {
		int product=1;
		int arr1[]=new int[size];
		for(int i = 0 ; i < size ; i++) {
			for(int j = 0 ;j < size; j++) {
				if(array[i]==array[j]) {
					continue;
				}
				else {
					product*=array[j];
				}
			}
			arr1[i]=product;
			
			product=1;
		}
		return arr1;
		
	}
}