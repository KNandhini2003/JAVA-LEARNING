package com.handson;
import java.util.*;
public class IgnoreNegative {
	public static void main(String [] args) {
		
		Scanner input = new Scanner(System.in);

		System.out.println("Enter a size of array:");
		int size = input.nextInt();
		int array[] = new int[size];
		System.out.println("Enter a array elements:");
		int i=0,n=0;
		boolean condition=true;
		while(condition) {
		
			 n= input.nextInt();
			 if(n<0) {
				break; 
			 }
			array[i]=n;
			i++;
		}
		
		display(array);
		input.close();
	}
	static void display(int array[]) {
		int array1[]=new int [array.length];
		for(int i=0;i<array.length;i++) {
			
			if(array[i]%2==0)
				array1[i]=0;
			if(array[i]%2!=0)
				array1[i]=1;
			if(array[i]%8==0)
				array1[i]=2;
			if(array[i]%10==3)
				array1[i]=3;
			if(array[i]%9==0)
				array1[i]=4;
		}
		
		System.out.println("original  array:");
		for(int i=0;i<array.length;i++) {
			System.out.print(array[i]+" ");
		}
		System.out.println("Updated array:");
		for(int i=0;i<array1.length;i++) {
			System.out.print(array1[i]+" ");
		}
	}
}
