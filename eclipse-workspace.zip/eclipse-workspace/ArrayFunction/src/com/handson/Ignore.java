package com.handson;

import java.util.Scanner;

public class Ignore {
public static void main(String [] args) {
		
		Scanner input = new Scanner(System.in);

		System.out.println("Enter a size of array1:");
		int size = input.nextInt();
		int array[] = new int[size];
		System.out.println("Enter a array1 elements:");
	
		for(int i = 0 ; i<size; i++) {
		
			array[i] = input.nextInt();
			
		}
		System.out.println("Enter a:");
		int a = input.nextInt();
		System.out.println("Enter b:");
		int b = input.nextInt();
		display(array,a,b);
		input.close();
}
static void display(int array[],int a,int b)
{
	int store=0,store1=0,sum=0,sum1=0;
	for(int i=0;i<array.length;i++) {
		if(array[i]==a) {
			store=i;
		}
		if(array[i]==b) {
			store1=i;
		}
	}
	if(store<store1) {
		for(int i=0;i<array.length;i++) {
			if(array[i]==a || array[i]==b)
				continue;
			sum+=array[i];
		}
		System.out.println(sum);
	}
	else {
		for(int i=0;i<array.length;i++) {
			
			sum1+=array[i];
		}
		System.out.println(sum1);
	}
}
}
