package com.handson;

import java.util.Scanner;

public class MissingNumber {
	
	void display(int size,int array[]) {
		int sum=0;
		
		for(int i=0 ; i < size ; i++) {
			sum+=array[i];
		}
        int expectedSum = (size * (size + 1)) / 2;
        int missingElement = expectedSum - sum;
		
		System.out.println("Missing element:"+missingElement);
		
	}
	public static void main(String [] args) {
		
		Scanner input = new Scanner(System.in);

		System.out.println("Enter a size of array:");
		int size = input.nextInt();
		int array[] = new int[size];
		System.out.println("Enter a array elements:");
	
		for(int i = 0 ; i<size-1; i++) {
			
			array[i] = input.nextInt();
		}
		MissingNumber obj=new MissingNumber();
		obj.display(size, array);
		
		input.close();
	}
		
}
