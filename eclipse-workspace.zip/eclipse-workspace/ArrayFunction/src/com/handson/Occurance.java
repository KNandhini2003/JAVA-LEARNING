package com.handson;
import java.util.*;
public class Occurance {
	
	static int occur(int size,int array[],int search) {
		int c=0;
		for(int i=0 ;i < size ;i++) {
			if(array[i]==search) {
				c++;
			}
		}
		return c;
	}
	public static void main(String [] args) {
		
		Scanner input = new Scanner(System.in);

		System.out.println("Enter a size of array:");
		int size = input.nextInt();
		int array[] = new int[size];
		System.out.println("Enter a array elements:");
		
		for(int i = 0 ; i<size; i++) {
			
			array[i] = input.nextInt();
		}
		System.out.println("Enter a number to search:");
		int search= input.nextInt();
		
		int count=occur(size,array,search);
		System.out.print("Occurance of number " + search + ":" + count);
		input.close();
		
	}
}