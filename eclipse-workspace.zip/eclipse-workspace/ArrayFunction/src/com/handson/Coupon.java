package com.handson;

import java.util.Scanner;

public class Coupon {
	static void display(int num) {
		int c=0;
		int set1[]= {2 ,4 ,7 ,11, 16, 22, 29, 37, 46, 56};
		int set2[]= {1, 5, 9, 10, 13, 18, 19, 22, 25, 28};
		for(int i=0;i<set1.length;i++) {
			if(set1[i]==num) {
				System.out.println("Rs.10000 Cash Prize ");
				c=1;
			}
		}
		for(int i=0;i<set2.length;i++) {
			if(set2[i]==num) {
				System.out.println("Tour Tickets for two days");
				c=1;
			}
		}
		if(c==0) {
			System.out.println("Better luck next time");
		}
	}
public static void main(String[]args) {
	Scanner input=new Scanner(System.in);
	System.out.println("Enter a number:");
	int number=input.nextInt();
	display(number);
	input.close();
}
}
