package com.handson;

import java.util.*;

public class Palindrome {
public static void main(String [] args) {
		
		Scanner input = new Scanner(System.in);

		System.out.println("Enter a size of array1:");
		int size = input.nextInt();
		int array[] = new int[size];
		System.out.println("Enter a array1 elements:");
	
		for(int i = 0 ; i<size; i++) {
		
			array[i] = input.nextInt();
			
		}
		display(array);
		input.close();
}
static void display(int array[]) {
	
	boolean res=true;
	int j=array.length-1;
	for(int i=0 ; i<array.length-1; i++) {
		if(array[i]!=array[j]) {
			res=false;
			
			break;
			}
		j--;	
	}
	if(res) {
		System.out.println(res);
	}
	else {
		System.out.println(res);
	}
}
}
