package com.handson;
import java.util.*;
public class Progression {
    static boolean Arithmetic(int[]arr) {
        int d = arr[1] - arr[0];
        for (int i = 1; i < arr.length - 1; i++) {
            if (arr[i + 1]- arr[i] != d) {
                return false;
            }
        }
        return true;
    }
    static boolean Geometric(int[]arr) {
        int r = arr[1] / arr[0];
        
        for (int i = 1; i < arr.length - 1; i++) {
            if (arr[i + 1] / arr[i] != r) {
                return false;
            }
        }
        return true;
    }
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
			System.out.println("Enter a size of array:");
			int size = input.nextInt();
			int array[] = new int[size];
			System.out.println("Enter a array elements:");
		
			for(int i = 0 ; i<size; i++) {
			
				array[i] = input.nextInt();
			}
        if (Arithmetic(array)) {
            System.out.println("Arithmetic Progression");
        } else if (Geometric(array)) {
            System.out.println("Geometric Progression");
        } else {
            System.out.println("Random Order");
        }
        input.close();
    }
}
