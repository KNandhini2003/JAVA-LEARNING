package com.handson;

import java.util.Scanner;

public class SplitArray {
public static void main(String [] args) {
		
		Scanner input = new Scanner(System.in);

		System.out.println("Enter a size of array1:");
		int size = input.nextInt();
		int array[] = new int[size];
		System.out.println("Enter a array1 elements:");
	int sum=0;
		for(int i = 0 ; i<size; i++) {
		
			array[i] = input.nextInt();
			sum+=array[i];
		}
		display(sum/size,array);
		input.close();
}
static void display(int average,int arr[]) {
	for(int i=0;i<arr.length;i++) {
		if(arr[i]<average) {
			System.out.print("["+arr[i]+"],");
		}
	}
	for(int i=0;i<arr.length;i++) {
		if(arr[i]>average) {
			System.out.print("  ["+arr[i]+"].");
			}
		}
	}
}
