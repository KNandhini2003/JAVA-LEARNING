package com.handson;

public class Strings {
	public static void main(String []args) {
	String str="Hello, World";
	System.out.println(str.indexOf('o'));
	
	System.out.println(str.indexOf("lo, W"));
	System.out.println(str.indexOf("Java"));
	if("heelo"=="heelo") {
		System.out.println("T");
	}
	String s1="hello";
	String s2="hello";
	
	if(s1==s2) {//string liternal so output.//it will check the memory//reference=memory
		System.out.println("T");
	}
	String s3=new String("hello");
	String s4=new String("hello");
	if(s3==s4) {
		System.out.println("new Keyword:"+s3+true);
	}
	else
		System.out.println("new Keyword:"+s3+false);
	
	if(s3.equals(s4))
		System.out.print("new Keyword with equals:"+s4+true);
//	input.close();
}
}