package com.handson;
import java.util.*;
public class TwoDArray {
	public static void main(String[]args) {
		Scanner input = new Scanner(System.in);

		System.out.println("Enter a  row size of array:");
		int row = input.nextInt();
		System.out.println("Enter a  column size of array:");
		int column = input.nextInt();
		int array[][]= new int[row][column];
		System.out.println("Enter a array elements:");
		for(int i = 0 ; i < row ; i++) {
			for(int j = 0 ; j < column ; j++) {
				array[i][j]=input.nextInt();
			}
		}
		display(row,column,array);
		input.close();
	}
	static void display(int row,int column,int array[][]) {
		for(int i = 0 ; i < row ; i++) {
			for(int j = 0 ; j < column ; j++) {
				System.out.print( array[i][j]+" ");
			}System.out.println();
		}
	}
	
}
