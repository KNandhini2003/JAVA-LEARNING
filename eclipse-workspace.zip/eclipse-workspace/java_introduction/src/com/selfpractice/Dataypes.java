package com.selfpractice;

public class Dataypes {
	public static void main(String[]args) {
		/*Initialize an integer variable ‘price’ with the value 52 and
		assign it to a float variable ‘priceInFloat’.
		*/
		int price=52;
		float priceInFloat=price;
		System.out.println("Price in integer:"+price);
		System.out.println("Price in float:"+priceInFloat);
		
		/*
		 Initialize a byte variable ‘age’ with the value 83 and assign
		it to an integer variable ‘intAge’.

		 */
		byte age=83;
		int intAge=age;
		System.out.println("Age in byte: "+age);
		System.out.println("Age in integer: "+intAge);
		/*
		 Initialize an integer variable ‘highestAge’ to 120 and assign
			it to a byte variable ‘byteAge’.
		 */
		int highestAge=120;
		byte byteAge=(byte)highestAge;
		System.out.println("Hage in integer: "+highestAge);
		System.out.println("Tye mismatch error:"
				+ "cannot convert from int to byte");
		
		System.out.println("Hage in byte: "+byteAge);
		
		/*
		 Change the value of ‘highestAge’ to 130 and assign it to
		‘byteAge’.
		 */
		highestAge=130;
		byteAge=(byte)highestAge;
		System.out.println("Hage in integer: "+highestAge);
		System.out.println("Tye mismatch error:"
				+ "cannot convert from int to byte");
		
		System.out.println("Hage in byte: "+byteAge);
	}
}
