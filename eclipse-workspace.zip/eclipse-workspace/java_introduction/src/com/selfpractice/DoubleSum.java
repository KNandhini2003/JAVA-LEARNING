package com.selfpractice;
import java.util.*;
public class DoubleSum {
		public static void main(String[]args) {
			Scanner input=new Scanner(System.in);
			System.out.print("Enter a number1:");
			int number1=input.nextInt();
			System.out.print("Enter a number2:");
			int number2=input.nextInt();
			if(number1==number2) {
				System.out.println("Two numbers is "
			+ " equal so return their sum:"+(number1+number2)*2);
			}
			else {
				System.out.println("Two numbers is not"
		+ " equal so return their sum:"+(number1+number2));
				}
			input.close();
			}
			
		}

