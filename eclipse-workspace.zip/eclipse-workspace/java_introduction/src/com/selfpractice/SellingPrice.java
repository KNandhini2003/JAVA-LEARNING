package com.selfpractice;
import java.util.Scanner;
public class SellingPrice {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter total selling price: ");
        double totalSellingPrice=input.nextDouble();

        System.out.print("Enter total profit earned: ");
        double totalProfit=input.nextDouble();
        int numberOfItems = 15;
        double profitPerItem = totalProfit/numberOfItems;
       double costPrice=(totalSellingPrice/numberOfItems) - profitPerItem;

        System.out.println("Cost price of one item: " +(int)costPrice);

        input.close();
    }
}
