package com.selfpractice;

import java.util.Scanner;

public class MonkeyTrouble {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.println("does it is Money aSmile?(true/false): ");
		String aSmile=input.next();
		System.out.println("does it is Money bSmile?(true/false): ");
		String bSmile=input.next();
		if(aSmile.equals(bSmile)) {
		System.out.println(aSmile);
		}
		else {
			System.out.println("false");
		}
		input.close();
	}
}


