package com.selfpractice;

import java.util.Scanner;

public class TeaCandy {
	public static void main(String[]args) {
	System.out.print("Enter a tea rate:");
	Scanner input=new Scanner(System.in);
	int tea=input.nextInt();
	System.out.print("Enter a candy rate:");
	int candy=input.nextInt();
	if(tea>=5&&candy>=5) {
		
		System.out.println(1);
		System.out.println("A party is considered good");
	}
	else if(tea*2>candy||candy*2>tea) {
		System.out.println(2);
		System.out.println("the party is great");
	}
	else if(tea<5 ||candy<5) {
		System.out.println(0);
		System.out.println("the party is always bad");
	}
	input.close();
	}
	
}
