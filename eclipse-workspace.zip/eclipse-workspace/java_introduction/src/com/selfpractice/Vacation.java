package com.selfpractice;
import java.util.*;
public class Vacation {
		public static void main(String[]args) {
			Scanner input=new Scanner(System.in);
			System.out.println("does it is weekday?(true/false): ");
			boolean week=input.nextBoolean();
			System.out.println("does it is vacation?(true/false): ");
			boolean vacation=input.nextBoolean();
			boolean sleep=(!week)||vacation;
			System.out.println(sleep);
			input.close();
		}
}
