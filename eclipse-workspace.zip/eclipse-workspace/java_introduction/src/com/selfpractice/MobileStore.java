package com.selfpractice;
//import java.util.*;
public class MobileStore {
	public static void main(String[]args) {
		String brand="Samsung";
	    String model="Galaxy 21";
	    String color="blue";
	    int romGB=128;
	    int ramGB=8;
	    double price=35000;
	    System.out.println("brand:"+brand);
	    System.out.println("mode:"+model);
	    System.out.println("color:"+color);
	    System.out.println("romGB:"+romGB);
	    System.out.println("ramGB:"+ramGB);
	    System.out.println("price:"+price);
	    
	    //input.close();
	}
}
