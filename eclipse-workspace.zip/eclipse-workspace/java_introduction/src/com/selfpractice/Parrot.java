package com.selfpractice;

import java.util.Scanner;

public class Parrot {
	public static void main(String[]args) {
	System.out.print("Enter a hour:");
	Scanner input=new Scanner(System.in);
	int time=input.nextInt();
	System.out.print("Enter a true/false:");
	boolean trouble=input.nextBoolean();
	
	boolean result=trouble&& (time<7 ||time>20); 
	System.out.println(result);
		
	
	input.close();
	}
}