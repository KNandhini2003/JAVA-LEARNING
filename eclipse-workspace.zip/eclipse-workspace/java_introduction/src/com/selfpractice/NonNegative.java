package com.selfpractice;

import java.util.Scanner;

public class NonNegative {
	public static void main(String[]args) {
	System.out.print("Enter a number1:");
	Scanner input=new Scanner(System.in);
	int number1=input.nextInt();
	int num=number1,c=0,c1=0;
	System.out.print("Enter a number2:");
	int number2=input.nextInt();
	int res=number1+number2;
	int res1=res;
	while(number1!=0) {
		number1/=10;
		c++;
	}
	while(res!=0) {
		res/=10;
		c1++;
	}
	if(c==c1) {
		System.out.print(res1);
	}
	else {
		System.out.print(num);
	}
	input.close();
	}
	
}
