/*
Anisha and Raja took their common pocket money to the market.
Anisha bought Apples and Raju bought Bananas.
On their way back they saw a Magic Money Vending Machine which gives the triple 
of the money deposited. They both tried with all the balance amount that they had. 
Now write a program to,
1.
Print the amount, they spent together in the market
2.
Print the final amount that they had when they reach home
3.
Print the amount they deposited in the magic machine
Inputs: Pocket money, Apple cost, Banana cost

*/

package com.handon;
import java.util.*;
public class MagicMoneyVendor {
		public static void main(String[]args) {
			Scanner input=new Scanner(System.in);
			System.out.println("Enter Pocket money:");
			int pocketMoney=input.nextInt();
			System.out.println("Enter Apple cost:");
			int appleCost=input.nextInt();
			System.out.println("Enter Banana cost:");
			int bananaCost=input.nextInt();
			int deposit=pocketMoney-(appleCost+bananaCost);
			System.out.println("the amount, they spent together in the market:"+(appleCost+bananaCost));
			System.out.println("final amount that they had when they reach home:"+deposit*3);
			System.out.println("the amount they deposited in the magic machine:"+deposit);
			input.close();
}
}