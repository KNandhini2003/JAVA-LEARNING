/*
Declare four variables numberOne, numberTwo, numberThree, and numberFour of integer type.
Assign the values of your choice for the variables numberOne, numberTwo and numberThree.
Assign 1000 to numberFour. Print the values.
Now re-assign the values as follows to print,

1.
numberOne’s value to numberTwo  1
2.
numberTwo’s value to numberThree 2
3.
numberThree’s value to numberFour 3
4.
100 to numberOne
*/

package com.handon;

public class FourVariableReassign {
		public static void main(String[]args) {
			int numberOne=1;
			int numberTwo=2;
			int numberThree=3;
			int numberFour=1000;
			System.out.println("numberOne"+numberOne);
			System.out.println("numberTwo"+numberTwo);
			System.out.println("numberThree"+numberThree);
			System.out.println("numberFour"+numberFour);
			/*int temp=numberTwo;
			numberTwo=numberOne;
			int temp1=numberThree;
			numberThree=temp;
			numberFour=temp1;
			numberOne=100;*/
			numberFour=numberThree;
			numberThree=numberTwo;
			numberTwo=numberOne;
			numberOne=100;
			System.out.println("AFter Ressigning the variable value:");
			System.out.println("numberOne:"+numberOne);
			System.out.println("numberTwo:"+numberTwo);
			System.out.println("numberThree:"+numberThree);
			System.out.println("numberFour:"+numberFour);
		
			

}
}