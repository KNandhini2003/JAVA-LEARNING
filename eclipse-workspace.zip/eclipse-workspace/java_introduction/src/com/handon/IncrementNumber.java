/*
Write a Java program that increments a given number. 
Don't use arithmetic operators.
*/
package com.handon;
import java.util.*;
public class IncrementNumber {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a number1:");
		int number=input.nextInt();
		int incrementedNumber = -~number;
       
       System.out.println("Original number: " + number);
       System.out.println("Incremented number: " + incrementedNumber);
       input.close();
   }
}

