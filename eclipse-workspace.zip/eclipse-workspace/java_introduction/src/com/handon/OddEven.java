/*
Write a Java program to check whether the given number is odd or even.
Don’t use comparison operator and decision statement.
*/
package com.handon;
import java.util.*;
public class OddEven {
		public static void main(String[]args) {
			Scanner input=new Scanner(System.in);
			System.out.println("Enter a number:");
			int number=input.nextInt();
			String result=(number & 1) > 0?"Odd Number":"Even Number";
			System.out.println(result);
			input.close();
		}
}
