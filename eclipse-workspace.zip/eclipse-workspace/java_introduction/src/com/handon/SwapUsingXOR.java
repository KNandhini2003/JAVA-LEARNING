/*
Suppose the values of variables 'a' and 'b' are 6 and 8
respectively, write programs to swap the values of the two
variables.
c. Third program using using XOR operator
*/

package com.handon;
import java.util.*;
public class SwapUsingXOR {
		public static void main(String[]args) {
			Scanner input=new Scanner(System.in);
			System.out.println("Enter a firstNumber:");
			int number1=input.nextInt();
			System.out.println("Enter a secondNumber:");
			int number2=input.nextInt();
			number1=number1^number2;
			number2=number1^number2;
			number1=number1^number2;
			System.out.println("Two numbers after swapping:"+"\n"+"firstNumber:"
			+number1+"\nsecondNumber:"+number2);
			input.close();
		}
}
