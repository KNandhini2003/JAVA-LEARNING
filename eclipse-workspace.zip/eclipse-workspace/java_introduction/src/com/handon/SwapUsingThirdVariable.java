/*
Suppose the values of variables 'a' and 'b' are 6 and 8
respectively, write programs to swap the values of the two
variables.
a. First program by using a third variable
*/

package com.handon;
import java.util.*;
public class SwapUsingThirdVariable {
		public static void main(String[]args) {
			Scanner input=new Scanner(System.in);
			System.out.println("Enter a firstNumber:");
			int number_a=input.nextInt();
			System.out.println("Enter a secondNumber:");
			int number_b=input.nextInt();
			int thirdNumber=number_a;
			number_a=number_b;
			number_b=thirdNumber;
			System.out.println("Two numbers after swapping:"+"\n"+"firstNumber:"
			+number_a+"\nsecondNumber:"+number_b);
			input.close();
		}
}
