/*
Write a Java program to detect if two integers have opposite signs or not.
Don’t use relational operator.
*/
package com.handon;
import java.util.*;
public class OppositeSign {
	public static void main(String[]args) {
		
		Scanner input=new Scanner(System.in);
		
		System.out.println("Enter a number1:");
		int number1=input.nextInt();
		System.out.println("Enter a number2:");
		int number2=input.nextInt();
		boolean value = (number1 ^ number2) < 0;
        if (value) {
            System.out.println("Opposite signs");
        } else {
            System.out.println("Same signs");
        }
        
        input.close();
	}
}
