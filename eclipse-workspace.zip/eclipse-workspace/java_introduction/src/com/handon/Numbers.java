/*
Declare three integer variables named 'hundred', 'twoHundred', and 'threeHundred', 
and initialize them with the values 10, 2000, and -30000 respectively.
Then, reassign them with the corresponding number names. 
Finally, print the values of all three variables.
*/
package com.handon;
import java.util.*;
public class Numbers {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		int hundred=10;
		int twoHundred=2000;
		int threeHundred=-30000;
		System.out.println("Enter a number:");
		hundred=input.nextInt();
		System.out.println("Enter a number:");
		
		twoHundred=input.nextInt();
		System.out.println("Enter a number:");
		
		threeHundred=input.nextInt();
		System.out.println(hundred);		
		System.out.println(twoHundred);		
		System.out.println(threeHundred);
		input.close();
		
	}
}
