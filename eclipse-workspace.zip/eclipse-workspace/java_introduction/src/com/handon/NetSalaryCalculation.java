/*
 Write a Java program to calculate Net Salary. 
 
User must input Basic Salary and Output should be net salary calculated 
based on following allowances:
Allowances:
DA = 70% of Basic Salary
HRA = 7% of Basic Salary
MA = 2% of Basic Salary
TA = 4% of Basic Salary
Deduction:
PF = 12% of Basic Salary
Income/professional tax = User Input (e.g., 500)
Net Salary = Basic Salary + Allowances – Deduction
*/

package com.handon;
import java.util.*;
public class NetSalaryCalculation {
		public static void main(String[]args) {
			Scanner input=new Scanner(System.in);
			System.out.println("Enter a basic salary:");
			int basicSalary=input.nextInt();
			System.out.println(	"Enter a income Tax:");	
			int income=input.nextInt();
			int DA,HRA,MA,TA,PF;
			DA=(int)(basicSalary*0.7);
			HRA=(int)(basicSalary*0.07);
			MA=(int)(basicSalary*0.02);
			TA=(int)(basicSalary*0.04);
			int allowance=DA+HRA+MA+TA;
			PF=(int)(basicSalary*0.12);
			int deduction=PF+income;
			System.out.println("Net Salary="+(basicSalary+allowance-deduction));
			input.close();
		}
}
