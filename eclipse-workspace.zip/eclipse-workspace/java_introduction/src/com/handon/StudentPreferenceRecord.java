/*
Assist the teacher in analyzing the students' fruit preferences
recorded as follows:

a) Determine the total number of students in the school who
like oranges.
b)
Determine the total number of students in the school who like mangoes.
c)
Calculate the total number of students in the school overall.
d)
Determine whether the number of girls exceeds the number of boys. State 'true' or 'false'.
*/

package com.handon;

public class StudentPreferenceRecord {
	public static void main(String[]args) {
		int girls_like_orange=136;
		int girls_like_mangoes=240;
		int boys_like_orange=128;
		int boys_like_mangoes=243;
		System.out.println("the total number of students in the school like oranges:"+
		(girls_like_orange+boys_like_orange));
		System.out.println("the total number of students in the school like mangoes:"+
		(girls_like_mangoes+boys_like_mangoes));
		System.out.println("the total number of students in the school :"+
		(girls_like_mangoes+boys_like_mangoes+girls_like_orange+boys_like_orange));
		if((girls_like_orange+girls_like_mangoes)>(boys_like_orange+boys_like_mangoes)) {
			System.out.println("Girls exceeds boys");
			
		}
		else {
			System.out.println("No Girls exceeds boys");
		}
	
	}

}
