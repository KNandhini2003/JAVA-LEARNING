/*
Write a Java program to reverse a 3-digit number.
*/

package com.handon;
import java.util.*;
public class ReverseNumber {
		public static void main(String[]args) {
			System.out.println("Enter a 3-Digit Number:");
			Scanner input=new Scanner(System.in);
			int number=input.nextInt();
			int remainder=0,reversedNumber=0;
			while(number!=0) {
				remainder=number%10;
				reversedNumber=reversedNumber*10+remainder;
				number/=10;
			}
			System.out.println("Reversal of number is:"+reversedNumber);
			input.close();
		}
}
