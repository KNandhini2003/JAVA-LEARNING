/*
Write a Java application that takes a duration in minutes as input and calculates 
the equivalent duration in years and days.
*/

package com.handon;
import java.util.*;
public class YearAndDate {
	public static void main(String[]args) {
		System.out.println("Enter a minutes:");
		Scanner input=new Scanner(System.in);
		double minutes=input.nextDouble();
		double year=minutes/(365*24*60);
		double day=minutes/(24*60);
		System.out.printf("Equivalent Year:%.2f",year);
		System.out.printf("\nEquivalent Day:%.2f",day);
		input.close();
}
	
}
