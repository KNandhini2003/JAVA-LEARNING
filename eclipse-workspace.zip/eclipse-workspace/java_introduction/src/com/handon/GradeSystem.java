/*
The total number of students in a class are 90 out of which 45 are boys.
If 50% of the total students secured grade 'A' out of which 20 are boys, 
then write a program to calculate the total number of girls getting grade 'A'.
*/

package com.handon;

public class GradeSystem {
	public static void main(String[]args) {
	int totalStudent=90;
	//boys:45
	int grade_50percent=(int)(totalStudent*0.5);
	int boy_Agrade=20;
	int totalgirl = grade_50percent - boy_Agrade;
	System.out.println("The total number of girls getting grade A:"+totalgirl);

}
}
