/*Declare a variable ‘age’. 
Assign a value to ‘age’ and print the value of age.
Choose the correct datatype for age considering age as a whole number.
*/
package com.handon;
import java.util.*;
public class Age {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a age of a person:");
		int age=input.nextInt();
		System.out.println("Age="+age);
		input.close();
	}

}
