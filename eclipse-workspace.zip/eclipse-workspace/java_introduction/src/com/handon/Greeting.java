/*Read a person's name first, read another person and another.
Greet the first person first, the third person second and the second
person last. If ‘Chloe’, ‘Joey’ & ‘Zoe’ are the inputs, then the
output will be ‘Welcome Chloe! Welcome Zoe! Welcome Joey too!’
*/
package com.handon;
import java.util.*;

public class Greeting {
		public static void main(String[]args) {
			Scanner input=new Scanner(System.in);
			System.out.println("Enter a firstperson name:");
			String firstPerson=input.nextLine();
			System.out.println("Enter a secondperson name:");
			String secondPerson=input.nextLine();
			System.out.println("Enter a thirdperson name:");
			String thirdPerson=input.nextLine();
			System.out.println("Welcome "+firstPerson+"!");
			System.out.println("Welcome "+thirdPerson+"!");
			System.out.println("Welcome "+secondPerson+"!");
			input.close();
		}
}
