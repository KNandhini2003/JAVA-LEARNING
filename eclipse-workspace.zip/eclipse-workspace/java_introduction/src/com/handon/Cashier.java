/*
A cashier in a shop has currency notes of denominations 10,50 and 100.
If the amount to be returned is the input, 
find the total number of currency notes of each denomination that the cashier
should give to the customer. 
Write a program to accomplish the above task.
Assume that the input is in 10’s multiples.
*/

package com.handon;
import java.util.*;
public class Cashier {
	public static void main(String[]args) {
		   Scanner input = new Scanner(System.in);
	  
	        System.out.print("Enter the amount in multiples of 10: ");
	        int amount = input.nextInt();
	        int hundred = amount / 100;
	        int remainingAmount = amount % 100;
	        int fifty = remainingAmount / 50;
	        remainingAmount %= 50;
	        int ten = remainingAmount / 10;
	        System.out.println("No.of Hundreds in currency notes:"+hundred);
	        System.out.println("No.of fifty in currency notes:"+fifty);
	        System.out.println("No.of ten in currency notes:"+ten);
	        input.close();
	}

}
