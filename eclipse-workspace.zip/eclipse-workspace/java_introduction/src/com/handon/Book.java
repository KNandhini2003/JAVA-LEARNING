/*Declare a variable ‘bookPrice’ (Choose the right datatype). 
Assign the value 150.50 to ‘bookPrice’. 
Print the price. Now, re-assign a value to ‘bookPrice’ then print ‘bookPrice’.
*/

package com.handon;
import java.util.*;
public class Book {
public static void main(String[]args) {
	Scanner input=new Scanner(System.in);
	float bookPrice=150.50f;
	System.out.printf("bookPrice:%.2f\n",bookPrice);
	System.out.println("Enter a bookPrice:");
	bookPrice=input.nextFloat();
	System.out.println("bookPrice:"+bookPrice);
	input.close();
}
}
