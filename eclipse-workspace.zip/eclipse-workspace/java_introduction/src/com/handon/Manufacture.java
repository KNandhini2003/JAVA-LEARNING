/*
A factory-manufactured LED bulbs on the first day. On the second
day, it made CFL bulbs. How many bulbs did the factory make
altogether? Counts are the input
*/

package com.handon;
import java.util.*;
public class Manufacture {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter Total LED buld produced:");
		int LED=input.nextInt();
		System.out.println("Enter Total CFL buld produced:");
		int CFL=input.nextInt();
		System.out.println("Total bulbs produced in a factory:"+(LED+CFL));
		input.close();
	}
}
