/*
Write a Java program to accept 3 sides of triangle from user and
print area of triangle as an output. (Library method can be used
to find the square root)
*/

package com.handon;
import java.util.*;
public class AreaOfTriangle {
	public static void main(String[]args) {
	Scanner input=new Scanner(System.in);
	System.out.println("Enter side_a:");
	float side_a=input.nextInt();
	System.out.println("Enter side_b:");
	float side_b=input.nextInt();
	System.out.println("Enter side_c:");
	float side_c=input.nextInt();
	float semiPerimeter=(side_a+side_b+side_c)/3;
	float area=semiPerimeter*(semiPerimeter-side_a)*(semiPerimeter-side_b)*(semiPerimeter-side_c);
	float result=(float)Math.sqrt(area);
	System.out.println("Area of Triangle:"+result);
	input.close();
}
}
