/*
Declare the variables for the marks of the subjects ‘Tamil’, ‘English’, and ‘French’. 
Initialize or assign them with the scores 95,99 and 100 respectively. 
Print them in separate lines.
*/
package com.handon;
public class Marks {
	public static void main(String[]args) {
		int Tamil=95;
		int English=99;
		int French=100;
		System.out.println("Tamil Mark:"+Tamil);
		System.out.println("English Mark:"+English);
		System.out.println("French Mark:"+French);
		
	}

}
