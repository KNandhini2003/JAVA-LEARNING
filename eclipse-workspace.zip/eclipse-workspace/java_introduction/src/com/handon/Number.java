/*Initialize an integer variable ‘number’ with the value 100.
Then print the value of ‘number’ to the console.
*/

package com.handon;
import java.util.*;
public class Number {
public static void main(String[]args) {
	Scanner input =new Scanner(System.in);
	System.out.println("Enter a number:");
	int number =input.nextInt();
	System.out.println("number:"+number);
	input.close();
}
}
