/*
Electricity bill calculator: Calculate the bill for 30 days based on the given below data.
a)
There are 2 fans of 60W each. Usage of each fan is 6 hours per day.
b)
There are 3 lights of 40W each. Usage of each light is 8 hours per day.
c)
For the other electrical appliances, the total consumption per day is 3000W.
d)
Cost of 1 unit is Rs.6
*/

package com.handon;

public class ElectricityBill {
	public static void main(String[]args) {
	//	Scanner sc=new Scanner(System.in);
		int fan=2*60*6; //2fans of 60W each. Usage of each fan is 6 hours per day.
		int lights=3*40*8;//3 lights of 40W each. Usage of each light is 8 hours per day
		int total_watt=3000+fan+lights;//3 lights of 40W each. Usage of each light is 8 hours per day.
		//System.out.println(total_watt);
		float unit=(float)total_watt/1000;
		//System.out.println(unit);
		System.out.println("Cost for 30 days:"+(unit*6*30));
		
	}

}
