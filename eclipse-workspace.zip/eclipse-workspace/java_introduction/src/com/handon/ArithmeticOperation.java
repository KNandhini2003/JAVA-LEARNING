/*
Write a Java program to add 8 to the given number and then
divide it by 3. Now, the modulus of the quotient is taken with 5,
and then multiply the resultant value by 5. Display the result.
*/
package com.handon;
import java.util.*;
public class ArithmeticOperation {
		public static void main(String[]args) {
			System.out.println("Enter a number:");
			Scanner input=new Scanner(System.in);
			//float number=input.nextFloat();
			int number=input.nextInt();
			number=number+8;
			number=number/3;
			number=number%5;
			number=number*5;
			System.out.println("Result:"+number);
			input.close();
		}
}
