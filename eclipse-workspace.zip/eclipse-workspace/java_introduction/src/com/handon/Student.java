/*Create two variables to store a student's name and his/her age.
Assign/initialize them with the appropriate values and display the data.
*/

package com.handon;
import java.util.*;
public class Student {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a StudentName:");
		String studentName=input.nextLine();
		System.out.println("Enter a StudentAge:");
		int age=input.nextInt();
		System.out.println("StudentName:"+studentName);
		System.out.println("StudentAge:"+age);
		input.close();

}
}