/*Initialize two integer variables ‘six’ and ‘four’ with the values as the name says.
Then, print the values of 'six' and 'four' to the console.
*/

package com.handon;

public class Number1 {
	public static void main(String[]args) {
		int six=6;
		int four=4;
		System.out.println("six:"+six+"\n"+"four:"+four);
	}

}
