/*
Create the variables for a player's name, age, height in cm,
weight in kg, rank, and mobile number, 
and assign the values of your choice.
Display the player detail.
(byte, short, int, double, String datatypes can be used).
*/

package com.handon;

import java.util.*;

public class Player {
	
	public static void main(String[]args) {
		
		Scanner input=new Scanner(System.in);
		String playerName="Tom";
		byte age=20;
		int weight=30;
		int height=150;
		short  rank=14;
		int mobile_No=875631356;
		System.out.println("PlayerName:"+playerName);
		System.out.println("Age:"+age);
		System.out.println("weight:"+weight+"kg");
		System.out.println("height:"+height+"cm");
		System.out.println("rank:"+rank);
		System.out.println("mobile_no:"+mobile_No);
		input.close();
	}
	
}
