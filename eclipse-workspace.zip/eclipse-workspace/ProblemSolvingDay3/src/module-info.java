/**
 * 
 */
/**
 * 
 */
module ProblemSolvingDay3 {
}