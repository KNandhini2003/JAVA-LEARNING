package com.handson;
import java.util.*;
public class KthSmallest30 {

		    public static int kthSmallest(int[] coins, int k) {
		        int left = 1;
		        int right = 2 * (int) Math.pow(10, 9);
		        
		        while (left < right) {
		            int mid = left + (right - left) / 2;
		            if (count(coins, mid) < k) {
		                left = mid + 1;
		            } else {
		                right = mid;
		            }
		        }
		        
		        return left;
		    }
		    
		    private static int count(int[] coins, int amount) {
		        int count = 0;
		        for (int coin : coins) {
		            count += amount / coin;
		        }
		        return count;
		    }

		    public static void main(String[] args) {
		        Scanner scanner = new Scanner(System.in);

		        System.out.print("Enter the number of coins: ");
		        int n = scanner.nextInt();

		        int[] coins = new int[n];
		        System.out.println("Enter the values of coins:");
		        for (int i = 0; i < n; i++) {
		            coins[i] = scanner.nextInt();
		        }

		        System.out.print("Enter the value of k: ");
		        int k = scanner.nextInt();

		        System.out.println("Kth smallest amount: " + kthSmallest(coins, k));

		        scanner.close();
		    }
		}
