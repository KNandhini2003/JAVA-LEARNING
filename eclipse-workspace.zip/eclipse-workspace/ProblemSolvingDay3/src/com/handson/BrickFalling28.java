package com.handson;
import java.util.*;
public class BrickFalling28 {



	    public static int[] hitBricks(int[][] grid, int[][] hits) {
	        int[] result = new int[hits.length];
	        
	        // Remove the hit bricks temporarily
	        for (int[] hit : hits) {
	            grid[hit[0]][hit[1]] = 0;
	        }
	        
	        // Mark all connected bricks to the top row as '2'
	        for (int j = 0; j < grid[0].length; j++) {
	            if (grid[0][j] == 1) {
	                markConnectedBricks(grid, 0, j);
	            }
	        }
	        
	        // Remove remaining top row bricks and mark connected bricks as '1'
	        for (int j = 0; j < grid[0].length; j++) {
	            if (grid[0][j] == 1) {
	                removeBrick(grid, 0, j);
	            }
	        }
	        
	        // Restore hit bricks and check their connected components
	        for (int i = hits.length - 1; i >= 0; i--) {
	            int row = hits[i][0];
	            int col = hits[i][1];
	            
	            grid[row][col] = 1;
	            
	            if (grid[row][col] == 1 && isConnectedToTop(grid, row, col)) {
	                result[i] = markConnectedBricks(grid, row, col) - 1;
	            }
	        }
	        
	        return result;
	    }
	    
	    public static boolean isConnectedToTop(int[][] grid, int row, int col) {
	        return row == 0 || 
	               (row - 1 >= 0 && grid[row - 1][col] == 2) || 
	               (col - 1 >= 0 && grid[row][col - 1] == 2) ||
	               (col + 1 < grid[0].length && grid[row][col + 1] == 2);
	    }
	    
	    public static int markConnectedBricks(int[][] grid, int row, int col) {
	        if (row < 0 || row >= grid.length || col < 0 || col >= grid[0].length || grid[row][col] != 1) {
	            return 0;
	        }
	        
	        grid[row][col] = 2;
	        
	        return 1 + markConnectedBricks(grid, row + 1, col) + 
	                   markConnectedBricks(grid, row - 1, col) +
	                   markConnectedBricks(grid, row, col + 1) + 
	                   markConnectedBricks(grid, row, col - 1);
	    }
	    
	    public static void removeBrick(int[][] grid, int row, int col) {
	        if (row < 0 || row >= grid.length || col < 0 || col >= grid[0].length || grid[row][col] != 1) {
	            return;
	        }
	        
	        grid[row][col] = 0;
	        
	        removeBrick(grid, row + 1, col);
	        removeBrick(grid, row - 1, col);
	        removeBrick(grid, row, col + 1);
	        removeBrick(grid, row, col - 1);
	    }

	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        
	        System.out.print("Enter the number of rows: ");
	        int rows = scanner.nextInt();
	        
	        System.out.print("Enter the number of columns: ");
	        int cols = scanner.nextInt();
	        
	        int[][] grid = new int[rows][cols];
	        System.out.println("Enter the elements of the grid:");
	        for (int i = 0; i < rows; i++) {
	            for (int j = 0; j < cols; j++) {
	                grid[i][j] = scanner.nextInt();
	            }
	        }
	        
	        System.out.print("Enter the number of hits: ");
	        int numHits = scanner.nextInt();
	        
	        int[][] hits = new int[numHits][2];
	        System.out.println("Enter the hits (row column):");
	        for (int i = 0; i < numHits; i++) {
	            hits[i][0] = scanner.nextInt();
	            hits[i][1] = scanner.nextInt();
	        }
	        
	        int[] result = hitBricks(grid, hits);
	        System.out.println("Result: " + Arrays.toString(result));
	        
	        scanner.close();
	    }
	}