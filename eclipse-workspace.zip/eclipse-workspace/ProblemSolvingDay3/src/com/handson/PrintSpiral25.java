package com.handson;
import java.util.*;

public class PrintSpiral25 {

    public static int[][] generateSpiralMatrix(int n) {
        int[][] matrix = new int[n][n];
        int num = 1;
        int top = 0, bottom = n - 1, left = 0, right = n - 1;

        while (num <= n * n) {
            // Traverse from left to right
            for (int i = left; i <= right && num <= n * n; i++) {
                matrix[top][i] = num++;
            }
            top++;

            // Traverse from top to bottom
            for (int i = top; i <= bottom && num <= n * n; i++) {
                matrix[i][right] = num++;
            }
            right--;

            // Traverse from right to left
            for (int i = right; i >= left && num <= n * n; i--) {
                matrix[bottom][i] = num++;
            }
            bottom--;

            // Traverse from bottom to top
            for (int i = bottom; i >= top && num <= n * n; i--) {
                matrix[i][left] = num++;
            }
            left++;
        }

        return matrix;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter the size of the spiral matrix:");
        int n = input.nextInt();
        int[][] spiralMatrix = generateSpiralMatrix(n);

        // Print the spiral matrix
        for (int[] row : spiralMatrix) {
            for (int num : row) {
                System.out.print(num + " ");
            }
            System.out.println();
        }

        input.close();
    }
}
