package com.handson;
import java.util.*;
public class MatrixExponentiation22 {

	    public static double calculateExpectedRolls(int N) {
	        if (N <= 1) return 0;
	        if (N <= 6) return 6;
	        
	        double[] expectedRolls = new double[6];
	        for (int i = 0; i < 6; i++) {
	            expectedRolls[i] = 6;
	        }
	        
	        double totalOfLastSix = 6 * 6;
	        
	        for (int i = 7; i <= N; i++) {
	            double newExpectedRolls = 1 + totalOfLastSix / 6;
	            totalOfLastSix = totalOfLastSix - expectedRolls[(i - 1) % 6] + newExpectedRolls;
	            expectedRolls[(i - 1) % 6] = newExpectedRolls;
	        }
	        
	        return expectedRolls[(N - 1) % 6];
	    }

	    public static void main(String[] args) {
	        Scanner input = new Scanner(System.in);
	        System.out.println("Enter a range:");
	        int T = input.nextInt();
	        
	        for (int t = 0; t < T; t++) {
	        	System.out.println("Enter a number:");
	            int N = input.nextInt();
	            System.out.println(calculateExpectedRolls(N));
	        }
	        
	        input.close();
	    }
	}
