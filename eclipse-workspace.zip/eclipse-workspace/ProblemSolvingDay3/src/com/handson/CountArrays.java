package com.handson;

import java.util.Scanner;

public class CountArrays {
		public static void main(String [] args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a size1:");
		int m =input.nextInt();
		System.out.println("enter a array elements:");
		int arr1[]=new int[m]; 
		 for (int j = 0; j <m; j++) {
	            arr1[j]=input.nextInt();
	     }
//		 input.close();
		 System.out.println("Enter a k:");
			int k =input.nextInt();
			int c = 0;
		 for(int i = 0;i<m;i++) {
			 for(int j=i+1;j<m;j++) {
				 if((arr1[i]*arr1[j]) % k == 0 ) {
					 c++;
				 }
			 }
		 }
		 System.out.println(c);
		 input.close();
		}
}

