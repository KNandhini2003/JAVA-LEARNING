package com.handson;
import java.util.*;
public class MiningDiamond21 {
	    

	    
	    public static int maxCoins(int n, int[] A) {
	        if (n < 3) 
	        	return 0; 
	        int coins = 0;
	        for (int i = 1; i < n - 1; i++) {
	            coins += A[i - 1] * A[i] * A[i + 1];
	        }
	        return coins + A[0] * A[1] + A[n - 2] * A[n - 1]; // Add coins for first and last diamonds
	    }

	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        System.out.print("Enter the number of test cases: ");
	        int t = scanner.nextInt();

	        for (int i = 0; i < t; i++) {
	            System.out.print("Enter the number of diamonds for test case " + (i + 1) + ": ");
	            int n = scanner.nextInt();

	            int[] A = new int[n];
	            System.out.print("Enter the sizes of diamonds: ");
	            for (int j = 0; j < n; j++) {
	                A[j] = scanner.nextInt();
	            }

	            System.out.println("Maximum coins for test case " + (i + 1) + ": " + maxCoins(n, A));
	        }

	        scanner.close();
	    }
	}
