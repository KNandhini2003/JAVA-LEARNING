package com.handson;
import java.util.*;
public class MaximumBuild23 {

	

		    public static int maxBuilding(int n, int[][] restrictions) {
		        int[][] extendedRestrictions = new int[restrictions.length + 1][2];
		        for (int i = 0; i < restrictions.length; i++) {
		            extendedRestrictions[i] = restrictions[i];
		        }
		        extendedRestrictions[restrictions.length] = new int[]{n, n - 1};

		        Arrays.sort(extendedRestrictions, (a, b) -> Integer.compare(a[0], b[0]));

		        for (int i = 1; i < extendedRestrictions.length; i++) {
		            extendedRestrictions[i][1] = Math.min(extendedRestrictions[i][1], 
		                extendedRestrictions[i - 1][1] + (extendedRestrictions[i][0] - extendedRestrictions[i - 1][0]));
		        }

		        for (int i = extendedRestrictions.length - 2; i >= 0; i--) {
		            extendedRestrictions[i][1] = Math.min(extendedRestrictions[i][1], 
		                extendedRestrictions[i + 1][1] + (extendedRestrictions[i + 1][0] - extendedRestrictions[i][0]));
		        }

		        int maxHeight = 0;
		        for (int i = 1; i < extendedRestrictions.length; i++) {
		            int leftIndex = extendedRestrictions[i - 1][0];
		            int rightIndex = extendedRestrictions[i][0];
		            int leftHeight = extendedRestrictions[i - 1][1];
		            int rightHeight = extendedRestrictions[i][1];
		            int maxPossibleHeight = (leftHeight + rightHeight + rightIndex - leftIndex) / 2;
		            maxHeight = Math.max(maxHeight, maxPossibleHeight);
		        }

		        return maxHeight;
		    }

		    public static void main(String[] args) {
		        Scanner input = new Scanner(System.in);
		        System.out.println("ENter a number:");
		        int n = input.nextInt();
		        System.out.println("ENter a number:");
			       
		        int m = input.nextInt();
		        int[][] restrictions = new int[m][2];
		        for (int i = 0; i < m; i++) {
		            restrictions[i][0] = input.nextInt();
		            restrictions[i][1] = input.nextInt();
		        }
		        System.out.println(maxBuilding(n, restrictions));
		        input.close();
		    }
		}
