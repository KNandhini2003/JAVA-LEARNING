package com.handson;
import java.util.*;
public class Circle26 {

	
		    public static int numDartsInsideCircle(int[][] darts, int[] center, int radius) {
		        int count = 0;
		        for (int[] dart : darts) {
		            int dx = dart[0] - center[0];
		            int dy = dart[1] - center[1];
		            if (dx * dx + dy * dy <= radius * radius) {
		                count++;
		            }
		        }
		        return count;
		    }

		    public static int maxDartsInsideCircle(int[][] darts, int radius) {
		        int maxDarts = 0;
		        for (int[] dart : darts) {
		            for (int x = -radius; x <= radius; x++) {
		                for (int y = -radius; y <= radius; y++) {
		                    int[] center = {dart[0] + x, dart[1] + y};
		                    maxDarts = Math.max(maxDarts, numDartsInsideCircle(darts, center, radius));
		                }
		            }
		        }
		        return maxDarts;
		    }

		    public static void main(String[] args) {
		        Scanner input = new Scanner(System.in);
		        System.out.println("Enter the number of darts:");
		        int n = input.nextInt();
		        int[][] darts = new int[n][2];
		        System.out.println("Enter the coordinates of each dart:");
		        for (int i = 0; i < n; i++) {
		            System.out.println("Enter x coordinate of dart " + (i + 1) + ":");
		            darts[i][0] = input.nextInt();
		            System.out.println("Enter y coordinate of dart " + (i + 1) + ":");
		            darts[i][1] = input.nextInt();
		        }
		        System.out.println("Enter the radius of the dartboard:");
		        int radius = input.nextInt();
		        
		        int maxDarts = maxDartsInsideCircle(darts, radius);
		        System.out.println("Maximum number of darts that can lie on the dartboard: " + maxDarts);
		        
		        input.close();
		    }
		}
