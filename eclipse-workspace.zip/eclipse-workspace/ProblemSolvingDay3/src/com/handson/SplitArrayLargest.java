package com.handson;
import java.util.Scanner;

public class SplitArrayLargest {
  private static boolean canSplit(int[] nums, int K, int mid) {
        int count = 1, currentSum = 0;
        for (int num : nums) {
            if (currentSum + num > mid) {
                count++;
                currentSum = num;
                if (count > K) {
                    return false;
                }
            } else {
                currentSum += num;
            }
        }
        return true;
    }

    public static int splitArray(int[] nums, int K) {
        int low = Integer.MIN_VALUE, high = 0;
        for (int num : nums) {
            low = Math.max(low, num);
            high += num;
        }

        while (low < high) {
            int mid = low + (high - low) / 2;
            if (canSplit(nums, K, mid)) {
                high = mid;
            } else {
                low = mid + 1;
            }
        }

        return low;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter the number of elements:");
        int n = input.nextInt();
        int arr1[] = new int[n];
        System.out.println("Enter the array elements:");
        for (int i = 0; i < n; i++) {
            arr1[i] = input.nextInt();
        }
        System.out.println("Enter the number of subarrays:");
        int K1 = input.nextInt();
        System.out.println(splitArray(arr1, K1)); 
        input.close();
    }
}
