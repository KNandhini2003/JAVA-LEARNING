package com.handson;

import java.util.Scanner;

public class ReachingPoints {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a sx:");
		int sx = input.nextInt();
		System.out.println("Enter a sy:");
		int sy = input.nextInt();
		System.out.println("Enter a tx:");
		int tx = input.nextInt();
		System.out.println("Enter a ty:");
		int ty = input.nextInt();
		boolean condition = true;
//		int diffX = tx-sx;
//		int diffY = ty-sy;
//		if(diffX > diffY) {
		while(condition) {
			
			if(sx < tx)
				sx = sx + sy;
			if(sy < ty ) 
				sy = sx + sy;
			if( sx == tx && sy == ty || (sx > tx || sy > sy ))
				condition = false;
			
		}
		if(condition) {
			System.out.print(false);
		}
		else {
			System.out.print(true);
		}
		input.close();
	}
}
