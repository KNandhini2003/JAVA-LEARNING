package com.handson;

import java.util.Scanner;

public class SumOfTwoDigits {
    static boolean prime(int num) {
        if (num <= 1) 
        	return false;
        for (int i = 2; i<= num/2; i++) {
            if (num % i == 0) 
            	return false;
        }
        return true;
    }
		  
	
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a n:");
		int n = input.nextInt();
		int count=0,difference = 0,isPrime=0,first=0,c=0;
		for(int i=2;i<=n;i++){

			if(prime(i)) {
	        	 difference = n-i;
	        	 if(prime(difference)) {
	        	 first = i;
	        	 if(first + difference == n) {
	        		 System.out.println(first+","+difference);
	        		 count = 1;
	        		 break;
	        	 }
	         }
	      }
//			if(count == 1) {
		}
		input.close();
	}
}
