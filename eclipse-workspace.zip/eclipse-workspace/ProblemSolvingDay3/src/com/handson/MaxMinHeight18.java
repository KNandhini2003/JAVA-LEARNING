package com.handson;
import java.util.*;
public class MaxMinHeight18 {

	    public static int maxHeight(int n, int k, int w, int[] a) {
	        int[] prefixSum = new int[n + 1];
	        for (int i = 1; i <= n; i++) {
	            prefixSum[i] = prefixSum[i - 1] + a[i - 1];
	        }
	        
	        int max = 0;
	        for (int i = 1; i <= n; i++) {
	            int j = Math.max(0, i - w);
	            int totalWatered = prefixSum[i] - prefixSum[j];
	            max = Math.max(max, totalWatered);
	            
	            if (i >= w) {
	                int totalDays = Math.min(k, n - i + 1);
	                max += totalDays;
	            }
	        }
	        
	        return max;
	    }

	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        
	        System.out.print("Enter the number of flowers: ");
	        int n = scanner.nextInt();
	        
	        System.out.print("Enter the number of days: ");
	        int k = scanner.nextInt();
	        
	        System.out.print("Enter the width of the window: ");
	        int w = scanner.nextInt();
	        
	        int[] heights = new int[n];
	        System.out.println("Enter the heights of flowers:");
	        for (int i = 0; i < n; i++) {
	            heights[i] = scanner.nextInt();
	        }
	        
	        int result = maxHeight(n, k, w, heights);
	        System.out.println("Maximum height of the smallest flower: " + result);
	        
	        scanner.close();
	    }
	}
