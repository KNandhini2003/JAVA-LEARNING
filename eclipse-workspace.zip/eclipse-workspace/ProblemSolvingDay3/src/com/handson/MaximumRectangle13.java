package com.handson;
import java.util.*;
public class MaximumRectangle13 {


	    public static void main(String[] args) {

	    	    	        Scanner sc = new Scanner(System.in);



	    	    	        System.out.print("Enter the number of test cases: ");

	    	    	        int T = sc.nextInt();



	    	    	        for (int t = 0; t < T; t++) {

	    	    	            System.out.print("Enter the number of rows: ");

	    	    	            int M = sc.nextInt();

	    	    	            System.out.print("Enter the number of columns: ");

	    	    	            int N = sc.nextInt();



	    	    	            int[][] arr = new int[M][N];

	    	    	            System.out.println("Enter the matrix elements:");

	    	    	            for (int i = 0; i < M; i++) {

	    	    	                for (int j = 0; j < N; j++) {

	    	    	                    arr[i][j] = sc.nextInt();

	    	    	                }

	    	    	            }



	    	    	            int maxSum = findMaxSumRectangle(arr, M, N);

	    	    	            System.out.println("The maximum sum rectangle is: " + maxSum);

	    	    	        }



	    	    	        sc.close();

	    	    	    }



	    	    	    private static int findMaxSumRectangle(int[][] arr, int M, int N) {

	    	    	        int maxSum = Integer.MIN_VALUE;

	    	    	        int[] temp = new int[M];



	    	    	        for (int left = 0; left < N; left++) {

	    	    	            for (int i = 0; i < M; i++) {

	    	    	                temp[i] = 0;

	    	    	            }



	    	    	            for (int right = left; right < N; right++) {

	    	    	                for (int i = 0; i < M; i++) {

	    	    	                    temp[i] += arr[i][right];

	    	    	                }



	    	    	                int sum = kadane(temp);

	    	    	                if (sum > maxSum) {

	    	    	                    maxSum = sum;

	    	    	                }

	    	    	            }

	    	    	        }



	    	    	        return maxSum;

	    	    	    }



	    	    	    private static int kadane(int[] array) {

	    	    	        int maxSoFar = Integer.MIN_VALUE;

	    	    	        int maxEndingHere = 0;



	    	    	        for (int value : array) {

	    	    	            maxEndingHere += value;

	    	    	            if (maxSoFar < maxEndingHere) {

	    	    	                maxSoFar = maxEndingHere;

	    	    	            }

	    	    	            if (maxEndingHere < 0) {

	    	    	                maxEndingHere = 0;

	    	    	            }

	    	    	        }



	    	    	        return maxSoFar;

	    	    	    }

	    	    	}



