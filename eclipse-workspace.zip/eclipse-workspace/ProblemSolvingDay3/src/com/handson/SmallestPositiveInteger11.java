package com.handson;
import java.util.*;
public class SmallestPositiveInteger11 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

        System.out.print("Enter the number of elements in the array: ");

        int N = sc.nextInt();

        int[] array = new int[N];



        System.out.println("Enter the elements of the array:");

        for (int i = 0; i < N; i++) {

            array[i] = sc.nextInt();

        }

       Arrays.sort(array);

        long smallestUnrepresentable = 1;



        for (int i = 0; i < N; i++) {

            if (array[i] > smallestUnrepresentable) {

                break;

            }

            smallestUnrepresentable += array[i];

        }



        System.out.println("The smallest positive integer that cannot be represented as a sum is: " + smallestUnrepresentable);

        sc.close();

    }

}