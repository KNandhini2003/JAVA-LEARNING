package com.handson;

import java.util.Scanner;

public class SubarraysWithEqual0 {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a n:");
		int n = input.nextInt();
		int arr[]=new int[n];
		System.out.println("Enter a array elements:");
		for(int i=0;i<n;i++) {
			arr[i]=input.nextInt();
			}
		int sum=0,c=0,set=0;
		for(int i = 0 ; i<n;i++) {
			for(int j=i;j<n;j++) {
				sum=arr[j]+sum;
				set++;
				if(sum==(1+0+2) && set==3) {
					c++;
					break;
				}
			}
			sum=0;set=0;
		}
		System.out.print(c);
	}
}

