package com.handson;

import java.util.Scanner;

public class WaysToExpress {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a n:");
//		double n = input.nextDouble();
//		System.out.print((int)Math.ceil(n));
		int n = input.nextInt();
		int sum = 0,c=0;
		for(int i = 1 ; i < n;i++) {
			sum =0;
			for(int j=i;j<n;j++) {
				if(sum < n)
					sum=sum+j;
				else	
					break;
				
			}
			if(sum == n) {
				c++;
			}
		}
		System.out.print(c);
		input.close();
	}
}
