package com.handson;
import java.util.*;
public class PoorPigs16 {

		    
		    public static int poorPigs(int buckets, int minutesToDie, int minutesToTest) {
		        int tests = minutesToTest / minutesToDie;
		        return (int) Math.ceil(Math.log(buckets) / Math.log(tests + 1));
		    }

		    public static void main(String[] args) {
		        Scanner scanner = new Scanner(System.in);
		        
		        System.out.print("Enter the number of buckets: ");
		        int buckets = scanner.nextInt();
		        
		        System.out.print("Enter minutes to die: ");
		        int minutesToDie = scanner.nextInt();
		        
		        System.out.print("Enter minutes to test: ");
		        int minutesToTest = scanner.nextInt();
		        
		        System.out.println("Minimum number of pigs needed: " + poorPigs(buckets, minutesToDie, minutesToTest));
		        
		        scanner.close();
		    }
		}
