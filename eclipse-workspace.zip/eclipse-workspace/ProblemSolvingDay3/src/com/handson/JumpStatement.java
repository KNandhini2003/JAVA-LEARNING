package com.handson;

import java.util.Scanner;

public class JumpStatement {
	public static void main(String [] args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a number:");
		int t=0,t1=0;
		int n =input.nextInt();
	
//			for(int j =0;j<=10;j++) {
//				System.out.print(j+" ");
//			}
			int re=0;
		for(int i = 0;i<=n;i++) {
			if(i>10) {
			 re=i;
			 while(re!=0) {
			 t=re%10;
			 re=re/10;
			 t1=re%10;
			 
			 
			 if(Math.abs(t-t1)==1) {
				 System.out.print(i+" ");
			 	}
			 }
			}
			 else {
				 System.out.print(i+" ");
			 }
		}
	}
}

