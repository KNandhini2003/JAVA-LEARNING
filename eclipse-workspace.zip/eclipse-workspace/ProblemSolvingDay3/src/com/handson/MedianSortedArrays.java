package com.handson;

import java.util.Arrays;
import java.util.Scanner;

public class MedianSortedArrays {
	public static void main(String [] args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a size1:");
		int m =input.nextInt();
		System.out.println("enter a array elements:");
		int arr1[]=new int[m]; 
		 for (int j = 0; j <m; j++) {
	            arr1[j]=input.nextInt();
	     }
		 
		 System.out.println("Enter a size2:");
		 int n =input.nextInt();
		 System.out.println("enter a array elements:");
		 int arr2[]=new int[n]; 

		 
		 for (int j = 0; j <n; j++) {
			 arr2[j]=input.nextInt();
		 }
		 
		 int arr3[]=new int[n+m];
		 int k = 0;
		 
		 for (int j = 0; j <m; j++) {
			 
			 arr3[k]=arr1[j];
			 k++;
		 }
		 for (int j = 0; j <n; j++) {
			 
			 arr3[k]=arr2[j];
			 k++;
		 }
		 
		 Arrays.sort(arr3);
		 Arrays.sort(arr3);
	        if (arr3.length % 2 == 0) {
	            float median = (arr3[arr3.length / 2] + arr3[(arr3.length / 2) - 1]) / 2.0f;
	            System.out.println("Median: " + median);
	        } else {
	            int medianIndex = (arr3.length - 1) / 2;
	            System.out.println("Median: " + arr3[medianIndex]);
	        }
		 
		 input.close();
	}
	
}
