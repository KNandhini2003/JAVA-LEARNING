package com.handson;
import java.util.*;
public class PerfecctRect24 {

		    public static boolean isRectangleCover(int[][] rectangles) {
		        Set<String> points = new HashSet<>();
		        int area = 0;
		        for (int[] rect : rectangles) {
		            int x1 = rect[0], y1 = rect[1], x2 = rect[2], y2 = rect[3];
		            area += (x2 - x1) * (y2 - y1);
		            String p1 = x1 + "," + y1, p2 = x1 + "," + y2, p3 = x2 + "," + y1, p4 = x2 + "," + y2;
		            if (!points.add(p1)) points.remove(p1);
		            if (!points.add(p2)) points.remove(p2);
		            if (!points.add(p3)) points.remove(p3);
		            if (!points.add(p4)) points.remove(p4);
		        }
		        if (points.size() != 4) return false;
		        int[] bottomLeft = Arrays.stream(points.iterator().next().split(",")).mapToInt(Integer::parseInt).toArray();
		        int[] topRight = Arrays.stream(points.iterator().next().split(",")).mapToInt(Integer::parseInt).toArray();
		        return area == (topRight[0] - bottomLeft[0]) * (topRight[1] - bottomLeft[1]);
		    }

		    public static void main(String[] args) {
		        Scanner input = new Scanner(System.in);
		        System.out.println("Enter the number of rectangles:");
		        int n = input.nextInt();
		        int[][] rectangles = new int[n][4];
		        System.out.println("Enter the coordinates of each rectangle as xi yi ai bi:");
		        for (int i = 0; i < n; i++) {
		            for (int j = 0; j < 4; j++) {
		                rectangles[i][j] = input.nextInt();
		            }
		        }
		        System.out.println("Do the rectangles form an exact cover of a rectangular region? " + isRectangleCover(rectangles));
		        input.close();
		    }
		}

