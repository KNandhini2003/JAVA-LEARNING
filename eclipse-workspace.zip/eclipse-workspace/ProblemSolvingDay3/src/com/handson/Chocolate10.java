package com.handson;
import java.util.*;
public class Chocolate10 {


    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Enter a range:");

        int T = sc.nextInt();  

        for (int t = 0; t < T; t++) {

        	

            

            System.out.println("Enter a array range:");

            int N = sc.nextInt();

            int[] SWEET = new int[N];

            int[] EXPIRY = new int[N];

            System.out.println("Enter a sweet array:");

            

             for (int i = 0; i < N; i++) {

                SWEET[i] = sc.nextInt();

            }

             System.out.println("Enter a expiry array:");

             

           for (int i = 0; i < N; i++) {

                EXPIRY[i] = sc.nextInt();

            }

           System.out.println("Enter a query :");

           

            int Q = sc.nextInt();  // Number of queries

            int[] results = new int[Q];

            System.out.println("Enter a qury elements:");

            

            for (int q = 0; q < Q; q++) {

            	  System.out.println("Enter a x:");

                  

                int X = sc.nextInt();

                System.out.println("Enter a y:");

                

                int Y = sc.nextInt();



                int count = 0;

                for (int i = 0; i < N; i++) {

                    if (SWEET[i] >= X && EXPIRY[i] > Y) {

                        count++;

                    }

                }

                results[q] = count;

            }



            for (int result : results) {

                System.out.println(result);

            }

        }



        sc.close();

    }

}