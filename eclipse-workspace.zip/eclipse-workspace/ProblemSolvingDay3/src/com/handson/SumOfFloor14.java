package com.handson;
import java.util.*;
public class SumOfFloor14 {
	
	    public static int sumOfFlooredPairs(int[] nums) {
		        final int MOD = 1_000_000_007;
		        int maxVal = Arrays.stream(nums).max().getAsInt();
		        
		        int[] freq = new int[maxVal + 1];
		        for (int num : nums) {
		            freq[num]++;
		        }
		        
		        int[] prefixSum = new int[maxVal + 1];
		        for (int i = 1; i <= maxVal; i++) {
		            prefixSum[i] = prefixSum[i - 1] + freq[i];
		        }
		        
		        long result = 0;
		        
		        for (int num : nums) {
		            for (int j = 1; num * j <= maxVal; j++) {
		                result += (long) j * (prefixSum[Math.min(num * (j + 1) - 1, maxVal)] - prefixSum[num * j - 1]);
		                result %= MOD;
		            }
		        }
		        
		        return (int) result;
		    }
		    
		    public static void main(String[] args) {
		        Scanner scanner = new Scanner(System.in);

		        System.out.print("Enter the length of the array: ");
		        int n = scanner.nextInt();

		        int[] nums = new int[n];
		        System.out.println("Enter the elements of the array:");
		        for (int i = 0; i < n; i++) {
		            nums[i] = scanner.nextInt();
		        }
		        
		        System.out.println("Sum of Floored Pairs: " + sumOfFlooredPairs(nums));
		        
		        scanner.close();
		    }
		}
