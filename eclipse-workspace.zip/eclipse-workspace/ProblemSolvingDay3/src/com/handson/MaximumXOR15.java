package com.handson;
import java.util.*;
public class MaximumXOR15 {

	public static int maxSubsetXOR(int[] arr, int n) {
		        int INT_BITS = 32;
		        int[] basis = new int[INT_BITS];
		        
		        for (int num : arr) {
		            for (int i = INT_BITS - 1; i >= 0; i--) {
		                if ((num & (1 << i)) == 0) continue;
		                
		                if (basis[i] == 0) {
		                    basis[i] = num;
		                    break;
		                }
		                
		                num ^= basis[i];
		            }
		        }
		        
		        int maxXOR = 0;
		        for (int i = INT_BITS - 1; i >= 0; i--) {
		            maxXOR = Math.max(maxXOR, maxXOR ^ basis[i]);
		        }
		        
		        return maxXOR;
		    }

		    public static void main(String[] args) {
		        Scanner scanner = new Scanner(System.in);

		        System.out.print("Enter the length of the array: ");
		        int n = scanner.nextInt();

		        int[] arr = new int[n];
		        System.out.println("Enter the elements of the array:");
		        for (int i = 0; i < n; i++) {
		            arr[i] = scanner.nextInt();
		        }

		        System.out.println("Maximum Subset XOR: " + maxSubsetXOR(arr, n));
		        
		        scanner.close();
		    }
		}
/*
8421
1000
0101
1101=13

*/