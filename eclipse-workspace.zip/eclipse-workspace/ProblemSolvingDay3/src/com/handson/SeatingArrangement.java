package com.handson;
import java.util.*;
public class SeatingArrangement {
	static int fact(int n) {
		int factorial = 1;
		for(int i = 1; i <= n ;i++) {
			factorial =factorial * i;
		}
		return factorial;
	}
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a n:");
		int n = input.nextInt();
		System.out.println("Enter a r:");
		int r = input.nextInt();
		if(r<n) {
		double result = (double)fact(n)/(fact(r)*fact(n-r));
		System.out.print("Possible arrangements:"+(int)result);}
		else {
			System.out.print(0);
		}
		input.close();
	}
	
}
