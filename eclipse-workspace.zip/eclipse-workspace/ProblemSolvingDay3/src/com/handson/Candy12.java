package com.handson;

import java.util.*;

public class Candy12 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);



        System.out.print("Enter the number of children: ");

        int N = sc.nextInt();

        int[] ratings = new int[N];



        System.out.println("Enter the ratings of the children:");

        for (int i = 0; i < N; i++) {

            ratings[i] = sc.nextInt();

        }



        int[] candies = new int[N];



        for (int i = 0; i < N; i++) {

            candies[i] = 1;

        }



        for (int i = 1; i < N; i++) {

            if (ratings[i] > ratings[i - 1]) {

                candies[i] = candies[i - 1] + 1;

            }

        }

        for (int i = N - 2; i >= 0; i--) {

            if (ratings[i] > ratings[i + 1]) {

                candies[i] = Math.max(candies[i], candies[i + 1] + 1);

            }

        }



        int totalCandies = 0;

        for (int i = 0; i < N; i++) {

            totalCandies += candies[i];

        }



          System.out.println("The minimum number of candies needed is: " + totalCandies);



        sc.close();

    }

}