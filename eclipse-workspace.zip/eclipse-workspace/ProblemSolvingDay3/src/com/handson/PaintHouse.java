package com.handson;
import java.util.*;
public class PaintHouse {

	
	    public static int minCost(int[][] costs) {
	        int n = costs.length;
	        int k = costs[0].length;

	        int[][] dp = new int[n][k];
	        for (int i = 0; i < k; i++) {
	            dp[0][i] = costs[0][i];
	        }

	        for (int i = 1; i < n; i++) {
	            for (int j = 0; j < k; j++) {
	                dp[i][j] = costs[i][j] + minCostForPreviousHouses(dp, i, j);
	            }
	        }

	        int minCost = Integer.MAX_VALUE;
	        for (int j = 0; j < k; j++) {
	            minCost = Math.min(minCost, dp[n - 1][j]);
	        }

	        return minCost;
	    }

	    public static int minCostForPreviousHouses(int[][] dp, int i, int color) {
	        int minCost = Integer.MAX_VALUE;
	        for (int j = 0; j < dp[0].length; j++) {
	            if (j != color) {
	                minCost = Math.min(minCost, dp[i - 1][j]);
	            }
	        }
	        return minCost;
	    }

	    public static void main(String[] args) {
	        Scanner input = new Scanner(System.in);
	        int T = input.nextInt();

	        for (int t = 0; t < T; t++) {
	            int N = input.nextInt();
	            int K = input.nextInt();
	            int[][] costs = new int[N][K];

	            for (int i = 0; i < N; i++) {
	                for (int j = 0; j < K; j++) {
	                    costs[i][j] = input.nextInt();
	                }
	            }

	            System.out.println(minCost(costs));
	        }

	        input.close();
	    }
	}

