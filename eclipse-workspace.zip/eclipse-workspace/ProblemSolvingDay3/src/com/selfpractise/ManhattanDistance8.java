package com.selfpractise;
import java.util.*;
public class ManhattanDistance8 {


    public static int minimizeMaxDistance(int[][] points) {
        int n = points.length;
        if (n <= 2) 
        	return 0; 
        int[][] dist = new int[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                dist[i][j] = Math.abs(points[i][0] - points[j][0]) + Math.abs(points[i][1] - points[j][1]);
                dist[j][i] = dist[i][j];
            }
        }

        int globalMin = Integer.MAX_VALUE;

         for (int remove = 0; remove < n; remove++) {
            int maxDist = 0;
            for (int i = 0; i < n; i++) {
                if (i == remove) continue;
                for (int j = i + 1; j < n; j++) {
                    if (j == remove) continue;
                    maxDist = Math.max(maxDist, dist[i][j]);
                }
            }
            globalMin = Math.min(globalMin, maxDist);
        }

        return globalMin;
    }

    public static void main(String[] args) {
    	Scanner scanner = new Scanner(System.in);

        System.out.println("Enter no of rows and columns:");
        int m = scanner.nextInt();
        int n = scanner.nextInt();
        
        int[][] point = new int[m][n];

        System.out.println("Enter the elements of the grid:");
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                point[i][j] = scanner.nextInt();
            }
        }

        System.out.println(minimizeMaxDistance(point)); 
        }
}
