package com.selfpractise;
import java.util.*;
public class SelfCross4 {    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.println("Enter length of  array:");
        int length = input.nextInt();
        int[] distance = new int[length];
        
        System.out.println("Enter  elements :");
        for (int i = 0; i < length; i++) {
            distance[i] = input.nextInt();
        }
        
        System.out.println(isSelfCrossing(distance) ? "true" : "false");
        
        input.close();
    }

    public static boolean isSelfCrossing(int[] distance) {
        int n = distance.length;
        for (int i = 3; i < n; i++) {
            if (distance[i] >= distance[i - 2] &&
            		distance[i - 1] <= distance[i - 3]) 
            		return true;
           if (i >= 4 && distance[i - 1] == distance[i - 3] 
        		   && distance[i] + distance[i - 4] >= distance[i - 2])
        	   		return true;
            if (i >= 5 && distance[i - 2] >= distance[i - 4] 
            		&& distance[i] + distance[i - 4] >= distance[i - 2] 
            		&& distance[i - 1] <= distance[i - 3] &&
            		distance[i - 1] + distance[i - 5] >= distance[i - 3]) 
            		return true;
        }
        return false;
    }
}
