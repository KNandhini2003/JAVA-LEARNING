package com.selfpractise;

import java.util.*;

public class MaximumScore {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        int MOD = 1000000007;
        System.out.println("Enter the number of test cases:");
        int t = input.nextInt();
        
        while (t >0 ) {
            System.out.println("Enter the size of the first array:");
            int n = input.nextInt();
            int[] arr1 = new int[n];
            System.out.println("Enter the elements of the first array:");
            for (int i = 0; i < n; i++) {
                arr1[i] = input.nextInt();
            }
            
          System.out.println("Enter the size of the second array:");
            int m = input.nextInt();
            int[] arr2 = new int[m];
            System.out.println("Enter the elements of the second array:");
            for (int i = 0; i < m; i++) {
                arr2[i] = input.nextInt();
            }
            int i = 0, j = 0;
            long sum1 = 0, sum2 = 0, maxScore = 0;
            
            while (i < n && j < m) {
                if (arr1[i] < arr2[j]) {
                    sum1 += arr1[i++];
                } else if (arr1[i] > arr2[j]) {
                    sum2 += arr2[j++];
                } else {
                    maxScore += Math.max(sum1, sum2) + arr1[i];
                    maxScore %= MOD;
                    sum1 = 0;
                    sum2 = 0;
                    i++;
                    j++;
                }
            }
            while (i < n) {
                sum1 += arr1[i++];
            }
            while (j < m) {
                sum2 += arr2[j++];
            }
            maxScore += Math.max(sum1, sum2);
            maxScore %= MOD;
             System.out.println(maxScore);
             t--;
        }
        
        input.close();
    }
}
