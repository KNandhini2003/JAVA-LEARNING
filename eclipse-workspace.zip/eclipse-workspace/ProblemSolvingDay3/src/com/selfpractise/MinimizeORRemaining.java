package com.selfpractise;
import java.util.Scanner;

public class MinimizeORRemaining {
    public static int minBitwiseOR(int[] nums, int k) {
        int n = nums.length;

        for (int op = 0; op < k && n > 1; op++) {
            int[] newNums = new int[n - 1];
            int newIdx = 0;
            for (int i = 0; i < n - 1; i++) {
                newNums[newIdx++] = nums[i] & nums[i + 1];
            }
            nums = newNums;
            n--;
        }

        int result = 0;
        for (int i = 0; i < n; i++) {
            result |= nums[i];
        }

        return result;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the number of elements in the array:");
        int len = scanner.nextInt();
        int[] nums = new int[len];
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < len; i++) {
            nums[i] = scanner.nextInt();
        }
        System.out.println("Enter the number of operations (k):");
        int k = scanner.nextInt();

        int result = minBitwiseOR(nums, k);
        System.out.println("The minimum possible value of the bitwise OR is: " + result);

        scanner.close();
    }
}
