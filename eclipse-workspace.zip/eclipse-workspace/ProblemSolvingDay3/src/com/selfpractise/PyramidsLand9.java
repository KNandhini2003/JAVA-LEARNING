package com.selfpractise;
import java.util.*;
public class PyramidsLand9 {
    public static int countPyramids(int[][] grid) {
        int m = grid.length, n = grid[0].length;
        int[][] pyramids = new int[m][n];
        int[][] inversePyramids = new int[m][n];
        int totalPyramids = 0;

       
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                if (grid[i][j] == 1) {
                    if (i > 0 && j > 0 && j < n - 1) {
                        pyramids[i][j] = Math.min(pyramids[i - 1][j - 1], Math.min(pyramids[i - 1][j], pyramids[i - 1][j + 1])) + 1;
                    } else {
                        pyramids[i][j] = 1;
                    }
                    totalPyramids += pyramids[i][j] - 1;
                }
            }
        }

        
        for (int i = m - 1; i >= 0; i--) {
            for (int j = 0; j < n; j++) {
                if (grid[i][j] == 1) {
                    if (i < m - 1 && j > 0 && j < n - 1) {
                        inversePyramids[i][j] = Math.min(inversePyramids[i + 1][j - 1], Math.min(inversePyramids[i + 1][j], inversePyramids[i + 1][j + 1])) + 1;
                    } else {
                        inversePyramids[i][j] = 1;
                    }
                    totalPyramids += inversePyramids[i][j] - 1;
                }
            }
        }

        return totalPyramids;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter no of rows and columns:");
        int m = scanner.nextInt();
        int n = scanner.nextInt();
        
        int[][] grid = new int[m][n];

        System.out.println("Enter the elements of the grid:");
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                grid[i][j] = scanner.nextInt();
            }
        }

        int result = countPyramids(grid);
        System.out.println("Total no. of pyramidal and inverse pyramidal" + result);

        scanner.close();
    }
}
