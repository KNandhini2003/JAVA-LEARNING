package com.selfpractise;
import java.util.*;
public class MinimumHP {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("Enter the number of test cases:");
        int t = input.nextInt();

        while (t-- > 0) {
            System.out.println("Enter the dimensions of the board (N M):");
            int n = input.nextInt();
            int m = input.nextInt();

            int[][] board = new int[n][m];
            System.out.println("Enter the board values:");
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < m; j++) {
                    board[i][j] = input.nextInt();
                }
            }

            System.out.println("Minimum initial health required: " + calculateMinimumHP(board, n, m));
        }

        input.close();
    }

    public static int calculateMinimumHP(int[][] board, int n, int m) {
        int[][] dp = new int[n][m];
        
        dp[n - 1][m - 1] = Math.max(1, 1 - board[n - 1][m - 1]);

        for (int i = n - 2; i >= 0; i--) {
            dp[i][m - 1] = Math.max(1, dp[i + 1][m - 1] - board[i][m - 1]);
        }

        for (int j = m - 2; j >= 0; j--) {
            dp[n - 1][j] = Math.max(1, dp[n - 1][j + 1] - board[n - 1][j]);
        }

        for (int i = n - 2; i >= 0; i--) {
            for (int j = m - 2; j >= 0; j--) {
                int minHPOnExit = Math.min(dp[i + 1][j], dp[i][j + 1]);
                dp[i][j] = Math.max(1, minHPOnExit - board[i][j]);
            }
        }

        return dp[0][0];
    }
}
