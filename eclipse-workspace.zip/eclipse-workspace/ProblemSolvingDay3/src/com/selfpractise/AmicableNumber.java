package com.selfpractise;
import java.util.*;
public class AmicableNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Scanner input = new Scanner(System.in);
	
	System.out.println("Enter a number1");
	int n = input.nextInt();
	
	System.out.println("Enter a number2");
	int m = input.nextInt();
	int sum1 = 0, sum2 = 0;
	
	for(int i = 1; i<n;i++) {
		if(n%i == 0)
				sum1 +=i;
	}
	for(int i = 1; i<m;i++) {
		if(m%i == 0)
			sum2 +=i;
	}
//	System.out.println("SUm1:"+sum1);
//	System.out.println("SUm2:"+sum2);
	sum1 = sum1 / n;
	sum2 = sum2 /m;
	if(sum1 ==  sum2)
		System.out.println("Yes");
	else
		System.out.println("NO");
	
	input.close();
	
	}

}
