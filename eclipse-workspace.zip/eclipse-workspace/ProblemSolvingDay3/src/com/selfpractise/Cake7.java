package com.selfpractise;
import java.util.*;
public class Cake7 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("Enter the number of chunks (N):");
        int N = input.nextInt();

        System.out.println("Enter the number of friends (K):");
        int K = input.nextInt();

        int[] sweetness = new int[N];
        System.out.println("Enter the sweetness of each chunk:");
        for (int i = 0; i < N; i++) {
            sweetness[i] = input.nextInt();
        }

        System.out.println("The maximum sweetness Geek can get is: " + maximizeSweetness(sweetness, N, K));
        
        input.close();
    }

    public static int maximizeSweetness(int[] sweetness, int N, int K) {
        int left = 1;
        int right = 0;
//        6 3 2 8 7 5
        for (int sweet : sweetness) {
            right += sweet;
        }
        
        while (left < right) {
            int mid = (left + right + 1) / 2;
            if (canDivide(sweetness, N, K, mid)) {
                left = mid;
            } else {
                right = mid - 1;
            }
        }
        
        return left;
    }

    private static boolean canDivide(int[] sweetness, int N, int K, int minSweetness) {
        int currentSum = 0;
        int pieces = 0;

        for (int sweet : sweetness) {
            currentSum += sweet;
            if (currentSum >= minSweetness) {
                pieces++;
                currentSum = 0;
            }
        }
        
        return pieces >= K + 1;
    }
}
