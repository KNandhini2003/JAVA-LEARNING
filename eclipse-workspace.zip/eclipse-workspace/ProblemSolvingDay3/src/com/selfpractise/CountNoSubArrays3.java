package com.selfpractise;

import java.util.*;

public class CountNoSubArrays3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Scanner input = new Scanner(System.in);
			
			System.out.println("Enter a range of array:");
			int n = input.nextInt();	
			System.out.println("Enter a left");
			int l = input.nextInt();	
			System.out.println("Enter a right");
			int r = input.nextInt();	
			int arr1[] = new int[n];
			System.out.println("Enter a array elements:");
			for(int i = 0;i < n; i++) {
				arr1[i] = input.nextInt();
				
			}
//			ArrayList<Integer> arr2 = new 
//					ArrayList<Integer>();
//			for(int i = l;i <= r; i++) {
//				arr2.add(i);
//				
//			}
			int c=0;
			for(int i = 0; i<n;i++) {
				int sum = 0;
				for(int j =i ;j<n;j++) {
					sum = sum + arr1[j];
					if(sum>=l && sum <=r) {
						c++;
						
						
					}
						
				}				
			}
			System.out.println(c);
			
			input.close();
	}

}
