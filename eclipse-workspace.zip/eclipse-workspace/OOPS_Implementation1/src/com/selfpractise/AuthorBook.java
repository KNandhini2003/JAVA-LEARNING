package com.selfpractise;
import java.util.*;


class Author {
    String name;
    String email;
 
    Author(String name, String email) {
        this.name = name;
        this.email = email;
    }
 
    String getName() {
        return name;
    }
 
    String getEmail() {
        return email;
    }
}
 
class Books {
    String bookName;
    Author author;
    double price;
    int qty;
 
    Books(String bookName, Author author, double price, int qty) {
        this.bookName = bookName;
        this.author = author;
        this.price = price;
        this.qty = qty;
    }
 
    String getBookName() {
        return bookName;
    }
 
    String getAuthorName() {
        return author.getName();
    }
 
    String getAuthorEmail() {
        return author.getEmail();
    }
 
    double getPrice() {
        return price;
    }
 
    int getQty() {
        return qty;
    }
}
 
public class AuthorBook {
    public static void main(String args[]) {
        Author author = new Author("NandhiniK ", "2k21cse092@kiot.ac.in");
        Books book = new Books("OOPS", author, 2000, 5);
 
        System.out.println("Book Name: " + book.getBookName());
        System.out.println("Author Name: " + book.getAuthorName());
        System.out.println("Author Email: " + book.getAuthorEmail());
        System.out.println("Book Price: " + book.getPrice());
        System.out.println("Quantity: " + book.getQty());
    }
}
 
