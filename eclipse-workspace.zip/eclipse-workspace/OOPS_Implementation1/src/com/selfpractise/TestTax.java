package com.selfpractise;

class Test {
    private double salary;
    private boolean isPANsubmitted;
    
    public Test(boolean isPANsubmitted , double salary) {
        this.isPANsubmitted = isPANsubmitted;
        this.salary = salary;
    }
    public double getSalary() {
        return salary;
    }

    public boolean getIsPANsubmitted() {
        return isPANsubmitted;
    }
    public double calculateTax() {
        if (salary < 180000) {
            return isPANsubmitted ? 0 : salary * 0.05;
        } else if (salary >= 180000 && salary < 500000) {
            return salary * 0.10;
        } else if (salary >= 500000 && salary < 1000000) {
            return salary * 0.20;
        } else {
            return salary * 0.30;
        }
    }

    public void displayInfo() {
        System.out.println("Salary: " + salary);
        System.out.println("PAN Submitted: " + isPANsubmitted);
        System.out.println("Calculated Tax: " + calculateTax());
    }
    
}
public class TestTax {
    public static void main(String[] args) {
      
        Test tax1 = new Test(false,500000);
        System.out.println("Tax Calculation for Instance 2:");
        
        tax1.displayInfo();
        System.out.println("Tax Calculation for Instance 2:");
        Test tax2 = new Test(true,800000);
        tax2.displayInfo();

    }
}

