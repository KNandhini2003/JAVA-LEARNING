package com.selfpractise;

public class CashRegister {
	private int cashOnHand;
    public CashRegister() {
        this.cashOnHand = 100;
    }

    public CashRegister(int initialCash) {
        if (initialCash >= 0) {
            this.cashOnHand = initialCash;
        } else {
            System.out.println("Invalid initial amount");
            this.cashOnHand = 0;
        }
    }
    public int getCurrentBalance() {
        return cashOnHand;
    }
    
    public void acceptAmount(int amount) {
        if (amount > 0) {
            cashOnHand += amount;
        } else {
            System.out.println("Invalid amount.");
        }
    }

    public static void main(String[] args) {
        CashRegister obj1 = new CashRegister();
        System.out.println(obj1.getCurrentBalance());
        CashRegister obj2 = new CashRegister(500);
        System.out.println("Initial balance:" + obj2.getCurrentBalance());
        obj2.acceptAmount(150);
        System.out.println("Updated balance: " + obj2.getCurrentBalance());
        obj1.acceptAmount(250);
        System.out.println("Updated balance" + obj1.getCurrentBalance());
    }
}
