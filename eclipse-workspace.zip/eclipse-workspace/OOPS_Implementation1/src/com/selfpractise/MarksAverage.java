package com.selfpractise;
import java.util.*;
class Average {

	int mark1;
	int mark2;
	int mark3;
	public void setMarks(int mark1,int mark2,int mark3)
	{
		this.mark1 = mark1;
		this.mark2 = mark2;
		this.mark3 = mark3;
	}
	public int getMarks() {
		return (mark1 + mark2 + mark3)/3;
	}
}
public class MarksAverage {
	 
	 public static void main(String [] args) {
		 Scanner input = new Scanner(System.in);
		 System.out.println("Enter a mark1:");
		 int mark1 = input.nextInt();
		 System.out.println("Enter a mark2:");
		 int mark2 = input.nextInt();
		 System.out.println("Enter a mark3:");
		 int mark3 = input.nextInt();
		 System.out.println("Average MArks:");
		 Average obj = new Average();
		 obj.setMarks(mark1, mark2, mark3);
		 System.out.println(obj.getMarks());
		 input.close();
	 }
 }
