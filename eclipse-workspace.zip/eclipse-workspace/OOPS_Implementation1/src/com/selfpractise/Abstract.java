package com.selfpractise;


abstract class Animal {
	 int  instance ;
 public abstract void abst();

 public void NonAbstract() {
     System.out.println("Zzz...");
 }
// public void NonAbstract() {
//	 System.out.println("Zzz...");
// }
}

//Subclass (inherits from Animal)
class Dog extends Animal {
 public void abst() {
     System.out.println("Dog");
 }
 
}
//they is no need of final keyword in abstract class , so we cant override.
class Abstract {
 public static void main(String[] args) {
     Animal myDog = new Dog(); 
	 Dog obj = new Dog();
	 System.out.println(obj.instance);//why getting o/p because 
	 //it is inherited and constructor invoked my child class constructor..
     myDog.abst();
     myDog.NonAbstract(); 
     System.out.print(myDog.instance);
//     Animal obj = new Animal();
//     obj.NonAbstract();
 }
}
