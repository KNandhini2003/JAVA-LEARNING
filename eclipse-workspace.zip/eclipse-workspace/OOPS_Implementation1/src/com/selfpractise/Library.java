package com.selfpractise;

class Library1 {

    private static int totalBooks = 0;
    
    public static final int MAX_CAPACITY = 10;
    public static void addBook() {
        if (totalBooks < MAX_CAPACITY) {
            totalBooks++;
            System.out.println("Total books added: " + totalBooks);
        } else {
            System.out.println("Cannot add ");
        }
    }
    public static int getTotalBooks() {
        return totalBooks;
    }
}

public class Library {
    public static void main(String[] args) {
        for (int i = 0; i < 10; i++) {
            Library1.addBook();
        }
        System.out.println("Total books:" + Library1.getTotalBooks());
        for (int i = 0; i < 12; i++) {
            Library1.addBook();
        }
        System.out.println("Total books:" + Library1.getTotalBooks());
        
    }
}
