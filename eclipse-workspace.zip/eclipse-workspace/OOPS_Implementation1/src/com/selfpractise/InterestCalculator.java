package com.selfpractise;

class IC {
 
	public static double CompoundInterest(double principal,
			double annualInterestRate, int years) {
		
        double totalAmount = principal * 
        		Math.pow((1 + annualInterestRate / 100), years);
        
        return totalAmount;
    }
	
    public static double InterestOnly(double principal, 
    		double annualInterestRate, int years) {
    	
        double compoundInterest = principal *
        		(Math.pow((1 + annualInterestRate / 100), years) - 1);
        
        return compoundInterest;
    }
}
public class InterestCalculator {
    public static void main(String[] args) {
      
        double principal = 1000;
        double annualInterestRate = 5;
        int years = 5;

        int totalAmount = (int)IC.CompoundInterest(principal, annualInterestRate, years);
        System.out.println("Total amount after CI " + years + " years:" + totalAmount);

       
        int  compoundInterest = (int)IC.InterestOnly(principal, annualInterestRate, years);
        System.out.println("Compound interest earn: " + years + " years:" + compoundInterest);
    }
}
