package com.selfpractise;
import java.util.*;
public class Crop {
	private int carrot;
	private int brinjal;
	private int potato;
	
	private Crop(int c , int b , int p){
		carrot = c;
		brinjal = b;
		potato = p;
	}
	private Crop(int c) {
		carrot = c;
	}
	private Crop(int c , int p){
		carrot = c;
		potato = p;
	}
	 public void displayCrops() {
	        System.out.println("C " + carrot + " P " + potato + " B " + brinjal);
	    }
	 
	 public static void main(String [] args) {
		 Scanner input = new Scanner(System.in);
		 System.out.print("Enter a No.of.carrot:");
		 int carrot = input.nextInt();
		 System.out.print("Enter a No.of.brinjal:");
		 int brinjal = input.nextInt();
		 System.out.print("Enter a No.of.potato:");
		 int potato = input.nextInt();
		 Crop obj1 = new Crop(carrot);
		 obj1.displayCrops();
		 Crop obj2 = new Crop(carrot , brinjal , potato);
		 obj2.displayCrops();
		 Crop obj3 = new Crop(carrot , potato);
		 obj3.displayCrops();
		 input.close();
	 }
}
