package com.selfpractise;

public class Employee {

    private int empId;
    private String name;
    private double salary;
    public Employee(int empId, String name, double salary) {
        this.empId = empId;
        this.name = name;
        this.salary = salary;
    }
    public double calculateYearlySalary(double monthlySalary) {
        return monthlySalary * 12;
    }
   public double calculateYearlySalary(double dailySalary, int daysInYear) {
        return dailySalary * daysInYear;
    }

   public double calculateYearlySalary(double hourlySalary, int hoursPerDay, int daysInYear) {
        return hourlySalary * hoursPerDay * daysInYear;
    }
    public String toString() {
        return "ID: " + empId + ", Name: " + name + ", Salary: " + salary;
    }

    public static void main(String[] args) {
        Employee emp = new Employee(1, "John Doe", 5000);
        System.out.println(emp);  

        System.out.println("employee's yearly salary based "
        		+ "on their monthly salary" + emp.calculateYearlySalary(23000));

        System.out.println("employee's yearly salary"
        		+ " based on their daily salary. : " + emp.calculateYearlySalary(5000 , 360));

       double y = emp.calculateYearlySalary(25, 8, 250);
        System.out.println("Yearly Salary from Hourly Salary: " 
       + y);
    }
}
