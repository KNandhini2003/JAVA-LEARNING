package com.selfpractise;

public class Product {
	
	    private int productId;
	    private String productName;
	    private double price;
	    private int quantity;

	    public Product() {
	        this.productId = 0;
	        this.productName = "Unknown";
	        this.price = 0.0;
	        this.quantity = 0;
	    }
	    public Product(int productId, String productName, double price, int quantity) {
	        this.productId = productId;
	        this.productName = productName;
	        this.price = price;
	        this.quantity = quantity;
	    }
	    public void displayProduct() {
	        System.out.println("Product ID: " + productId);
	        System.out.println("Product Name: " + productName);
	        System.out.println("Price: " + price);
	        System.out.println("Quantity: " + quantity);
	    }
}
