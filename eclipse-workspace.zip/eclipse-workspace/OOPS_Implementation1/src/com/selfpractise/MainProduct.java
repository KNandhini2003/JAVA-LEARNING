package com.selfpractise;

public class MainProduct {

	    public static void main(String[] args) {
	        Product store = new Product();
	        System.out.println("Default Product:");
	        store.displayProduct();
	        Product store1 = new Product(1, "Laptop", 50489, 10);
	        System.out.println("Parameterized Product:");
	        store1.displayProduct();
	    }
}
	


