package com.selfpractise;

class Account {

    protected String accountNumber;
    protected String accountName;
    protected double balance;

    public Account(String accountNumber, String accountName, double initialBalance) {
        this.accountNumber = accountNumber;
        this.accountName = accountName;
        this.balance = initialBalance;
    }
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
        }
    }
    public void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
        } else {
            System.out.println("Insufficient balance.");
        }
    }
    public String getAccountNumber() {
        return accountNumber;
    }

    public String getAccountName() {
        return accountName;
    }

    public double getBalance() {
        return balance;
    }
    public void displayInfo() {
        System.out.println("Account Name: " + accountName);
        System.out.println("Balance: " + balance);
    }
}



class SavingsAccount extends Account {
	    protected double interestRate;

	    public SavingsAccount(String accountNumber, String accountName, double initialBalance, double interestRate) {
	        super(accountNumber, accountName, initialBalance);
	        this.interestRate = interestRate;
	    }

	    public void addInterest() {
	        balance += balance * (interestRate / 100);
	    }

	    public void displayInfo() {
	        super.displayInfo();
	        System.out.println("Interest Rate: " + interestRate + "%");
	    }
}
class CurrentAccount extends Account {
    private double overdraftLimit;
    public CurrentAccount(String accountNumber,
    		String accountName, double initialBalance, double overdraftLimit) {
        super(accountNumber, accountName, initialBalance);
        this.overdraftLimit = overdraftLimit;
    }
    public void withdraw(double amount) {
        if (amount > 0 && amount <= balance + overdraftLimit) {
            balance -= amount;
        } else {
            System.out.println("Insufficient balance and overdraft limit for withdrawal.");
        }
    }
    public double getOverdraftLimit() {
        return overdraftLimit;
    }
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Overdraft Limit: " + overdraftLimit);
    }
}
public class Accounts {
    public static void main(String[] args) {
       
        Account standardAccount = new Account("001", "Standard Account", 1000);
        SavingsAccount savingsAccount = new SavingsAccount("002", "Savings Account", 2000, 3.5);
        CurrentAccount currentAccount = new CurrentAccount("003", "Current Account", 1500, 500);

        System.out.println("Initial Account Info:");
        standardAccount.displayInfo();
        savingsAccount.displayInfo();
        currentAccount.displayInfo();

        System.out.println("Deposit");
        standardAccount.deposit(20000);
        savingsAccount.deposit(1000);
        currentAccount.deposit(5000);

        System.out.println("Withdrawing:");
        standardAccount.withdraw(7000);
        savingsAccount.withdraw(700);
        currentAccount.withdraw(70);

        System.out.println("Account Info after Withdrawals:");
        standardAccount.displayInfo();
        savingsAccount.displayInfo();
        currentAccount.displayInfo();

   
        System.out.println("Adding interest to Savings Account:");
        savingsAccount.addInterest();
        savingsAccount.displayInfo();

        System.out.println("Account overdraft limit");
        currentAccount.withdraw(200880);
        currentAccount.displayInfo();
    }
}

