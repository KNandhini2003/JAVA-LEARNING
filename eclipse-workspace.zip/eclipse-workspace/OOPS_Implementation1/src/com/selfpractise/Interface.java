//package com.selfpractise;
//
//public class Interface {
//
//}
////Define an interface
//interface Animal {
// // Abstract method (does not have a body)
// void makeSound();
////obj we cant access the variable (public static final)
// // Default method (Java 8 and later)
// default void sleep() {
//     System.out.println("Zzz...");
// }
//}
//
////Implement the interface in a class
//class Dog implements Animal {
// public void makeSound() {
//     // The body of makeSound() is provided here
//     System.out.println("Dog");
// }
//}
//
//class Cat implements Animal {
// public void makeSound() {
//     // The body of makeSound() is provided here
//     System.out.println("Meow");
// }
//}
//
//class Main {
// public static void main(String[] args) {
//     Dog myDog = new Dog(); // Create a Dog object
//     myDog.makeSound(); // Call the makeSound method
//     myDog.sleep(); // Call the default method
//
//     Cat myCat = new Cat(); // Create a Cat object
//     myCat.makeSound(); // Call the makeSound method
//     myCat.sleep(); // Call the default method
//     
//     Animal parent = new Animal();
//     
// }
//}
