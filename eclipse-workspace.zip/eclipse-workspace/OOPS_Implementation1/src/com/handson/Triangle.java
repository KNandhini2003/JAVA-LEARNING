package com.handson;

import java.util.Scanner;

public class Triangle {
	 double side1;
	 double side2;
	 double side3;
	
	public void setValue(double a,double b,double c) {
		side1 = a;
		side2 = b;
		side3 = c;
	}
	public double getArea() {
		double semi = (side1+side2+side3)/2;
		double area = semi*(semi - side1)*
				(semi - side2)*(semi - side3);
		
		return Math.sqrt(area);
	}
	public double getPerimeter() {
		double perimeter = side1 + side2 + side3;
		return perimeter;
	}
	public static void main(String [] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter a side1:");
		double a = input.nextDouble();
		System.out.println("Enter a side2:");
		double b = input.nextDouble();
		System.out.println("Enter a side3:");
		double c = input.nextDouble();
		
		Triangle obj = new Triangle();
		obj.setValue(a, b,c);
		System.out.println("Area of rectangle:");
		System.out.println(obj.getArea());
		System.out.println("Perimeter of rectangle:");
		System.out.println(obj.getPerimeter());
		input.close();
	}
	
}

