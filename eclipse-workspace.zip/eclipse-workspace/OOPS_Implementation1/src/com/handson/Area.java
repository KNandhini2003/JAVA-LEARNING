package com.handson;

import java.util.Scanner;

public class Area {
	
	double length;
	double breadth;
	
	public void setDim(double length,double breadth) {
		this.length = length;
		this.breadth= breadth;
	}
	public double getArea() {
		double area = this.length*this.breadth;
		return area;
	}
	public static void main(String [] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter a length:");
		double length = input.nextDouble();
		System.out.println("Enter a breadth:");
		double breadth = input.nextDouble();
		Area obj = new Area();
		obj.setDim(length, breadth);
		System.out.println("Area of rectangle:");
		System.out.println(obj.getArea());
		input.close();
	}
	
}
