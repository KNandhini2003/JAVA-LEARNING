package com.handson;
import java.util.*;
public class School {

	public static int totalStudents;
	
	public static final int max_capacity = 500;
	void enrollStudent() {
//		if(max_capacity > totalStudents)
			totalStudents++;
	
//		else
//			System.out.println("No enrolement accepted.");
	}
	public int getTotalStudents() {
		return totalStudents;
	}
}
	class Main{
	public static void main(String [] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter a no.of student "
				+ "will Enroll");
		School obj = new School();
		int totalStudents = input.nextInt();
		for(int i = 0;i<totalStudents;i++) {
			obj.enrollStudent();
	            if (i > School.max_capacity) {
	            	System.out.println("No enrolement accepted.");
	                break;
	                
	            }
	        }
		int avail = 0;
		if(School.max_capacity > totalStudents)
			 avail = School.max_capacity - obj.getTotalStudents();
		else
			avail = 0;
		System.out.println("Enrolled students:"
					+obj.getTotalStudents());
		System.out.println("Remaining seats:"+avail);
		
		input.close();	
	
		}
		
	}

