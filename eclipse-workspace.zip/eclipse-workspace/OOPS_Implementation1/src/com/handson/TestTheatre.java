package com.handson;

public class TestTheatre {
	    public static void main(String[] args) {

	        Theatre theatre1 = new Theatre();
	        theatre1.details(1021, "ABC Theatre", 3, "Salem");

	        Theatre theatre2 = new Theatre();
	        theatre2.details(1022, "XYZ Theatre", 2, "Chennai");
	    }
	}


