package com.handson;

public class Student {
    public int studentID;
    public String studentName;
    public int age;
    public String grade;
    public Student() {
        studentID = 0;
        studentName = "Unknown";
        age = 0;
        grade = "Unknown";
        System.out.println("Student  Details:");
        System.out.println("ID: " + studentID);
        System.out.println("Name: " + studentName);
        System.out.println("Age: " + age);
        System.out.println("Grade: " + grade);
    }
    public Student(int id, String name, int age, String grade) {
        this.studentID = id;
        this.studentName = name;
        this.age = age;
        this.grade = grade;
        System.out.println("Student  Details:");
        System.out.println("ID: " + studentID);
        System.out.println("Name: " + studentName);
        System.out.println("Age: " + age);
        System.out.println("Grade: " + grade);
    }
}
