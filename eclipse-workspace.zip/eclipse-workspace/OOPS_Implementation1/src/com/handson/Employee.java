package com.handson;

import java.util.Scanner;

public class Employee {

	double salary;
	int hours;
	public void getInfo(double salary,int hours) {
		this.salary = salary;
		this.hours = hours;
	}
	 public void AddSal() {
		 if(salary < 500) {
			 salary += 10; }
//		 return salary;
	 }
	 public void AddWork() {
		 if(hours > 6) {
			 salary += 5; }
//		 return salary;
	 }
	 public void display() {
		 AddSal() ;
		 AddWork();
		 System.out.println("Final Salary:"+salary);
	 }
	 public static void main(String [] args) {
		 Scanner input = new Scanner(System.in);
		 System.out.println("Enter a salary:");
		 double salary = input.nextDouble();
		 System.out.println("Enter a Hours:");
		 int hours = input.nextInt();
		 Employee obj = new Employee();
		 obj.getInfo(salary,hours);
		 obj.display();
		 input.close();
	 }
}
