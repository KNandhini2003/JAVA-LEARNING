package com.handson;

public class Bank {
    private int accountNo;
    private String accountHolderName;
    private double accountBalance = 2000;


    public void setAccountNumber(int accountNo ) {
        if (accountNo > 0) {
            this.accountNo = accountNo;
        } else {
            System.out.println("Invalid account number. Account number must be positive.");
        }
        
    }
    public void setAccountHolderName(String accountHolderName) {
        if (!accountHolderName.isEmpty()) {
            this.accountHolderName = accountHolderName;
        } else {
            System.out.println("Invalid account holder name.");
        }
    }
    public void setAccountBalance(double accountBalance) {
        if (accountBalance >= 0) {
            this.accountBalance = accountBalance;
        } else {
            System.out.println("Invalid account balance. Balance cannot be negative.");
        }
    }
    public void getAccountBalance() {
       System.out.println("Account Balance:" + accountBalance);
    }

    public void deposit(double amount) {
        if (amount > 0) {
            accountBalance += amount;
            System.out.println("Deposit successful." + accountBalance);
        } else {
            System.out.println("Invalid amount for deposit.");
        }
    }

    public void withdraw(double amount) {
        if (amount > 0 && accountBalance >= amount) {
            accountBalance -= amount;
            System.out.println("Withdrawal successful." + accountBalance);
        } else {
            System.out.println("Invalid amount");
        }
        
    }

    public static void main(String[] args) {
        Bank account = new Bank();
        account.setAccountNumber(3456456);
        account.setAccountHolderName("Nandhini");
        account.getAccountBalance();
        account.deposit(5000);
        account.withdraw(2000);
    }
}
