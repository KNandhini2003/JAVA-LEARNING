package com.handson;
import java.util.*;
public class Circle {
	
	private double radius;
	private String color;
	public Circle(){
		radius = 1.0;
		color = "red";
	}
	public Circle(double radius){
		this.radius = radius;
	}
	public Circle(double radius,String color){
		this.radius = radius;
		this.color = color;
	}
	public double getRadius() {
		return radius;
	}
	public String getColor() {
		return color;
	}
	public void setRadius(double radius) {
		this.radius = radius;
	}
	public void setColor(String color) {
		this.color= color;
	}
	public String toString() {
		return this.color;
	}
	public double getArea() {
		return 3.14*radius*radius;
	}
	public static void main(String [] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter a radius:");
		double radius = input.nextDouble();
		System.out.println("Enter a radius:");
		String color = input.next();
		Circle obj1 = new Circle();
		Circle obj2 = new Circle(radius);
		Circle obj3 = new Circle(radius,color);
		System.out.println(obj1.getRadius());
		System.out.println(obj1.getColor());
		obj1.setRadius(radius);
		obj1.setColor(color);
		System.out.println(obj1.toString());
		System.out.println("Area of circle:");
		System.out.println(obj1.getArea());
		
		input.close();
	}
	
}









