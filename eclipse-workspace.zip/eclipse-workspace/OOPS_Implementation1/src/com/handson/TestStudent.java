package com.handson;

public class TestStudent {

	    public static void main(String[] args) {
	        Student student1 = new Student();
	        Student student2 = new Student(123, "Dad", 15, "56th Grade");
	      
	    }
	}


