package com.handson;

public class Theatre {

	int theatreId;
	String theatreName;
	int screens;
	String location;
	void details(int id,String name,
			int screen,String loc) {
		theatreId = id;
		theatreName = name;
		screens = screen;
		location = loc;
		System.out.println("TheatreId:"+theatreId );
		System.out.println("Theatre Name:"+theatreName );
		System.out.println("Theatre screens:"+screens );
		System.out.println("Theatre location:"+location );
		
	}
}
