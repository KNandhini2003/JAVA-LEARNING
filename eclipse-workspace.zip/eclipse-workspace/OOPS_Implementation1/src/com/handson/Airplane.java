package com.handson;
import java.util.*;
public class Airplane {

	private int flightNo;
	private String destination;
	private float distance;
	private float fuel;
	private void calFuel() {
	    if (distance <= 1000) {
            fuel = 500;
        } else if (distance > 1000 && distance <= 2000) {
            fuel = 1100;
        } else {
            fuel = 2200;
        }
    }
    public void feedInfo() {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter flight number:");
        flightNo = input.nextInt();
        input.nextLine();
        System.out.println("Enter destination:");
        destination = input.nextLine();
        System.out.println("Enter distance:");
        distance = input.nextFloat();

        calFuel();
        input.close();
    }
    public void showInfo() {
        System.out.println("Flight Number: " + flightNo);
        System.out.println("Destination: " + destination);
        System.out.println("Distance: " + distance);
        System.out.println("Fuel: " + fuel);
    }

    public static void main(String[] args) {
        Airplane flight = new Airplane();
        flight.feedInfo();
        flight.showInfo();
    }
}
	

	

