package com.handson;
import java.util.*;
public class Main1 {
	
	    public static void main(String[] args) {
	        Scanner input = new Scanner(System.in);
	        System.out.println("Enter temperature in Celsius:");
	        double celsius = input.nextDouble();
	        double fahrenheit = TemperatureConverter.celsiusToFahrenheit(celsius);
	        System.out.println("Fahrenheit: " + fahrenheit);
	        System.out.println("Enter temperature in Fahrenheit:");
	        double fahrenheitInput = input.nextDouble();
	        double celsiusConverted = TemperatureConverter.fahrenheitToCelsius(fahrenheitInput);
	        System.out.println("Equivalent temperature in Celsius: " + celsiusConverted);

	        input.close();
	    }
	}

