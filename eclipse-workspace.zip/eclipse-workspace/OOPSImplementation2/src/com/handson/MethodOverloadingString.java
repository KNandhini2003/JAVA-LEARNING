package com.handson;


class StringOperations {

    public void  processString(String str) {
        System.out.println("Upper Case:" + str.toUpperCase());
    }

    public  String processString(String str, String check) {
        
    		String s = "";
           for(int i = 0 ; i < str.length() ; i++) {
        	   
        	   s += str.charAt(i);
           }
        	
        if(check.equalsIgnoreCase(s))
            return "Reverse String equals to check string";
        
    	
    		return "Reverse String Not equals to check string";
    	
    		
	}	
    
    public int processString(int length, String str) {
        return str.length() ;
    }
}
public class MethodOverloadingString {
    public static void main(String[] args) {
        String input = "NandhiNi";
        StringOperations op = new StringOperations();
        op.processString(input);
        System.out.println(op.processString(10, input));
        System.out.println(op.processString(input, "Good"));
    }
}
