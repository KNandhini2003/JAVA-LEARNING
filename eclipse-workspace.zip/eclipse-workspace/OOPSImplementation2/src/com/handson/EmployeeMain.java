package com.handson;

abstract class Employee {
	 protected int employeeID;
	 protected String name;
	  public abstract void calculateSalary();
	 
	 void display(int employee , String name) {
		 System.out.println("EmployeeID:" + employee);
		 System.out.println("Employee Name:" + name);
	 }
}

class FullTimeEmployee extends Employee{
	 double salary;
	 FullTimeEmployee(double salary){
		 this.salary = salary;
	 }
	 
	 public void calculateSalary() {
		 System.out.println("FullTimeEmployee Salary:"+salary);
	 }
}
class PartTimeEmployee extends Employee{
	double salary;
	double hourlyRate;
	int hoursWorked;
	PartTimeEmployee(double hourlyRate , int hoursWorked) {
		
		this.hourlyRate = hourlyRate;
		this.hoursWorked = hoursWorked;
	}
	public void calculateSalary() {
		
		salary = hourlyRate * hoursWorked;
		System.out.println("PartTimeEmployee Salary:"+salary);
	}
}
class ContractEmployee extends Employee{
	
	int contractDuration;
	int fixedMonthly; 
	double salary;
	ContractEmployee(int contractDuration ,int fixedMonthly )
	{
		this.contractDuration = contractDuration;
		this.fixedMonthly = fixedMonthly;
	}
	public void calculateSalary() {
		
		salary = contractDuration * fixedMonthly;
		System.out.println("ContractEmployee Salary:"+salary);
	}
} 

public class EmployeeMain {

		public static void main(String [] args) {
			
			FullTimeEmployee full = new FullTimeEmployee(15000);
			full.display(1,"Nandhini");
			full.calculateSalary();
			PartTimeEmployee part = new PartTimeEmployee(24,10);
			part.display(2, "Sam");
			part.calculateSalary();
			ContractEmployee cont = new ContractEmployee(8,20000);
			cont.display(3, "Ram");
			cont.calculateSalary();
		}
}
