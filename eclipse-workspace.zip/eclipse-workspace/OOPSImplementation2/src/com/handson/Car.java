package com.handson;

class Vehicle {
	String brand;
	int year;
	String model;
	void displayInfo(String brand , int year) {
		this.brand = brand;
		this.year = year;
		System.out.println("Vehicle Brand:"+brand);
		System.out.println("Manufactured Year:"+year);
	}
    void displayCarInfo() {
    	this.model = "X5";
        System.out.println("Vehicle Brand: " + brand);
        System.out.println("Car Model: " + model);
        System.out.println("Manufactured Year: " + year);
    }
}
public class Car extends Vehicle{

	public static void main(String [] args) {
		Car obj = new Car();
		obj.displayInfo("TATA",1900);
		obj.displayInfo("BMW", 2023);
		obj.displayCarInfo();
	}
	
}
