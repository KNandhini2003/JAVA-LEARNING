package com.handson;

class AreaCalculator {
	
    private  double calculateArea(double length, double width , String name) {
        return length * width;
    }
    
    private double calculateArea(int radius) {
        return Math.PI * radius * radius;
    }
    
    private double calculateArea(double base, double height) {

            return 0.5 * base * height;
    }

    	
    public void display() {
    	System.out.println("Area of Circle:" + calculateArea(5) );
    	System.out.println("Area of Rectangle:" + calculateArea(10,20,"hi"));
    	System.out.println("Area of Triangle:" + calculateArea(3,10) );
    	
    }
}
public class CirRecTri {
    public static void main(String[] args) {
        
    	AreaCalculator obj = new AreaCalculator();
    	obj.display();
    }
}
