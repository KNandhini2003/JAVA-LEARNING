package com.handson;

public class ArrayDifferentOperation {

    public  void processArray(int[] arr) {
        int sum = 0;
        for (int number : arr) {
            sum += number;
        }
       System.out.println("Sum of Array Elements:" + sum);
    }
    public void processArray(int[] arr, double Max) {
        int max = Integer.MIN_VALUE;
        for (int i = 0 ; i < arr.length ; i++) {
            if (arr[i] > max) {
                max = arr[i];
            }
        }
        System.out.println("MAximum Array Element:" + max);
    }

   public void processArray(float [] arr) {
	   double sum = 0;
       for (int i = 0 ; i < arr.length ; i++) {
           
               sum += arr[i];
           }
       
       System.out.println("Average of Array"+ ""
       		+ " elements:"+ (sum / arr.length));
    }

    public static void main(String[] args) {
        int[] array = {5, 3, 8, 2, 7};
        ArrayDifferentOperation obj = new ArrayDifferentOperation();
        obj.processArray(array);
        
        obj.processArray(array, 0);

        float doubleArray[] = {2.5f, 3.7f, 1.8f, 4.2f, 2.1f};
        obj.processArray(doubleArray);
    }
}
