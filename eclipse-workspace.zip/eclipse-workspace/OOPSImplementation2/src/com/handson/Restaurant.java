package com.handson;

abstract class MenuItem {
	protected String name;
	protected float price;
	MenuItem(String name , float price){
		this.name = name;
		this.price = price;
	}
	abstract void Cook();
//	void display() {
//		System.out.println("Item Name:" + name);
//		System.out.println("Item Price:" + price);
//	}
}
class Burger extends MenuItem {
		
		Burger(String name , float price){
			super(name , price);
		}
		void Cook() {
			
			System.out.println("Item Name:" + name);
			System.out.println("Item Price:" + price);
			System.out.println("Burger Ready..!");
		}
		
}
class Pizza extends MenuItem {
	
	Pizza(String name , float price){
		super(name , price);
	}
	void Cook() {
		
		System.out.println("Item Name:" + name);
		System.out.println("Item Price:" + price);
		System.out.println("Pizza Ready..!");
		
	}
	
}

public class Restaurant {

	public static void main(String [] args) {
		
		Pizza obj1 = new Pizza("VegPizza",250);
		obj1.Cook();
		Burger obj2 = new Burger("EggBurger",150);
		obj2.Cook();
	}
}
