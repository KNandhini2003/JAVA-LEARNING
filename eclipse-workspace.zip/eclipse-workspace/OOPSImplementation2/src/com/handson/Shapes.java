package com.handson;

abstract class Shape {

	abstract double CalculateArea(); 
	
}
final class Circle1 extends Shape {
	
	double radius ;
	Circle1(double radius){
		this.radius = radius;
	}
	
	public double CalculateArea() {
		
		return  Math.PI * radius * radius;
		
	}

	
}
final class Rectangle1 extends Shape {
	
	double length ;
	double breadth ;
	Rectangle1(double length , double breadth){
		this.length = length;
		this.breadth = breadth;
		
	}
	
	public double CalculateArea() {
		
		return  length * breadth;
		
	}

}



public class Shapes {
	public static void main(String [] args) {
		
		Rectangle1 rec = new Rectangle1(20,10);
		System.out.println("Area of Rectangle:\n");
		System.out.println(rec.CalculateArea());
		
		
		Circle1 cir = new Circle1(20);
		System.out.println("Area of Circle:");
		System.out.println(cir.CalculateArea());
		
	}
}





