package com.handson;

interface Vehicle1 {
	void start();
	void stop();
}

interface ElectricVehicle {
	void charge();
}
interface GasVehicle {
	void refuel();
}

class ElectricCar implements Vehicle1,ElectricVehicle {
	
    public void start() {
        System.out.println("Electric car started");
    }

    public void stop() {
        System.out.println("Electric car stopped");
    }
    public void charge() {
        System.out.println("Electric car charging");
    }
    public void refuel() {
    	System.out.println("Electric car charging");
    }
}

class GasMotorcycle implements Vehicle1,GasVehicle {
	
    public void start() {
        System.out.println("GasMotorcycle started");
    }

    public void stop() {
        System.out.println("GasMotorcycle stopped");
    }
    public void refuel() {
    	System.out.println("GasMotorcycle refuel");
    }
}


public class Vehicles {

	public static void main(String [] args) {
        ElectricCar electricCar = new ElectricCar();
        GasMotorcycle gasMotorcycle = new GasMotorcycle();
        System.out.println("Hyundai Kona  Electric Car:");
        electricCar.start();
        electricCar.charge();
        electricCar.stop();
        System.out.println("KTM   Motorcycle:");
        gasMotorcycle.start();
        gasMotorcycle.refuel();
        gasMotorcycle.stop();
	}
}
