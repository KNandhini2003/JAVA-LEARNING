package com.handson;

abstract class Product {

	protected String name;
	protected float price;
	
	Product( String name ,float price ){
		
		this.name = name;
		this.price = price;
		
	}
	abstract void  AddToCart();
	protected double GetDiscountedPrice(float discount) {
		
		return price - (price * (discount / 100));
		
	}
	
		
}
class Book extends Product{
	
	Book ( String name ,float price ){
		
		super(name,price);
	}
	void AddToCart() {
		System.out.println("Product Name:" + name);
		System.out.println("Product price:" + price);
		
	}
	
}
class Electronics extends Product{
	
	Electronics ( String name ,float price ){
		
		super(name,price);
	}
	void AddToCart() {
		System.out.println("Product Name:" + name);
		System.out.println("Product price:" + price);
		
	}
	
}
public class ECommerce {
	
	public static void main(String [] args) {
		
		Book book = new Book("Java Program",500);
		book.AddToCart();
		System.out.println("Discount cost:" 
		+ book.GetDiscountedPrice(20)+"!!");
		
		Electronics electronics = new Electronics("Fan",5000);
		electronics.AddToCart();
		System.out.println("Discount cost:" 
				+ electronics.GetDiscountedPrice(15)+"!!");
		
	}
}



