package com.handson;

interface IShape {

	public void CalculateArea(); 
	public void CalculatePerimeter();
	
}
class Circle implements IShape {
	
	double radius ;
	Circle(double radius){
		this.radius = radius;
	}
	
	public void CalculateArea() {
		
		double area = Math.PI * radius * radius;
		System.out.println("Area of Circle :" + area);
	}
	public void CalculatePerimeter() {
		
		double perimeter = 2 * Math.PI * radius;
		System.out.println("Perimeter of Circle :" + perimeter);
	}
	
}
class Rectangle implements IShape {
	
	double length ;
	double breadth ;
	Rectangle(double length , double breadth){
		this.length = length;
		this.breadth = breadth;
		
	}
	
	public void CalculateArea() {
		
		double area = length * breadth;
		System.out.println("Area of Circle :" + area);
	}
	public void CalculatePerimeter() {
		
		double perimeter = 2*(length + breadth);
		System.out.println("Perimeter of Circle :" + perimeter);
	}
	
}



public class ShapeCalculator {
	public static void main(String [] args) {
		
		Rectangle rec = new Rectangle(20,10);
		rec.CalculateArea();
		rec.CalculatePerimeter();
		
		Circle cir = new Circle(20);
		cir.CalculateArea();
		cir.CalculatePerimeter();
	}
}





