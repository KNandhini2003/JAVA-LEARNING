package com.selfpractise;

abstract class IShape {

	public abstract void CalculateArea(); 
	public abstract void CalculatePerimeter();
	
}
class Circle extends IShape {
	
	double radius ;
	Circle(double radius){
		this.radius = radius;
	}
	
	public void CalculateArea() {
		
		double area = Math.PI * radius * radius;
		System.out.println("Area of Circle :" + area);
	}
	public void CalculatePerimeter() {
		
		double perimeter = 2 * Math.PI * radius;
		System.out.println("Perimeter of Circle :" + perimeter);
	}
	
}
class Rectangle extends IShape {
	
	double length ;
	double breadth ;
	Rectangle(double length , double breadth){
		this.length = length;
		this.breadth = breadth;
		
	}
	
	public void CalculateArea() {
		
		double area = length * breadth;
		System.out.println("Area of Circle :" + area);
	}
	public void CalculatePerimeter() {
		
		double perimeter = 2*(length + breadth);
		System.out.println("Perimeter of Circle :" + perimeter);
	}
	
}
class Triangle extends IShape {
	
	double base ;
	double height ;
	double s1;
	double s2;
	double s3;
	
	Triangle(double base , double height , double s1 , 
			double s2 , double s3){
		this.base = base;
		this.height = height;
		this.s1 = s1;
		this.s2 = s2;
		this.s3 = s3;
				
	}
	
	public void CalculateArea() {
		
		double area = base * height * 0.5;
		System.out.println("Area of Triangle :" + area);
	}
	public void CalculatePerimeter() {
		
		double perimeter = (s1 + s2 + s3);
		System.out.println("Perimeter of Triangle :" + perimeter);
	}
	
}



public class CriRecTri {
	public static void main(String [] args) {
		
		Rectangle rec = new Rectangle(20,10);
		rec.CalculateArea();
		rec.CalculatePerimeter();
		
		Circle cir = new Circle(20);
		cir.CalculateArea();
		cir.CalculatePerimeter();
		
		Triangle tri = new Triangle(2,5,6,3,4);
		tri.CalculateArea();
		tri.CalculatePerimeter();
	}
}





