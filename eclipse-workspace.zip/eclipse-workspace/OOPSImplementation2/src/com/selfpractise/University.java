package com.selfpractise;

public class University {

	public static void main(String [] args) {
		
		Person []object = new Person[]{
			
				new Faculty("Diya" , 35 ,"Teacher",987653221, 15000),
				
				new UndergraduateStudent("Nandhini",20 ,"Student",824,90,"CSE"),
				
				new GraduateStudent("Pavithra",20,"Student",934,92,"CSE")
				
		};
		for(Person p:object)
		{
			
		p.displayInfo();
		}
		
		
	}
}

class Person {
	
	private String name;
	private int age;
	private String designation;
	private long phone;
	
	Person(String name ,int age ,String designation ,long phone){
		this.name = name;
		this.age = age;
		this.designation = designation;
		this.phone = phone; 
	}
	void displayInfo() {
		System.out.println("Name:"+ name);
		System.out.println("age:"+ age);
		System.out.println("designation:"+designation);
		System.out.println("phone:"+ phone);
		
	}
}

class Faculty extends Person{
	double Salary ;
	Faculty(String name ,int age ,String designation 
			,long phone,double Salary){
		super(name , age , designation , phone);
		this.Salary = Salary;
		
	}
	void displayInfo() {
		super.displayInfo();
		System.out.println("Salary:"+ Salary);
	}
}
class UndergraduateStudent extends Person{
	double score ;
	String course ;
	
	UndergraduateStudent(String name ,int age ,String designation 
			,long phone,double score , String course){
		super(name , age , designation , phone);
		this.score = score;
		this.course = course;
		
	}
	void displayInfo() {
		super.displayInfo();
		System.out.println("score:"+ score);
		System.out.println("course:"+ course);
	}
}
class GraduateStudent extends Person{
	double score ;
	String course ;
	
	GraduateStudent(String name ,int age ,String designation 
			,long phone,double score , String course){
		super(name , age , designation , phone);
		this.score = score;
		this.course = course;
		
	}
	void displayInfo() {
		super.displayInfo();
		System.out.println("score:"+ score);
		System.out.println("course:"+ course);
	}
}
