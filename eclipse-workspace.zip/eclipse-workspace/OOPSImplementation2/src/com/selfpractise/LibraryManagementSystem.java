package com.selfpractise;

public class LibraryManagementSystem {

	void libraryDetails(String Title) {
		System.out.println("Title of Book:" + Title);
		System.out.println("Author of Book :Swathi");
		System.out.println("Book in 502 rack.");
	}
	void libraryDetails(String Title , String Author) {
		System.out.println("Title of Book:" + Title);
		System.out.println("Author of Book:" + Author);
		
		System.out.println("Book in 503 rack.\n"
				+ "Have a new Learning!!!");
		
	}
	void libraryDetails(String Title , String Author , int ISBN) {
		
		System.out.println("Title of Book:" + Title);
		System.out.println("Author of Book:" + Author);
		System.out.println("ISBN Number:" + ISBN);
		
		System.out.println("Book in 504 rack.\n"
				+ "Have a new Learning!!!");
	}
	
	public static void main(String [] args) {
	LibraryManagementSystem l = new LibraryManagementSystem();
	l.libraryDetails("AIML");
	l.libraryDetails("Maths Book" , "Pavithra");
	l.libraryDetails( "History Book","Nandhini", 234);
	}
}
