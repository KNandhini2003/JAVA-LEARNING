package com.selfpractise;

class Account {

    protected String accountNumber;
    protected String accountName;
    protected double balance;

    public Account(String accountNumber, String accountName, double initialBalance) {
        this.accountNumber = accountNumber;
        this.accountName = accountName;
        this.balance = initialBalance;
    }
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
        }
    }
    public void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
        } else {
            System.out.println("Insufficient balance.");
        }
    }
    public void displayInfo() {
        System.out.println("Account Name: " + accountName);
        System.out.println("Balance: " + balance);
    }
}



class SavingAccount extends Account {
	    protected double interestRate;

	    public SavingAccount(String accountNumber, String accountName,
	    		double initialBalance, double interestRate) {
	        super(accountNumber, accountName, initialBalance);
	        this.interestRate = interestRate;
	    }

	    public void addInterest() {
	        balance += balance * (interestRate / 100);
	    }

	    public void displayInfo() {
	        super.displayInfo();
	        System.out.println("Interest Rate: " + interestRate + "%");
	        addInterest();
	    }
}
class CurrentAccount extends Account {
    private double overdraftLimit;
    public CurrentAccount(String accountNumber,
    		String accountName, double initialBalance, double overdraftLimit) {
        super(accountNumber, accountName, initialBalance);
        this.overdraftLimit = overdraftLimit;
    }
    public void withdraw(double amount) {
        if (amount > 0 && amount <= balance + overdraftLimit) {
            balance -= amount;
        } else {
            System.out.println("Insufficient balance and overdraft limit for withdrawal.");
        }
    }

    public void displayInfo() {
        super.displayInfo();
        System.out.println("Overdraft Limit: " + overdraftLimit);
    }
}
public class Accounts1 {
    public static void main(String[] args) {
       
        Account std = new Account("001", "Standard Account", 1000);
        std.displayInfo();
        std.deposit(20000);
        std.withdraw(7000);
        SavingAccount sav = new SavingAccount("002", "Savings Account", 2000, 34);
        sav.displayInfo();
        sav.deposit(30000);
        sav.withdraw(2359);
        CurrentAccount cur = new CurrentAccount("003", "Current Account", 1500, 500);
        cur.displayInfo();
        cur.deposit(30000);
        cur.withdraw(2359);


    }
}

