package com.selfpractise;


interface Vehicle2 {
	public void start();
	public void stop();
	
}


class Car implements Vehicle2 {
	
    public void start() {
        System.out.println("Electric car started");
    }

    public void stop() {
        System.out.println("Electric car stopped");
    }
}

class Motorcycle implements Vehicle2 {
	
    public void start() {
        System.out.println("GasMotorcycle started");
    }

    public void stop() {
        System.out.println("GasMotorcycle stopped");
    }
    public void refuel() {
    	System.out.println("GasMotorcycle refuel");
    }
}
class Truck implements Vehicle2 {
	
	public void start() {
		System.out.println("Truck started");
	}
	
	public void stop() {
		System.out.println("Truck stopped");
	}
}

public class TypesOfVehicle { 

	public static void main(String [] args) {
        Car car = new Car();
        Motorcycle motorcycle = new Motorcycle();
        Truck truck = new Truck();
        System.out.println("Hyundai Kona  Electric Car:");
        car.start();
        car.stop();
        System.out.println();
        System.out.println("KTM   Motorcycle:");
        motorcycle.start();
        motorcycle.stop();
        System.out.println();
        System.out.println("Mahendra Trucks");
        truck.start();
        truck.stop();
        
        
	}
}
