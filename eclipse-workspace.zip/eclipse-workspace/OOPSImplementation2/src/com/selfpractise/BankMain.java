package com.selfpractise;

public class BankMain {
		 public static void main(String[] args) {
		     BankAccount b = new BankAccount("123456", 1000, 25);
		     b.deposit(500);
		     b.getAccountDetails();

		     SavingsAccount s = new SavingsAccount("7891011", 20000, 3, 10);
		     s.getAccountDetails();
		     s.deposit(300);
		     s.withdraw(100);
		     

		     FixedDepositAccount f = new FixedDepositAccount("12131415", 5000, 4, 10, 24);
		     f.deposit(1000);
		     f.getAccountDetails();
		 
		 }
		
}


class BankAccount {
 protected String accountNumber;
 protected double balance;
 protected double interestRate;

 public BankAccount(String accountNumber,
		 double balance, double interestRate) {
     this.accountNumber = accountNumber;
     this.balance = balance;
     this.interestRate = interestRate;
 }

 public void deposit(double amount) {
     if (amount > 0) {
         balance += amount;
         System.out.println("Deposited: " + amount);
     } else {
         System.out.println("Deposit amount must be positive.");
     }
 }
 public void getAccountDetails() {
     System.out.println("AccountNumber:" + accountNumber );
     System.out.println("Balance:" + balance);
     System.out.println("InterestRate:"+ interestRate);
 }

}


class SavingsAccount extends BankAccount {
 private double minimumBalance;

 public SavingsAccount(String accountNumber, double balance,
		 double interestRate, double minimumBalance) {
     super(accountNumber, balance, interestRate);
     this.minimumBalance = minimumBalance;
 }

 public void withdraw(double amount) {
     if (amount > 0 ) {
    	 if(Math.abs(amount -minimumBalance) > minimumBalance) {
         balance -= amount;
         System.out.println("Withdrawn: " + amount);
    	 }
         else {
        	 System.out.println("Withdrawn not"
        	 		+ " accepted minimumBalance exclude ");
         }
     }
    	 else
          	 System.out.println("Not accepted"); 

 }
}


class FixedDepositAccount extends SavingsAccount {
 private int term; 

 public FixedDepositAccount(String accountNumber, double balance, 
		 double interestRate, double minimumBalance, int term) {
     super(accountNumber, balance, interestRate, minimumBalance);
     this.term = term;
 }

 public void getInterest() {
	 
	 System.out.println("Simple Interset with term :"+ term);
	 System.out.println( balance * (interestRate / 100) * (term / 12.0)); 
 }

}
