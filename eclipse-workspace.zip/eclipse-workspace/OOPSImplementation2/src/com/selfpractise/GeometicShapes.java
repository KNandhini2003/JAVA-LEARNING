package com.selfpractise;

/*interface Shape1 {

	public void CalculateArea(); 
	public void CalculatePerimeter();
	
}
class Circle1 implements Shape1 {
	
	double radius ;
	Circle1(double radius){
		this.radius = radius;
	}
	
	public void CalculateArea() {
		
		double area = Math.PI * radius * radius;
		System.out.println("Area of Circle :" + area);
	}
	public void CalculatePerimeter() {
		
		double perimeter = 2 * Math.PI * radius;
		System.out.println("Perimeter of Circle :" + perimeter);
	}
	
}
class Rectangle1 implements Shape1 {
	
	double length ;
	double breadth ;
	Rectangle1(double length , double breadth){
		this.length = length;
		this.breadth = breadth;
		
	}
	
	public void CalculateArea() {
		
		double area = length * breadth;
		System.out.println("Area of Circle :" + area);
	}
	public void CalculatePerimeter() {
		
		double perimeter = 2*(length + breadth);
		System.out.println("Perimeter of Circle :" + perimeter);
	}
	
}

*/


import com.handson.ShapeCalculator;

public class GeometicShapes {
	public static void main(String [] args) {
		
		Rectangle rec = new Rectangle(20,10);
		rec.CalculateArea();
		rec.CalculatePerimeter();
		
		Circle cir = new Circle(20);
		cir.CalculateArea();
		cir.CalculatePerimeter();
	}
}





