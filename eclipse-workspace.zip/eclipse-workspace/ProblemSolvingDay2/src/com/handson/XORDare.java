package com.handson;
import java.util.*;
public class XORDare {


    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a size");
        int size = sc.nextInt();  
        System.out.print("Enter a K element");
            int K = sc.nextInt();  
            int[] arr = new int[size];
            System.out.print("Enter a array elements:");
            for (int i = 0; i < size; i++) {
                arr[i] = sc.nextInt();
            }
            
          
            int maxStrength = 0;      
            int numSubsets = 1 << size;  
            for (int mask = 1; mask < numSubsets; mask++) {
                int currentXOR = 0;
                
                for (int i = 0; i < size; i++) {
                    if ((mask & (1 << i)) != 0) {
                        currentXOR ^= arr[i];
                    }
                }
                
                maxStrength = Math.max(maxStrength, currentXOR ^ K);
            }
            
            System.out.println(maxStrength);
            sc.close();
        }
        
      
    }

