package com.handson;

import java.util.Scanner;

public class Diamond {
	public static void main(String [] args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a range:");
		int range = input.nextInt();
		for(int i = 1 ; i <= range ; i++) {
			for(int j = 1 ; j <= range ; j++) {
				if(i==1 || j==1 || j==range||i==range) {
					System.out.print("*");
				}
				else if(i == (range/2)+1 || j == (range/2)+1) {
					System.out.print(" ");
				}
				else {
					System.out.print("*");
				}
				
			}System.out.println();
		}
		input.close();
	}
}
//		int r,r1;
//		if(range %2 == 0) {
//			r=range/2;
//		}
//		else {
//			r=range/2+1;
//		}
//		int m=r;
//		for(int i = 1 ; i <= r ;i++ ) {
//			for(int j = m; j >= 1 ;j-- ) {
//				
//				System.out.print("*"+"");
//			}
//			for(int k=2;k<i*2;k++) {
//				System.out.print(" ");
//			}
//			for(int j = m-1; j >=1 ;j-- ) {
//				
//				System.out.print("*");
//			}
//			m--;
//			
//			System.out.println();
//		}
//		//int m1=range;
////		for(int i = 1 ; i <= range ;i++ ) {
////			for(int k=1;k<=i;k++) {
////				System.out.print(" ");
////			}
////			for(int j = m1; j >= 1 ;j-- ) {
////				
////				System.out.print("*");
////			}
////			System.out.println();
////			m1--;
////		}
//		
//		input.close();
//	}
//	
//}
