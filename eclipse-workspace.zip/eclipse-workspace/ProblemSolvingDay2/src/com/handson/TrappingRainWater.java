package com.handson;

import java.util.Arrays;
import java.util.Scanner;

public class TrappingRainWater {
	public static void main(String [] args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a number:");
		int size = input.nextInt();
		int num[] = new int[size];
		System.out.println("Enter a array elemnts 1:");
		for(int i = 0 ; i < size ; i++) {
			num[i] = input.nextInt();
			
		}
		int num1[] = new int[size];
		for(int i = 0 ; i < size ; i++) {
			num1[i] = num[i];
			
		}
		
		Arrays.sort(num1);
		int sum = 0;
		
		for(int i = 0 ; i < size ; i++) {
			for(int j = i+1 ; j < size ; j++) {
				if(num1[i] == num1[j]) {
					for(int k = j ; k < size-1 ; k++) {
						num1[k] = num1[k+1];
					}
					size--;
				}
			
			}
			
		}
		int max = 0;
		if(num1.length == 1) {
			max = num1[0];
			System.out.println(0);
		}
		else if(num1.length == 2) {
			max = num1[num1.length - 1];
		}
		else
		{
			max = num1[size-2];
		
		for(int i = 0 ; i < size ; i++) {
			if(max > num[i])
				sum += Math.abs(num[i] - max ) ;
		}
		}
		System.out.println(sum);
		input.close();
	}
}
