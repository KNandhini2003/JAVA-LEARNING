package com.handson;

import java.util.Scanner;

public class ClosestDivisor {
	public static void main(String [] args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a number:");
		int number = input.nextInt();
		int a = number + 1;
		int b = number + 2;
		int min =Integer.MAX_VALUE,diff=0,f1=0,f2=0;
		int arr[]=new int[3];
		int arr1[]=new int[3];
		for(int i = 1; i <= Math.sqrt(a); i++) {
			if(a % i == 0) {
				f1 = a/i;
				f2 = i;
				diff=Math.abs(f1-f2);
				if(min > diff) {
					min = diff;
					arr[1]=f1;
					arr[2]=f2;
					arr[0]=min; }
			}
		}
		int min1 =Integer.MAX_VALUE,diff1=0,f3=0,f4=0;
		for(int i = 1; i <= Math.sqrt(b); i++) {
			if(b % i == 0) {
				f3 = b/i;
				f4 = i;
				diff1=Math.abs(f3-f4);
				if(min1 > diff1) {
					min1 = diff1;
					arr1[1]=f3;
					arr1[2]=f4;
					arr1[0]=min1;
			}
		}
		}
		if(arr1[0]>arr[0]) {
			System.out.println(arr[2]+" "+arr[1]);
		}
		else {
			System.out.println(arr1[2]+" "+arr1[1]);
		}
		input.close();
	}
}
