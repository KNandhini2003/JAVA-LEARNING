package com.handson;

import java.util.*;
public class DecodeXORPermutation {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("Enter the size of the encoded array:");
        int size = input.nextInt();
        
    int[] encoded = new int[size];
        System.out.println("Enter the encoded array elements:");
        for (int i = 0; i < size; i++) {
            encoded[i] = input.nextInt();
        }
        
  int[] perm = decode(encoded);

        System.out.println("The original permutation is:");
        for (int num : perm) {
            System.out.print(num + " ");
        }
        
        input.close();
    }
    
    public static int[] decode(int[] encoded) {
        int n = encoded.length + 1;
        
    int totalXor = 0;
        for (int i = 1; i <= n; i++) {
            totalXor ^= i;
        }
        
     int evenXor = 0;
        for (int i = 1; i < encoded.length; i += 2) {
            evenXor ^= encoded[i];
        }

        int firstElement = totalXor ^ evenXor;

        int[] perm = new int[n];
        perm[0] = firstElement;
        for (int i = 0; i < encoded.length; i++) {
            perm[i + 1] = perm[i] ^ encoded[i];
        }
        
        return perm;
    }
}
