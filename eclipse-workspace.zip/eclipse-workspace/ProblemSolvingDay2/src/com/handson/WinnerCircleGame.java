package com.handson;

import java.util.Scanner;

public class WinnerCircleGame {

		public static void main(String [] args) {
			Scanner input=new Scanner(System.in);
			System.out.println("Enter a friends:");
			int n = input.nextInt();
			System.out.println("Enter next Kfriends:");
			int k = input.nextInt();
			int winner = 0;
			for(int i = 1 ; i <= n;i++) {
				
				winner=(winner+k)%i;
			}
			System.out.print(winner+1);
			input.close();
		}
}
