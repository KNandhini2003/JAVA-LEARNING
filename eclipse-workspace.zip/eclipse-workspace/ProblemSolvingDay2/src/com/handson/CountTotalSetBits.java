package com.handson;

import java.util.Scanner;

public class CountTotalSetBits {
	public static void main(String [] args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a number:");
		int number = input.nextInt();
		int sum=0;
		for(int i =1 ;i<=number;i ++) {
//			System.out.println(display(i));
			sum=sum+display(i);
		}
		System.out.print(sum);
		input.close();
	}
	static int display(int number) {
		String dup="";
		while(number!=0) {
			dup=dup+(number%2);
			number/=2;
		}
		int c=0;
		for(int i = 0;i<dup.length();i++) {
			if(dup.charAt(i) == '1')
				c++;
		}
		return c;
	}
}
