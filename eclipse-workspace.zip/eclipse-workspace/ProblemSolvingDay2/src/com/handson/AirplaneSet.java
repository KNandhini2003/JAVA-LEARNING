package com.handson;

import java.util.Scanner;

public class AirplaneSet {
	public static void main(String [] args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a seat:");
		float seat = input.nextFloat();
		if(seat==1)
			System.out.printf("%f",seat);
		else {
			System.out.printf("%f",(seat-1)/seat);
		}
		input.close();
	}
}
