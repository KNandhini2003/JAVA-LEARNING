package com.handson;

import java.util.Scanner;

public class MinimumAbsoluteDifference {
	public static void main(String [] args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a number:");
		int size = input.nextInt();
		int num1[] = new int[size];
		System.out.println("Enter a array elemnts 1:");
		for(int i = 0 ; i < size ; i++) {
			num1[i] = input.nextInt();
			
		}

		int num2[] = new int[size];
		System.out.println("Enter a array elemnts 2:");
		for(int i = 0 ; i < size ; i++) {
			num2[i] = input.nextInt();
			
		}
		int max = Integer.MIN_VALUE;
		int min = Integer.MAX_VALUE;
		int sum = 0 , index = 0;
		boolean c = true;
		for(int i = 0 ; i < size ; i++) {
			if(num1[i] != num2[i])
				c = false;
		}
		if(c) {
			System.out.println("absolute difference is 0");
		}
		else {
		for(int i = 0 ; i < size ; i++) {				
				if( max < num1[i]) {
					max = num1[i];
					index = i;}
				if(min > num1[i])
					min = num1[i];
				
					
			}
			
		
		num1[index] = min;
		for(int i = 0 ; i < size ; i++) {	
			sum += Math.abs(num1[i] - num2[i]);
		}
		System.out.println(sum % (109+7));
		}
		input.close();
	}
}
