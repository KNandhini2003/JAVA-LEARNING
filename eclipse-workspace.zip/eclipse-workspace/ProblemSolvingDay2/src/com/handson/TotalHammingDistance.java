package com.handson;

import java.util.Scanner;

public class TotalHammingDistance {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a array size:");
		int size = input.nextInt();
		int array[]=new int[size];
		System.out.println("Enter a array elements:");
//		int max=Integer.MIN_VALUE;
		for(int i = 0 ;i<size;i++) {
			array[i]=input.nextInt();
			
		}
		int sum=0;
		for(int i = 0;i<size;i++) {
			for(int j=i+1;j<size;j++) {
				sum=sum+display(array[i],array[j]);
			}
		}
		System.out.println(sum);
		input.close();
	}
	static int display(int x,int y) {			
				String bit1="";
				while(x != 0) {
					bit1=(x%2) +bit1;
					x/=2;
				}
				String bit2="";
				while(y != 0) {
					bit2=(y%2) +bit2;
					y/=2;
				}
				int length = Math.abs(bit1.length() - bit2.length());
				for (int i = 0; i < length; i++) {
		            if (bit1.length() < bit2.length()) {
		                bit1 = "0" + bit1; 
		            } else {
		                bit2 = "0" + bit2; 
		            }
		        }
				int count=0;

				for( int i = 0 ; i < bit1.length() ; i++) {
					
					if( bit1.charAt(i) != bit2.charAt(i)) {
						count ++;
					}
					
				}
				return count;
				
			}
		}


