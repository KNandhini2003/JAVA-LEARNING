package com.handson;

import java.util.Scanner;

public class KadaneAlgorithm {
	public static void main(String [] args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a number:");
		int size = input.nextInt();
		int arr[] = new int[size];
		System.out.println("Enter a array elemnts:");
		for(int i = 0 ; i < size ; i++) {
			arr[i] = input.nextInt();
			
		}
		int max = Integer.MIN_VALUE;
		int sum = 0;
		for(int i = 0 ; i < size ; i++) {
			for(int j = i ; j< size ;j++) {
				sum = sum + arr[j];
				
				if( max < sum)
					max = sum;
				
			}
			sum = 0;
		}
		System.out.println(max);
		input.close();
	}
}
