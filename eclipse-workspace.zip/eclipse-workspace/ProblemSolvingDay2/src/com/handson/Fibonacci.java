package com.handson;
import java.util.*;
public class Fibonacci {
	public static void main(String [] args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a number:");
		int number = input.nextInt();
		int sum=1;
		int f1=0,f2=1;
		
        for (int i = 2; i <= number; i++) {
            int c = (f1 + f2) % 1000000007;
            sum = (sum + c) % 1000000007;
            f1 = f2;
            f2 = c;
        }
		System.out.println(sum);
		input.close();
	}
}
