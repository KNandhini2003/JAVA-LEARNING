package com.handson;

import java.util.Scanner;

public class TriangleOfNumbers {
	public static void main(String [] args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a range:");
		int range = input.nextInt();
		int left=1,l=2,temp=0;
		for(int i = 1;i<=range;i++) {
			for(int j=range-i;j>=1;j--) {
				System.out.print(" ");
			}
			left=i;
			for(int k=1;k<=i;k++) {
				System.out.print(left);
				left++;
			}
			if(i==2) {
				
			temp=2; 
			}
			int t=temp;
			for(int k=2;k<=i;k++) {
//				temp=2*i;
				System.out.print(t);
				t--;
			}
			temp=temp+2;
				l=l+2;
			System.out.println();
		}
		input.close();
	}
}
