package com.handson;

import java.util.Arrays;
import java.util.Scanner;

public class MissingRepeating {
	public static void repeating(int arr[],int size){
		int max = 0;
		int index = 0 , c = 0;
		for(int i = 0 ; i < size ; i++) {
			for(int j = 0 ; j< size ;j++) {
				if(arr[i] ==  arr[j]) {
					c++;
					index = i;
				}
			}
				if(max < c) {
					max = c;
				}
			c=0;
		}
		System.out.println(arr[index]);
	
		Arrays.sort(arr);
		int sum = 0;
		for(int i = 0 ; i < size ; i++){
//			if(arr[i] != arr[i+1]) {
				sum = sum + arr[i];
				
//			}
		}
		int res = Math.abs(size*(size+1)/2  -(sum - arr[index]));
		System.out.println(res);
		 
	}
	public static void main(String [] args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a number:");
		int size = input.nextInt();
		int arr[] = new int[size];
		System.out.println("Enter a array elemnts:");
		for(int i = 0 ; i < size ; i++) {
			arr[i] = input.nextInt();
		}
		repeating(arr,size);

		input.close();
	}
}
