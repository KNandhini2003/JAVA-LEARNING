package com.handson;

import java.util.Scanner;

public class WaterBottle {


    static int Bottles(int numBottles, int numExchange) {
        int totalDrunk = 0;
        int emptyBottles = 0;

        while (numBottles > 0) {
            totalDrunk += numBottles; 
            emptyBottles += numBottles; 
            numBottles = 0;  
          if (emptyBottles >= numExchange) {
                int newFullBottles = emptyBottles / numExchange;
                emptyBottles %= numExchange;  
                numBottles += newFullBottles;  
                numExchange++;
            } else {
                break;  
            }
        }

        return totalDrunk-1;
    }

    public static void main(String[] args) {
	    	Scanner input= new Scanner(System.in);
	    
	    	System.out.println("Enter anumber of bottles:");
	    	int  bottle = input.nextInt();
	    	System.out.println("Enter anumber of exchange:");
	    	int  exchange = input.nextInt();
	    

        System.out.println(Bottles(bottle, exchange)); 
        
    }
}
