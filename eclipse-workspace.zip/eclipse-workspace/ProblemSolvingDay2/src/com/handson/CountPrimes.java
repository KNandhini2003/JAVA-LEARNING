package com.handson;

import java.util.Scanner;

public class CountPrimes {
	public static void main(String [] args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a number:");
		int n =input.nextInt();
		int c=0,counter=0;
		for(int i=2;i<n;i++){
	         counter=0;
	         for(int j=1;j<=i;j++){
	            if(i%j==0){
	               counter++;
	            }
	         }
	         if(counter==2)
	         c++;
	      }
		System.out.print(c);
		input.close();
	}
}