package com.handson;

import java.util.Scanner;

public class OnefulPair {
	public static void main(String [] args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a number1:");
		int a = input.nextInt();
		System.out.println("Enter a number2:");
		int b = input.nextInt();
		int res= a+b+(a*b);
		String onePair="";
		onePair=onePair+res;
		boolean check=true;
		for(int i=0;i<onePair.length()-1;i++) {
			if(onePair.charAt(i)!=onePair.charAt(i+1))
			{
				check=false;
				break;
			}
		}
		if(check)
			System.out.println("Yes");
		else
			System.out.println("No");
		input.close();
	}
}
