package com.handson;

import java.util.Scanner;

public class WateringPlant {
		public static void main(String [] args) {
		Scanner input = new Scanner(System.in);	
		System.out.println("Enter a array size:");
		int size = input.nextInt();
		int array[]=new int[size];
		System.out.println("Enter a array elements:");
		int max=Integer.MIN_VALUE;
		int sum = 0;
		for(int i = 0 ;i<size;i++) {
			array[i]=input.nextInt();
		}
		System.out.println("Enter a capacity:");
		int cap = input.nextInt();
		int capacity = cap;
		
		
		for(int i = 0 ; i < size ; i++) {
			
			if(array[i] <= capacity ) {
//				sum = capacity -array[i] + sum;
				sum++;
				capacity = capacity - array[i] ;
				
				
			}
			
			if( array[i] > capacity) {
					sum += i*2;
					capacity = cap - array[i] ;
			}
		}
		System.out.print(sum-1);
		input.close();
	}
}
