package com.handson;
import java.util.*;
public class SingleNumber {
	public static void main(String [] args) {
	
	Scanner input = new Scanner(System.in);
	
	System.out.println("Enter a array size:");
	int size = input.nextInt();
	int array[]=new int[size];
	System.out.println("Enter a array elements:");
	int max=Integer.MIN_VALUE;
	for(int i = 0 ;i<size;i++) {
		array[i]=input.nextInt();
		
	}
	for(int i = 0 ;i<size;i++) {
	if(max<array[i]) {
		max=array[i];
	}
	}
	int f[]=new int[max+1];
	for(int i=0;i<size;i++) {
		f[array[i]]++;
	}
	for(int i=0;i<f.length;i++) {
		if(f[i]==1) {
			System.out.print(i);
		}
	}
	input.close();
	
	
	
	}
}
//	for(int i=0 ; i < size ; i++) {
//		
//		for(int j = i+1 ; j < size ; j++) {
//			
//			if(array[i]==array[j]) {
//
//				for(int k=j;k<size-1;k++) {
//					array[k]=array[k+1];
//				}
//				
//				size--;
//			}
//		}
//	}
//	Arrays.sort(array);
//	for(int i=0 ; i < size-1 ; i++) {
//		if(array[i]!=array[i+1]) {
//			System.out.println(array[i+1]);
//		}
//	}
//	
	


