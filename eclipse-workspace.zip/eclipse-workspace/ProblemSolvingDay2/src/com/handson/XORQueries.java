package com.handson;

import java.util.Scanner;

public class XORQueries {
	
		public static void main(String [] args) {
		
		 
		Scanner input = new Scanner(System.in);
		int sum = 0;
		System.out.println("Enter a size of array:");
		int size = input.nextInt();
		int arr[] = new int[size];
		System.out.println("Enter a array elements:");
		for(int i = 0 ; i < size ; i++) {
			
			arr[i] = input.nextInt();
			
		}
		System.out.println("Enter a query elements:");
		int query[] = new int[size + size];
		for(int i = 0 ; i < query.length ; i++) {
			
			query[i] = input.nextInt();
			
		}
		for(int i = 0 ; i < query.length-1 ; i=i+2) {
			
			for(int j = query[i] ; j<= query[i+1]; j++) {
				
				sum = arr[j] ^ sum;
			}
			System.out.print(sum+" ");
			sum = 0;
		}
		
		input.close();
	}
}






