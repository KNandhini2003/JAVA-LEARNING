package com.handson;

import java.util.Scanner;

public class KthFactor {
	public static void main(String [] args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a number:");
		int number = input.nextInt();
		System.out.println("Enter a factor:");
		int factor = input.nextInt();
		display(number,factor);
		//System.out.println(kFactor);
		input.close();
	}
	static void display(int number,int factor) {
		 String str = "";
		 
		 for(int i = 1; i <= number ; i++) {
			 if(number%i==0) {
				 str=str + i + ",";
			 }
		 }
		// System.out.println(str);
		 String arr[]=str.split(",");
		System.out.println(arr[factor-1]);
		 
	}
}
