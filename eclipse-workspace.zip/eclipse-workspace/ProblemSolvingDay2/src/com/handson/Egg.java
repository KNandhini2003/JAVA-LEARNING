package com.handson;

import java.util.Scanner;

public class Egg {
	public static void main(String [] args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a floor:");
		int floor = input.nextInt();
		int c =0,egg=1;
		while(floor >0) {
			floor=floor - egg;
		//	System.out.println(floor +" ");
			c++;
			egg++;
		}
		System.out.println(c);
		input.close();
	}
}
