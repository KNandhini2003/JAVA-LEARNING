package com.handson;

import java.util.Arrays;
import java.util.Scanner;

public class Arraysort {
	public static void main(String [] args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a number:");
		int n =input.nextInt();
		System.out.println("enter a array elements:");
		int arr[]=new int[n]; 
		 for (int j = 0; j < n; j++) {
	            arr[j]=input.nextInt();
	        }
		input.close();
		Arrays.sort(arr);
		for (int j = 0; j < n; j++) {
            System.out.print(arr[j]+" ");
        }
		input.close();
	}

}
