/*
 Special Numbers
Problem statement : Number is a special number if it’s digits only consist 0, 1, 2, 3, 4 or 5.
Given a number N and we have to find N-th Special Number.

Input:
N = 6
Output: 5
Explanation: First 6 numbers are ( 0, 1, 2, 3, 4, 5 )

 */
package com.handson;

import java.util.Scanner;

public class SpecialNumber {
		public static void main(String[] args) {
			Scanner sc=new Scanner(System.in);
			System.out.print("enter a  number : ");
			int n=sc.nextInt();
			int count=0;
			int i=0;
			while(count<n) {

			int temp=i;
			int flag=1;
			while(temp>0) {
			if(temp%10>5) {
			flag=0;
			break;
			}
			temp/=10;

			}
			if(flag==1){
			count++;
			}
			i++;
	}
	System.out.println(i-1);		
	sc.close();
}
}
