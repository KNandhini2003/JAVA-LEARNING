package com.handson;
import java.util.*;
public class MinimizeMaximumPairSum {
	public static void main(String [] args) {
	Scanner input = new Scanner(System.in);	
	System.out.println("Enter a array size:");
	int size = input.nextInt();
	int array[]=new int[size];
	System.out.println("Enter a array elements:");
	int max=Integer.MIN_VALUE;
	int sum = 0;
	for(int i = 0 ;i<size;i++) {
		array[i]=input.nextInt();
	}
	Arrays.sort(array);
	for(int i = 0 ; i < size/2 ; i++) {
		sum = array[i] + array[size - 1 - i];
		if(sum > max) {
			max = sum;
		}
	}
	System.out.println(max);
	input.close();
	}
}
