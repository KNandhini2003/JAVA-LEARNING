package com.handson;

import java.util.Scanner;

public class StarPattern {
	public static void main(String [] args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a range:");
		int range = input.nextInt();
		for(int i = 1 ; i <= range ;i++ ) {
		for(int k=1;k<=i;k++) {
			System.out.print("*");
			
		}
		System.out.println();
	}
		input.close();
	}
}
