package com.selfpractise;
import java.util.*;

public class NumberInBinary {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("Enter the binary string:");
        String binaryString = input.next();
       int num = Integer.parseInt(binaryString, 2);
        int steps = 0;

        while (num > 1) {
            if (num % 2 == 0) {
                num /= 2;
            } else {
                num += 1;
            }
            steps++;
        }

        System.out.println(steps);

        input.close();
    }
}
