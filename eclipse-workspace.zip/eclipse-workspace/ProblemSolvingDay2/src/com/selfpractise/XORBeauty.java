package com.selfpractise;
import java.util.*;
public class XORBeauty {


		    public static void main(String[] args) {
		        Scanner input = new Scanner(System.in);

		        
		        System.out.println("Enter the array size:");
		        int size = input.nextInt();

		        int[] nums = new int[size];
		        System.out.println("Enter the array elements:");
		        for (int i = 0; i < size; i++) {
		            nums[i] = input.nextInt();
		        }

		        int xorBeauty = 0;
		        for (int num : nums) {
		            xorBeauty ^= num;
		        }

		        System.out.println("XOR-Beauty of the array is: " + xorBeauty);

		        input.close();
		    }
		
	
	}

