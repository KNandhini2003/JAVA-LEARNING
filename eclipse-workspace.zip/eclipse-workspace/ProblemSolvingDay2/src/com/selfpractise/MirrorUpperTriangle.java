package com.selfpractise;

import java.util.Scanner;

public class MirrorUpperTriangle {
	public static void main(String [] args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a range:");
		int range = input.nextInt();
		for(int i = 1 ; i <= range ; i++) {
			for(int j = range-i+1 ; j >=1 ; j--) {
				System.out.print(" ");
			}
			for(int k = 1; k<=i;k++) {
				System.out.print("* ");
			}
			System.out.println();
		}
		for(int i = 1 ; i <= range ; i++) {
			
			for(int k = 1; k<=i;k++) {
				System.out.print(" ");
			}
			for(int j = range-i+1 ; j >=1 ; j--) {
				System.out.print("* ");
			}
			System.out.println();
		}
		input.close();
	}	
}
