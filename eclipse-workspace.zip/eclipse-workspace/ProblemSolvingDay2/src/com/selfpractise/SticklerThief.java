package com.selfpractise;

import java.util.Scanner;

public class SticklerThief {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter the number of housess:");
        int n = input.nextInt();
        int arr[] = new int[n];
        System.out.println("Enter the  housess:");
        
        for(int i=0;i<n;i++) {
        	arr[i]=input.nextInt();
    	}
        int sum = 0,sum1 = 0;
        for(int i=0;i<n;i=i+2) {
        
        		sum = sum +arr[i];
        }
        for(int j = n-2; j>=0; j=j-2) {
        	sum1 = sum1 +arr[j];
        }
        System.out.print(Math.max(sum1, sum));
        input.close();
    }
}
