package com.selfpractise;
import java.util.*;
public class CaptureQueen {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

         System.out.println("Enter the position of the white rook (a b):");
        int a = input.nextInt();
        int b = input.nextInt();

        System.out.println("Enter the position of the white bishop (c d):");
        int c = input.nextInt();
        int d = input.nextInt();

        System.out.println("Enter the position of the black queen (e f):");
        int e = input.nextInt();
        int f = input.nextInt();

       boolean rookCanCapture = (a == e || b == f);

        boolean bishopCanCapture = (Math.abs(c - e) == Math.abs(d - f));

        int minMoves = Integer.MAX_VALUE;

        if (rookCanCapture) {
            minMoves = 1;
        } else {
            minMoves = 2;
        }

        if (bishopCanCapture) {
            minMoves = 1;
        } else if ((c + d) % 2 == (e + f) % 2) {
            minMoves = Math.min(minMoves, 2); // Bishop can reach the queen in two moves if on same color
        }
        System.out.println("Minimum number of moves to capture the queen: " + minMoves);

        input.close();
    }
}
