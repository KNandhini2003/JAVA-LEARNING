package com.selfpractise;

import java.util.Scanner;

public class PrimeFactor {
	public static boolean isPrime(int n) {
		int c = 0;
		for(int i = 1;i <= n; i++) {
			if(n%i==0) {
				c++;
			}
		}
		if(c==2)
			return true;
		else
			return false;
	}
	public static void main(String [] args) {
		
	Scanner input = new Scanner(System.in);
	
	System.out.println("Enter a number:");
	int n = input.nextInt();
	int max = Integer.MIN_VALUE;
	for(int i = 1;i <= n; i++) {
		if(n%i == 0) {
			if(isPrime(i)) {
				if(max < i)
					max = i;
			}
		}
	}
	System.out.print(max);
	input.close();
	}
}
