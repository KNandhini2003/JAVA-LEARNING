package com.selfpractise;
import java.util.Scanner;
public class NumberOfstepReduce {

	    public static void main(String[] args) {
	        Scanner input = new Scanner(System.in);
	        System.out.println("Enter the binary string:");
	        String s = input.next();
	        input.close();

	        System.out.println("Number of steps: " + numSteps(s));
	    }

	    public static int numSteps(String s) {
	        int steps = 0;
	       long num = Long.parseLong(s, 2);

	     while (num > 1) {
	            if (num % 2 == 0) {
	          
	                num /= 2;
	            } else {
	             
	                num += 1;
	            }
	            steps++;
	        }

	        return steps;
	    }
	}

