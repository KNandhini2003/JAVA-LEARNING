package com.selfpractise;
import java.util.*;
public class SingleNumber3 {

		public static void main(String [] args) {
		
		Scanner input = new Scanner(System.in);
		
		System.out.println("Enter a array size:");
		int size = input.nextInt();
		int array[]=new int[size];
		System.out.println("Enter a array elements:");
		int max=Integer.MIN_VALUE;
		for(int i = 0 ;i<size;i++) {
			array[i]=input.nextInt();
			
		}
		
		for(int i = 0 ;i<size;i++) {
		if(max<array[i]) {
			max=array[i];
		}
		}
		int f[]=new int[max+1];
		for(int i=0;i<size;i++) {
			f[array[i]]++;
		}
		for(int i=0;i<f.length;i++) {
			if(f[i]==1) {
				System.out.print(i+",");
			}
		}
		input.close();
		
		for(int i = 0 ; i< array.length;i++) {
			array[0] ^= array[i];
		}
		System.out.println(array[0]);
		
		}
	}
