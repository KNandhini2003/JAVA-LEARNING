package com.selfpractise;
import java.util.*;
public class OccuranceDigit {


	public static void main(String [] args) {
	
	Scanner input = new Scanner(System.in);
	
	System.out.println("Enter a number:");
	int n = input.nextInt();
//	int max=Integer.MIN_VALUE;

	int f[]=new int[10];
	while(n != 0) {
		
		f[n%10]++;
		n/=10;
	}
	int c = 0;
	for(int i=0;i<f.length;i++) {
		if(f[i]==2) {
			c = 1;
			System.out.print(i);
		}
	}
		if(c == 0)
			System.out.print(0);
		
	
	input.close();
	
	
	
	}
}
//	for(int i=0 ; i < size ; i++) {
//		
//		for(int j = i+1 ; j < size ; j++) {
//			
//			if(array[i]==array[j]) {
//
//				for(int k=j;k<size-1;k++) {
//					array[k]=array[k+1];
//				}
//				
//				size--;
//			}
//		}
//	}
//	Arrays.sort(array);
//	for(int i=0 ; i < size-1 ; i++) {
//		if(array[i]!=array[i+1]) {
//			System.out.println(array[i+1]);
//		}
//	}
//	
	


