package com.selfpractise;
import java.util.*;
public class CountWays {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter the number of stairs:");
        int n = input.nextInt();
        input.close();

        System.out.println("Number of ways to reach the " + n + "th stair: " + countWays(n));
    }

    public static int countWays(int n) {
      
        if (n == 0)
        	return 1;
        if (n == 1)
        	return 1;
        return countWays(n - 1) + countWays(n - 2);
    }
}
