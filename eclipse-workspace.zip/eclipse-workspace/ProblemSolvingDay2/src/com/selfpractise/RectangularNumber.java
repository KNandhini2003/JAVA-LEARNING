package com.selfpractise;
import java.util.Scanner;

public class RectangularNumber {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("Enter the number n:");
        int n = input.nextInt();

        int size = 2 * n - 1;
        int[][] matrix = new int[size][size];

        
        for (int i = 0; i < n; i++) {
            int num = n - i;
            for (int j = i; j < size - i; j++) {
                matrix[i][j] = num;
                matrix[j][i] = num;
                matrix[size - 1 - i][j] = num;
                matrix[j][size - 1 - i] = num;
            }
        }

   
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                System.out.print(matrix[i][j] + " ");
            }
            System.out.println();
        }

        input.close();
    }
}
