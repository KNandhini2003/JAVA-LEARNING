/**
 * 
 */
/**
 * 
 */
module ProblemSolvingDay2 {
}