
 package QueueADT;

public class ArrayCircularQueue {
    int capacity = 10;
    int front = -1;
    int rear = -1;
    int queue[] = new int[capacity];

    public boolean isEmpty() {
        return front == -1;
    }

    public boolean isFull() {
        return (rear + 1) % capacity == front;
    }

    public void enqueue(int data) {
        if (isFull()) {
            System.out.println("Queue is Full.");
        } else {
            if (isEmpty()) {
                front = 0;
            }
            rear = (rear + 1) % capacity;
            queue[rear] = data;
        }
    }

    public int dequeue() {
        if (isEmpty()) {
            System.out.println("Queue is Empty.");
            return -1;
        } else {
            int data = queue[front];
            if (front == rear) { // Queue is now empty
                front = -1;
                rear = -1;
            } else {
                front = (front + 1) % capacity;
            }
            return data;
        }
    }
    public int size() {
        if (isEmpty()) {
            return 0;
        }
        if (rear >= front) {
            return rear - front + 1;
        } else {
            return capacity - front + rear + 1;
        }
    }

    public int peek() {
        if (isEmpty()) {
            System.out.println("Queue is Empty.");
            return -1;
        }
        return queue[front];
    }
    public void display() {
        if (isEmpty()) {
            System.out.println("Queue is Empty.");
            return;
        }
    System.out.print("Queue elements: ");
    if (rear >= front) {
        for (int i = front; i <= rear; i++) {
            System.out.print(queue[i] + " ");
        }
    } else {
        for (int i = front; i < capacity; i++) {
            System.out.print(queue[i] + " ");
        }
        for (int i = 0; i <= rear; i++) {
            System.out.print(queue[i] + " ");
        }
    }
    System.out.println();
}
    public static void main(String[] args) {
        ArrayCircularQueue queue = new ArrayCircularQueue();
        queue.enqueue(1);
        queue.enqueue(2);
        queue.enqueue(3);
        queue.enqueue(4);
        queue.enqueue(5);

        queue.display(); // Queue elements: 1 2 3 4 5
        queue.dequeue();
        queue.dequeue(); // Deleted element: 1
        queue.dequeue(); // Deleted element: 2
        queue.dequeue();
        queue.display(); // Queue elements: 3 4 5
        queue.enqueue(3);
        queue.enqueue(4);
        queue.enqueue(5);
        System.out.println("Peek element: " + queue.peek()); // Peek element: 3

        System.out.println("Size of the queue: " + queue.size()); // Size of the queue: 3
    }

}


