package QueueADT;

public class ArrayQueue {
int capacity = 10;
int front = -1,rear = -1;
int queue[] = new int[capacity];
	public boolean isEmpty() {
		return front == -1 || front > rear;
	}
	public boolean isFull() {
		return rear == capacity - 1;
	}
	public void enqueue(int data) {
		if(front == -1 && rear == -1) {
			front = rear = 0;
			queue[rear] = data;
	}
		else if(isFull()) {
			System.out.println("Queue is Full.");
		}
		else {
			queue[++rear] = data;
		}
	}
	public void dequeue() {
		if(isEmpty()) {
			System.out.println("Queue is Empty.Cant delete.");
			return;
		}
		front ++;
//		rear--;
	}
	public int size() {
		if(isEmpty()) {
			return -1;
		}
//		int count = 1;
//..///		for(int i = front ; i <= rear ; i++) {
//			count ++;
//		}
		return rear - front + 1;
//		return count;
	}
	public int peek() {
		if(isEmpty()) {
			return -1;
		}
		return queue[front];
	}
	public void display() {
		if(isEmpty()) {
			System.out.println("Queue is Empty.Cant delete.");
			return;
		}
		for(int i = front ; i <= rear ; i++) {
			System.out.print(queue[i] + " ");
		}
		System.out.println();
	}

}



