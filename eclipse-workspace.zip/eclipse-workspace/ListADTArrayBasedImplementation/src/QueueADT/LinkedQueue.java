package QueueADT;
import java.util.*;
public class LinkedQueue {
    private Node front;
    private Node rear;

    private class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    public Node createNode(int data) {
        return new Node(data);
    }

    public boolean isEmpty() {
        return front == null;
    }

    public void enqueue(int data) {
        Node newNode = createNode(data);
        if (isEmpty()) {
            front = rear = newNode;
        } else {
            rear.next = newNode;
            rear = newNode;
        }
    }

    public void dequeue() {
        if (isEmpty()) {
            System.out.println("Queue is Empty. Cannot dequeue.");
            return;
        }
        System.out.println("Deleted Element: " + front.data);
        front = front.next;
        if (front == null) {
            rear = null; // Reset rear if queue becomes empty
        }
    }

    public int size() {
        Node current = front;
        int c = 0;
        while (current != null) {
            current = current.next;
            c++;
        }
        return c;
    }

    public int peek() {
        if (isEmpty()) {
            return -1;
        }
        return front.data;
    }

    public void display() {
        Node current = front;
        if (isEmpty()) {
            System.out.println("Queue is Empty.");
            return;
        }
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    public boolean search(int data) {
        Node current = front;
        while (current != null) {
            if (current.data == data) {
                return true;
            }
            current = current.next;
        }
        return false;
    }
   
    /*
    public void queueReversal() {
        if (isEmpty() || front.next == null) {
            return; // No need to reverse if empty or has only one node
        }

        Node prev = null;
        Node current = front;
        Node next = null;
        rear = front; // Update rear to the original front node

        while (current != null) {
            next = current.next;
            current.next = prev;
            prev = current;
            current = next;
        }

        front = prev; // Update front to the last node which is now the first node
    }*/
    public void queueReversal() {
        if (isEmpty() || front.next == null) {
            return; 
            }

        Stack<Node> stack = new Stack<>();
        Node current = front;

        while (current != null) {
            stack.push(current);
            current = current.next;
        }
        Node newFront = stack.pop();
        front = newFront;
       Node dummprear = newFront;
        while (!stack.isEmpty()) {
            Node nextNode = stack.pop();
            dummprear.next = nextNode;
            dummprear = nextNode;
        }
        dummprear.next = null;
        rear = dummprear;
    }
 
    
}
