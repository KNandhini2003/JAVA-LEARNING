package QueueADT;
import java.util.*;

public class LinkedQueueChar {
    private Node front;
    private Node rear;

    private class Node {
        char data;
        Node next;

        Node(char data) {
            this.data = data;
            this.next = null;
        }
    }

    public Node createNode(char data) {
        return new Node(data);
    }

    public boolean isEmpty() {
        return front == null;
    }

    public void enqueue(char data) {
        Node newNode = createNode(data);
        if (isEmpty()) {
            front = rear = newNode;
        } else {
            rear.next = newNode;
            rear = newNode;
        }
    }

    public void dequeue() {
        if (isEmpty()) {
            System.out.println("Queue is Empty. Cannot dequeue.");
            return;
        }
        front = front.next;
        if (front == null) {
            rear = null; // Reset rear if queue becomes empty
        }
    }

    public char peek() {
        if (isEmpty()) {
            throw new NoSuchElementException("Queue is empty");
        }
        return front.data;
    }

    public void display() {
        Node current = front;
        if (isEmpty()) {
            System.out.println("Queue is Empty.");
            return;
        }
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    public void removeAdjacentDuplicate(String s) {
    	Stack<Character> stack = new Stack<>();
    	
        for (int i = 0; i < s.length(); i++) {
        	
            char currentChar = s.charAt(i);
            if (stack.isEmpty() || stack.peek() != currentChar) {
                stack.push(currentChar);
                }
            else {
                stack.pop(); 
                }
        	}
        String res = "";
        	while(!stack.isEmpty()) {
        		res  =stack.pop()+res; 
        	}
        	System.out.println(res);
        }
    public String backspaceremove(String s) {
        Stack<Character> stack = new Stack<>();
        for (int i = 0; i < s.length(); i++) {
            char currentChar = s.charAt(i);
            if (currentChar != '#') {
                stack.push(currentChar);
            } else if (!stack.isEmpty()) {
                stack.pop();
            }
        }
        StringBuilder str = new StringBuilder();
        while (!stack.isEmpty()) {
            str.insert(0, stack.pop());
        }
        return str.toString();
    }

    public boolean backspaceCompare(String s, String t) {
        return backspaceremove(s).equals(backspaceremove(t));
    }

}




