package QueueADT;

public class ArrayQueueImplement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	ArrayQueue queue = new ArrayQueue();
	queue.enqueue(10);
	queue.enqueue(11);
	queue.enqueue(12);
	queue.enqueue(13);
	queue.enqueue(14);
	queue.display();
	queue.dequeue();
	queue.display();
	queue.dequeue();
	queue.display();
	}

}
