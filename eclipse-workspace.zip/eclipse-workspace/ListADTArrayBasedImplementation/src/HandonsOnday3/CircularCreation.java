package HandonsOnday3;
import java.util.Scanner;

import CircularList.CircularlyLinkedList;

public class CircularCreation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		CircularlyLinkedList list = new 
				CircularlyLinkedList();
		System.out.print("Enter list elements:");
		
		while(true) {
			int n= sc.nextInt();
			if(n == -1)
				break;
			list.addNode(n);
		}
		list.traverse();
	}

}
