package HandonsOnday3;

import java.util.Scanner;

import CircularList.CircularlyLinkedList;

public class DeleteBeginCircular8 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		CircularlyLinkedList list = new 
				CircularlyLinkedList();
		System.out.print("Enter list elements:");
		
		while(true) {
			int n= sc.nextInt();
			if(n == -1)
				break;
			list.addNode(n);
		}
		System.out.print("Enter element to delete:");
		list.deleteAtBegin();
		list.traverse();
	}

}
