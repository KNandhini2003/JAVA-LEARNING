package HandonsOnday3;
import java.util.Scanner;

import DoublyLinkedListADT
.DoublyLinkedList ;

public class CreationOfLinkedList {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter a no.of elements to create:");
		int n = sc.nextInt();
		DoublyLinkedList list = new 
				DoublyLinkedList();
		System.out.print("Enter list elements:");
		
		for(int i = 0 ; i < n ; i++) {
			list.addNode(sc.nextInt());
		}
		list.traverse();
		
	}

}
