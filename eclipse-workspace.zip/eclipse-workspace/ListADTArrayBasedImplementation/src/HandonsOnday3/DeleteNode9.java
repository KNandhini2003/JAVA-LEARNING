package HandonsOnday3;

import java.util.Scanner;

import CircularList.CircularlyLinkedList;

public class DeleteNode9 {

	public static void main(String [] args) {
			Scanner sc = new Scanner(System.in);
		
				CircularlyLinkedList list = new 
						CircularlyLinkedList();
				System.out.print("Enter list elements:");
		
				while(true) {
					int n= sc.nextInt();
					if(n == -1)
						break;
					list.addNode(n);
				}
	System.out.println("Enter a node to delete:");
    int x = sc.nextInt();
    list.deleteAtSpecificPosition(x);
    list.traverse();
	}
}

class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        next = null;
    }


    private Node head;

    public Node createNode(int data) {
        return new Node(data);
    }

    public void addNode(int data) {
        Node newNode = createNode(data);
        if (isEmpty()) {
            head = newNode;
            newNode.next = head;
        } else {
            Node currentNode = head;
            while (currentNode.next != head) {
                currentNode = currentNode.next;
            }
            currentNode.next = newNode;
            newNode.next = head;
        }
    }

    public void traverse() {
        if (isEmpty()) {
            System.out.println("List is Empty.");
        } else {
            Node current = head;
            do {
                System.out.print(current.data + " ");
                current = current.next;
            } while (current != head);
            System.out.println();
        }
    }

    public boolean isEmpty() {
        return head == null;
    }

    public void deleteAtSpecificPosition(int pos) {
        if (isEmpty()) {
            System.out.println("List is Empty.");
            return;
        }
        if (pos < 1 || pos > length()) {
            System.out.println("Invalid Position.");
            return;
        }
        if (pos == 1) {
            deleteAtBegin();
        } else {
            Node current = head;
            int currentPos = 1;
            while (currentPos < pos - 1) {
                current = current.next;
                currentPos++;
            }
            current.next = current.next.next;
        }
    }

    public void deleteAtBegin() {
        if (isEmpty()) {
            System.out.println("List is Empty.");
            return;
        }
        if (head.next == head) {
            head = null;
            return;
        }
        Node current = head;
        while (current.next != head) {
            current = current.next;
        }
        current.next = head.next;
        head = head.next;
    }

    public int length() {
        if (isEmpty()) {
            return 0;
        }
        Node current = head;
        int count = 1;
        while (current.next != head) {
            current = current.next;
            count++;
        }
        return count;
    }

}
