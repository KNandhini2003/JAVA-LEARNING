package HandonsOnday3;

import java.util.Scanner;

import DoublyLinkedListADT.DoublyLinkedList;

public class InsertAtMiddle4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		DoublyLinkedList list = new 
				DoublyLinkedList();
		System.out.print("Enter list elements:");
		
		while(true) {
			int n= sc.nextInt();
			if(n == -1)
				break;
			list.addNode(n);
		}
		System.out.println("Enter a key to insert:");
		int key = sc.nextInt();
		int mid = list.length()/2;
		if(mid % 2 == 0) {
			list.insertAtSpecificPosition
			(key, mid+1);
			list.traverse();
		}
		else {
			list.insertAtSpecificPosition
			(key, mid+1+1);
			list.traverse();
		}
	}

}
