package HandonsOnday3;

import java.util.Scanner;

import DoublyLinkedListADT.DoublyLinkedList;

public class InsertAtSpecificPosititon3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		DoublyLinkedList list = new 
				DoublyLinkedList();
		System.out.print("Enter list elements:");
		
		while(true) {
			int n= sc.nextInt();
			if(n == -1)
				break;
			list.addNode(n);
		}
		System.out.println("Enter a value to insert:");
		int val = sc.nextInt();
		System.out.println("Enter a position to insert:");
		int pos = sc.nextInt();
		//index based question
		list.insertAtSpecificPosition(val, pos+1);
		list.traverse();
		
	}

}
