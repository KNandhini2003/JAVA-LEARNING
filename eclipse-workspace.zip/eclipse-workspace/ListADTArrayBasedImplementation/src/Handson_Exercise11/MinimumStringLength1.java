package Handson_Exercise11;

import java.util.*;

public class MinimumStringLength1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);	
		System.out.println("Enter a String:");
		String str = sc.next();
		Stack<Character> stack = new
				Stack<Character>();
		for(int i = 0 ; i < str.length() ; i++) {
			char c =str.charAt(i);
			if(!stack.isEmpty() && 
					stack.peek() == 'A'&& c == 'B' ) {
				stack.pop();
			}
			else if(!stack.isEmpty() && 
					stack.peek() == 'C'&& c == 'D' ) {
				stack.pop();
			}
			else
				stack.push(c);
		}
		System.out.println(stack.size());
	}

}
