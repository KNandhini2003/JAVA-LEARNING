package Handson_Exercise11;


import java.util.Scanner;

public class CountSubArray {
    public static int countSubarrays(int[] nums, int minK, int maxK) {
        return countSubarraysWithMax(nums, maxK) - countSubarraysWithMax(nums, minK - 1);
    }
    
    private static int countSubarraysWithMax(int[] nums, int maxVal) {
        int count = 0;
        int currentCount = 0;
        
        for (int num : nums) {
            if (num <= maxVal) {
                currentCount++;
                count += currentCount;
            } else {
                currentCount = 0;
            }
        }
        
        return count;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of elements in the array (nums): ");
        int n = scanner.nextInt();
        int[] nums = new int[n];
        
        System.out.println("Enter the elements of the array (nums): ");
        for (int i = 0; i < n; i++) {
            nums[i] = scanner.nextInt();
        }

        System.out.print("Enter the minimum value (minK): ");
        int minK = scanner.nextInt();

        System.out.print("Enter the maximum value (maxK): ");
        int maxK = scanner.nextInt();
        
        scanner.close();
     
        int result = countSubarrays(nums, minK, maxK);
        System.out.println(result);
    }
}
