package Handson_Exercise11;
import java.util.Scanner;
import java.util.Stack;

public class EvaluationPostfix3 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter the postfix expression:");
            String postfix = sc.nextLine();
            // Evaluate the postfix expression and print the result
            System.out.println(evaluatePostfix(postfix));
        

        sc.close();
    }

    static int evaluatePostfix(String s) {
        Stack<Integer> stack = new Stack<>();
        String[] tokens = s.split(" ");

        for (String token : tokens) {
            if (isNumeric(token)) {
                stack.push(Integer.parseInt(token));
            } else {
                int val1 = stack.pop();
                int val2 = stack.pop();
                int result = 0;

                switch (token) {
                    case "+":
                        result = val2 + val1;
                        break;
                    case "-":
                        result = val2 - val1;
                        break;
                    case "*":
                        result = val2 * val1;
                        break;
                    case "/":
                        result = val2 / val1;
                        break;
                }

                stack.push(result);
            }
        }
        return stack.pop();
    }

    static boolean isNumeric(String str) {
        try {
            Integer.parseInt(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
