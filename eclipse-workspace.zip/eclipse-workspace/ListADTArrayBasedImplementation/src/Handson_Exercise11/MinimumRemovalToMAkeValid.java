package Handson_Exercise11;
import java.util.*;
public class MinimumRemovalToMAkeValid {

	    public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);
	        System.out.print("Enter a string:");
	        System.out.println(minRemoveToMakeValid(sc.next()));  // Output: "lee(t(c)o)de"
	    }
	    public static String minRemoveToMakeValid(String s) {
	        Stack<Integer> stack = new Stack<>();
	        Set<Integer> indexesToRemove = new HashSet<>();
	        
	        // First pass: Identify invalid parentheses
	        for (int i = 0; i < s.length(); i++) {
	            char c = s.charAt(i);
	            
	            if (c == '(') {
	                stack.push(i);
	            } else if (c == ')') {
	                if (stack.isEmpty()) {
	                    indexesToRemove.add(i);
	                } else {
	                    stack.pop();
	                }
	            }
	        }
	        
	        // Add any unmatched '(' positions to indexesToRemove
	        while (!stack.isEmpty()) {
	            indexesToRemove.add(stack.pop());
	        }
	        
	        // Second pass: Build the valid string
	        StringBuilder result = new StringBuilder();
	        for (int i = 0; i < s.length(); i++) {
	            if (!indexesToRemove.contains(i)) {
	                result.append(s.charAt(i));
	            }
	        }
	        
	        return result.toString();
	    }


	}
