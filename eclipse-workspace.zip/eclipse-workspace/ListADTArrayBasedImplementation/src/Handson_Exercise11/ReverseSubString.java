package Handson_Exercise11;
import java.util.*;
public class ReverseSubString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	 public static String reverseParentheses(String s) {
	        Stack<StringBuilder> stack = new Stack<>();
	        StringBuilder current = new StringBuilder();

	        for (char c : s.toCharArray()) {
	            if (c == '(') {
	                stack.push(current);
	                current = new StringBuilder();
	            } else if (c == ')') {
	                current.reverse();
	                if (!stack.isEmpty()) {
	                    current = stack.pop().append(current);
	                }
	            } else {
	                current.append(c);
	            }
	        }

	        return current.toString();
	    }


}
