package Handson_Exercise11;
import java.util.*;
public class ScoreOfParenthese10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	     Scanner sc = new Scanner(System.in);
	        System.out.print("Enter a string:");
	        System.out.println(scoreOfParentheses(sc.next()));
	   
	}
	 public static int scoreOfParentheses(String s) {
	        Stack<Integer> stack = new Stack<>();
	        stack.push(0); 
	        
	        for (char c : s.toCharArray()) {
	            if (c == '(') {
	                stack.push(0); 
	               } else {
	                int innerScore = stack.pop(); 
	               int outerScore = stack.pop(); 
	                
	                int newScore = outerScore + Math.max(2 * innerScore, 1);
	                stack.push(newScore);             }
	        }
	        
	        return stack.pop(); 
	    }
}
