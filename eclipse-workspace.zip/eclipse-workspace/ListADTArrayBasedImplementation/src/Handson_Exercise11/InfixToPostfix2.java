package Handson_Exercise11;
import StackADT.InfixToPostfix;
import java.util.*;

public class InfixToPostfix2 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);	
       // System.out.println("Enter an infix expression:");
     //   String infix = sc.next();
       // String postfix = InfixToPostfix.result(infix);
        System.out.println("Enter an postfix expression:");
        String postfix = sc.next();
        System.out.println("Postfix expression: " + postfix);
       
        int result = evaluation(postfix);
        System.out.println("Evaluation result: " + result);

        sc.close();
    }

    static int evaluation(String s) {
        Stack<Integer> stack = new Stack<>();

        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            
            if (Character.isDigit(c)) {
                stack.push(c - '0'); // Convert character to integer
            } else {
                int val1 = stack.pop();
                int val2 = stack.pop();

                switch (c) {
                    case '+':
                        stack.push(val2 + val1);
                        break;
                    case '-':
                        stack.push(val2 - val1);
                        break;
                    case '*':
                        stack.push(val2 * val1);
                        break;
                    case '/':
                        stack.push(val2 / val1);
                        break;
                }
            }
        }
        return stack.pop();
    }
}
