package Handson_Exercise11;

import java.util.Scanner;
import java.util.Stack;

public class ArithmeticExpression4 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter an infix expression:");
        String infix = sc.nextLine();
        
        // Check for balanced parentheses before processing
        if (!areParenthesesBalanced(infix)) {
            System.out.println("The infix expression has unbalanced parentheses.");
            return;
        }
        
        String postfix = infixToPostfix(infix);
        double result = evaluatePostfix(postfix);  // Changed to double
        System.out.println("Postfix Expression: " + postfix);
        System.out.println("Evaluation Result: " + (int)Math.ceil(result));

        sc.close();
    }

    // Function to check for balanced parentheses
    public static boolean areParenthesesBalanced(String infix) {
        Stack<Character> stack = new Stack<>();
        for (char ch : infix.toCharArray()) {
            if (ch == '(') {
                stack.push(ch);
            } else if (ch == ')') {
                if (stack.isEmpty()) {
                    return false;
                }
                stack.pop();
            }
        }
        return stack.isEmpty();
    }

    // Function to convert infix to postfix
    public static String infixToPostfix(String infix) {
        Stack<String> stack = new Stack<>();
        StringBuilder postfix = new StringBuilder();
        String[] tokens = infix.split(" ");

        for (String token : tokens) {
            if (isNumeric(token)) {
                postfix.append(token).append(" ");
            } else if (token.equals("(")) {
                stack.push(token);
            } else if (token.equals(")")) {
                while (!stack.isEmpty() && !stack.peek().equals("(")) {
                    postfix.append(stack.pop()).append(" ");
                }
                if (!stack.isEmpty()) {
                    stack.pop(); // Pop '('
                }
            } else if (isOperator(token)) {
                while (!stack.isEmpty() && precedence(token) <= precedence(stack.peek())) {
                    postfix.append(stack.pop()).append(" ");
                }
                stack.push(token);
            }
        }

        while (!stack.isEmpty()) {
            postfix.append(stack.pop()).append(" ");
        }

        return postfix.toString().trim();
    }

    // Function to check if a string is numeric
    static boolean isNumeric(String str) {
        try {
            Double.parseDouble(str);  // Changed to Double
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    // Function to check if a string is an operator
    public static boolean isOperator(String str) {
        return str.equals("+") || str.equals("-") || str.equals("*") || str.equals("/");
    }

    // Function to get the precedence of an operator
    public static int precedence(String str) {
        switch (str) {
            case "+":
            case "-":
                return 1;
            case "*":
            case "/":
                return 2;
        }
        return -1;
    }

    // Function to evaluate postfix expression
    public static double evaluatePostfix(String postfix) {  // Changed to double
        Stack<Double> stack = new Stack<>();
        String[] tokens = postfix.split(" ");

        for (String token : tokens) {
            if (isNumeric(token)) {
                stack.push(Double.parseDouble(token));  // Changed to Double
            } else {
                double val1 = stack.pop();
                double val2 = stack.pop();

                switch (token) {
                    case "+":
                        stack.push(val2 + val1);
                        break;
                    case "-":
                        stack.push(val2 - val1);
                        break;
                    case "*":
                        stack.push(val2 * val1);
                        break;
                    case "/":
                        stack.push(val2 / val1);  // Changed to double division
                        break;
                }
            }
        }
        return stack.pop();
    }
}
