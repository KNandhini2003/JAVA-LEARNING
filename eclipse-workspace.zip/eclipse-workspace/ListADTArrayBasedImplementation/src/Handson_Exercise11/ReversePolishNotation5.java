package Handson_Exercise11;

import java.util.Scanner;
import java.util.Stack;

public class ReversePolishNotation5 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a postfix expression:");
        String postfix = sc.nextLine();
        
        int result = evaluatePostfix(postfix);  // Evaluate postfix expression
        System.out.println("Postfix Expression: " + postfix);
        System.out.println("Evaluation Result: " + result);  // Convert result to int using Math.ceil

        sc.close();
    }

    // Function to evaluate postfix expression
    public static int evaluatePostfix(String postfix) {
        Stack<Integer> stack = new Stack<>();
        String[] tokens = postfix.split(" ");

        for (String token : tokens) {
            if (isNumeric(token)) {
                stack.push(Integer.parseInt(token));  // Push operands onto stack
            } else if (isOperator(token)) {
                // Ensure there are enough operands in the stack
                if (stack.size() < 2) {
                    throw new IllegalArgumentException("Invalid postfix expression: Insufficient operands for operator " + token);
                }
                int val2 = stack.pop();  // Pop operands
                int val1 = stack.pop();
                
                // Perform operation based on the operator
                switch (token) {
                    case "+":
                        stack.push(val1 + val2);
                        break;
                    case "-":
                        stack.push(val1 - val2);
                        break;
                    case "*":
                        stack.push(val1 * val2);
                        break;
                    case "/":
                        if (val2 == 0) {
                            throw new ArithmeticException("Division by zero");
                        }
                        stack.push(val1 / val2);  // Division
                        break;
                }
            }
        }
        
        if (stack.size() != 1) {
            throw new IllegalArgumentException("Invalid postfix expression: Extra operands");
        }

        return stack.pop();  // Return final result
    }

    // Function to check if a string is numeric
    static boolean isNumeric(String str) {
        try {
        	Integer.parseInt(str);  // Attempt to parse as double
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    // Function to check if a string is an operator
    public static boolean isOperator(String str) {
        return str.equals("+") || str.equals("-") || str.equals("*") || str.equals("/");
    }
}










/*package Handson_Exercise11;

import java.util.Scanner;
import java.util.Stack;

public class ReversePolishNotation5 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a postfix expression:");
        String postfix = sc.nextLine();
        
        double result = evaluatePostfix(postfix);  // Evaluate postfix expression
        System.out.println("Postfix Expression: " + postfix);
        System.out.println("Evaluation Result: " + result);  // Convert result to int using Math.ceil

        sc.close();
    }

    // Function to evaluate postfix expression
    public static double evaluatePostfix(String postfix) {
        Stack<Double> stack = new Stack<>();
        String[] tokens = postfix.split(" ");

        for (String token : tokens) {
            if (isNumeric(token)) {
                stack.push(Double.parseDouble(token));  // Push operands onto stack
            } else if (isOperator(token)) {
                // Ensure there are enough operands in the stack
                if (stack.size() < 2) {
                    throw new IllegalArgumentException("Invalid postfix expression: Insufficient operands for operator " + token);
                }
                double val2 = stack.pop();  // Pop operands
                double val1 = stack.pop();
                
                // Perform operation based on the operator
                switch (token) {
                    case "+":
                        stack.push(val1 + val2);
                        break;
                    case "-":
                        stack.push(val1 - val2);
                        break;
                    case "*":
                        stack.push(val1 * val2);
                        break;
                    case "/":
                        if (val2 == 0) {
                            throw new ArithmeticException("Division by zero");
                        }
                        stack.push(val1 / val2);  // Division
                        break;
                }
            }
        }
        
        if (stack.size() != 1) {
            throw new IllegalArgumentException("Invalid postfix expression: Extra operands");
        }

        return stack.pop();  // Return final result
    }

    // Function to check if a string is numeric
    static boolean isNumeric(String str) {
        try {
            Double.parseDouble(str);  // Attempt to parse as double
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    // Function to check if a string is an operator
    public static boolean isOperator(String str) {
        return str.equals("+") || str.equals("-") || str.equals("*") || str.equals("/");
    }
}
*/