package Handson_Exercise11;
import java.util.Scanner;
import java.util.Stack;

public class RemoveAllAdjacentDuplicateString8 {
    public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);	
		System.out.println("Enter a String:");
		String str = sc.next();
		System.out.println("Enter the kth time:");
		int k = sc.nextInt();
    	
        System.out.println(removeDuplicates(str,k ));  
        }
    	
    public static void remove(String str,int k) {
    	int f[] = new int[26];
    	for(char c : str.toCharArray()) {
    		f[c - 'a']++;
    	}
    	for(int i = 0 ; i < f.length ; i++) {
    		if(f[i] == k) {
    		//	char b = i + 'a';
    		System.out.print(false);
    		}
    	}
    }
    public static String removeDuplicates(String s, int k) {
        Stack<Pair> stack = new Stack<>();
        
        for (char c : s.toCharArray()) {
            if (!stack.isEmpty() && stack.peek().character == c) {
                stack.peek().count++;
            } else {
                stack.push(new Pair(c, 1));
            }
            
            if (stack.peek().count == k) {
                stack.pop();
            }
        }
        
        StringBuilder result = new StringBuilder();
        for (Pair p : stack) {
            for (int i = 0; i < p.count; i++) {
                result.append(p.character);
            }
        }
        
        return result.toString();
    }
    
    private static class Pair {
        char character;
        int count;
        
        Pair(char character, int count) {
            this.character = character;
            this.count = count;
        }
    }


}
