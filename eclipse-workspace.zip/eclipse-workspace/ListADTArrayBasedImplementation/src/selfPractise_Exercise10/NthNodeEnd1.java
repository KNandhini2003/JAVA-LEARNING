package selfPractise_Exercise10;
import java.util.*;
import Handson_LinkedList.SinglyLinkedList;
public class NthNodeEnd1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Scanner sc = new Scanner(System.in);
	SinglyLinkedList list = new 
			SinglyLinkedList();
	System.out.println("Enter a list elements:");
	while(true) {
		int n = sc.nextInt();
		if(n == -1) {
			break;
		}
		list.addNode(n);
	}
	System.out.println("Enter a position:");
	int pos = sc.nextInt();
	System.out.println(list.findNthNode(pos));
	
	
	}

}
