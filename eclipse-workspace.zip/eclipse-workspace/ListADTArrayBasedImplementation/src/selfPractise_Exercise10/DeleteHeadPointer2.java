package selfPractise_Exercise10;

import java.util.Scanner;

import Handson_LinkedList.SinglyLinkedList;

public class DeleteHeadPointer2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		SinglyLinkedList list = new 
				SinglyLinkedList();
		System.out.println("Enter a list elements:");
		while(true) {
			int n = sc.nextInt();
			if(n == -1) {
				break;
			}
			list.addNode(n);
		}
//		System.out.println("Enter a data to delete:");
		int del = sc.nextInt();
		list.reverse();
		list.traverse();
		
	}

}
