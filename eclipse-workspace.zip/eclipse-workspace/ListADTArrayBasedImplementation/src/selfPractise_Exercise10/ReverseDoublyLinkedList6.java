package selfPractise_Exercise10;

import java.util.Scanner;

import DoublyLinkedListADT.DoublyLinkedList;

public class ReverseDoublyLinkedList6 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		DoublyLinkedList list = new 
				DoublyLinkedList();
		System.out.println("Enter a list elements:");
		while(true) {
			int n = sc.nextInt();
			if(n == -1) {
				break;
			
		}
			list.addNode(n);
		}
	
		list.rev();
		
	}


}
