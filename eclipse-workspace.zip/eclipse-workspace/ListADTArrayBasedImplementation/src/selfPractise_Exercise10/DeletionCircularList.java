package selfPractise_Exercise10;

import java.util.Scanner;

import CircularList.CircularlyLinkedList;

public class DeletionCircularList {
	public static void main(String [] args) {
	Scanner sc = new Scanner(System.in);
	CircularlyLinkedList list = new 
			CircularlyLinkedList();
	System.out.println("Enter a list elements:");
	while(true) {
		int n = sc.nextInt();
		if(n == -1) {
			break;
		}
		list.addNode(n);
	}
	System.out.println("Enter a element:");
	int k = sc.nextInt();
	list.deleteNode(k);
	list.traverse();
	}
}
