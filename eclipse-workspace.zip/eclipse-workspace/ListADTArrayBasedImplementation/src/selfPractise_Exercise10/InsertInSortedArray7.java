package selfPractise_Exercise10;

import java.util.Scanner;

import DoublyLinkedListADT.
DoublyLinkedList;

public class InsertInSortedArray7 {
	public static void main(String [] args) {
	Scanner sc = new Scanner(System.in);
	DoublyLinkedList list = new 
			DoublyLinkedList();
	System.out.println("Enter a list elements:");
	while(true) {
		int n = sc.nextInt();
		if(n == -1) {
			break;
		}
		list.addNode(n);
	}
	System.out.println("Enter a element to insert:");
	int k = sc.nextInt();
	list.insertAtSortedArray(k);
	list.traverse();
	}
}
