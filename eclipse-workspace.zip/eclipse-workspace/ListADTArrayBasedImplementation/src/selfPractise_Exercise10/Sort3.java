package selfPractise_Exercise10;

import java.util.Scanner;

import Handson_LinkedList.SinglyLinkedList;

public class Sort3 {
	public static void main(String [] args) {
	Scanner sc = new Scanner(System.in);
	SinglyLinkedList list = new 
			SinglyLinkedList();
	System.out.println("Enter a list elements:");
	while(true) {
		int n = sc.nextInt();
		if(n == -1) {
			break;
		}
		list.addNode(n);
	}
	list.sort();
//	list.traverse();
	
}

}
