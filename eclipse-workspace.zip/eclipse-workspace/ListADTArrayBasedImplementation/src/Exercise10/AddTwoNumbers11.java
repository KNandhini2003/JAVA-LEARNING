package Exercise10;
import java.util.*;
import Handson_LinkedList.SinglyLinkedList;

public class AddTwoNumbers11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);  
		System.out.print("Enter list1 size: ");
	        int n = sc.nextInt();
	        SinglyLinkedList list1 = new
	        		SinglyLinkedList();
	        System.out.print("Enter list1 elements: ");

	        for (int i = 0; i < n; i++) {
	            list1.addNode(sc.nextInt());
	        }
	        System.out.print("Enter list2 size: ");
	        int m = sc.nextInt();
	        SinglyLinkedList list2 = new
	        		SinglyLinkedList();
	        System.out.print("Enter list2 elements: ");
	        
	        for (int i = 0; i < n; i++) {
	        	list2.addNode(sc.nextInt());
	        }
	        SinglyLinkedList list3 = new
	        		SinglyLinkedList();
	        list3.head = list1.addTwoNumbers(list1,list2);
	        list3.traverse();
	}

}
