package Exercise10;

import java.util.Scanner;

import Handson_LinkedList.SinglyLinkedList;
public class MiddleLinkedList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		SinglyLinkedList list = new 
				SinglyLinkedList();
		
		System.out.print("Enter list size:");
		int n = sc.nextInt();
		System.out.print("Enter list elements:");
		
		for(int i = 0 ; i < n ; i++) {
			list.addNode(sc.nextInt());
		}
	
		int mid = list.length()/2;
		if(mid % 2 == 0) {
			list.traverseMid(mid+1);
			
		}
		else {
			list.traverseMid(mid+1 );
		}
	
	}

}
