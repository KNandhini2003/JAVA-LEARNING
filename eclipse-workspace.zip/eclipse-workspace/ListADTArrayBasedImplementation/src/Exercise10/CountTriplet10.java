package Exercise10;

import java.util.Scanner;

import Handson_LinkedList.SinglyLinkedList;

public class CountTriplet10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
        System.out.print("Enter number of elements to create: ");
        int n = sc.nextInt();
        SinglyLinkedList list = new
        		SinglyLinkedList();
        SinglyLinkedList list1 = new
        		SinglyLinkedList();
       
        System.out.print("Enter list elements: ");
       
        for (int i = 0; i < n; i++) {
            list.addNode(sc.nextInt());
        }
        
        list1.head = list.OddEven(list);
        list1.traverse();
        System.out.println("Enter a sum to check triple:");
        System.out.print(list.tripleCount(sc.nextInt()));
        
        
	}

}
