package Exercise10;

import java.util.Scanner;

import Handson_LinkedList.SinglyLinkedList;

public class SwapNodeInPairs18 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);  
		System.out.print("Enter list1 size: ");
	        int n = sc.nextInt();
	        SinglyLinkedList list1 = new
	        		SinglyLinkedList();
	        System.out.print("Enter list1 elements: ");

	        for (int i = 0; i < n; i++) {
	            list1.addNode(sc.nextInt());
	        }
	        list1.swap(list1);
	        list1.traverse();
	}

}
