package Exercise10;

import java.util.Scanner;

import Handson_LinkedList.SinglyLinkedList;

public class ConvertBinry9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner sc = new Scanner(System.in);
	        System.out.print("Enter number of elements to create: ");
	        int n = sc.nextInt();
	        SinglyLinkedList list = new
	        		SinglyLinkedList();
	        System.out.print("Enter list elements: ");

	        for (int i = 0; i < n; i++) {
	            list.addNode(sc.nextInt());
	        }
	        list.binaryNumber();
	}

}
