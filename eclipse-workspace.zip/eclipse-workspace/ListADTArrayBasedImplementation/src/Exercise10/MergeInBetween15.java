package Exercise10;

import java.util.Scanner;

import Handson_LinkedList.SinglyLinkedList;

public class MergeInBetween15 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);  
		System.out.print("Enter list1 size: ");
	        int n = sc.nextInt();
	        SinglyLinkedList list1 = new
	        		SinglyLinkedList();
	        SinglyLinkedList list2 = new
	        		SinglyLinkedList();
	        System.out.print("Enter list1 elements: ");

	        for (int i = 0; i < n; i++) {
	            list1.addNode(sc.nextInt());
	        }
	        
	        System.out.print("Enter list2 size: ");
	        int m = sc.nextInt();
	        
	        System.out.print("Enter list2 elements: ");
	        
	        for (int i = 0; i < m; i++) {
	        	list2.addNode(sc.nextInt());
	        }
	        System.out.print("Enter start postiton: ");
	        int start = sc.nextInt();
	        System.out.print("Enter end position: ");
	        int end = sc.nextInt();
	        list1.mergeInBetween(list1, list2, start, end);
	        list1.traverse();
	}
		//10 1 13 6 9 5
			//1000000 1000001 1000002
}
