package Exercise10;

import java.util.*;
import Handson_LinkedList.SinglyLinkedList;
public class RemoveNthNode {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter number of elements to create: ");
        int n = sc.nextInt();
        SinglyLinkedList list = new
        		SinglyLinkedList();
        System.out.print("Enter list elements: ");

        for (int i = 0; i < n; i++) {
            list.addNode(sc.nextInt());
        }
        System.out.print("Enter nth node: ");
        list.removeNthNodeFromEnd(sc.nextInt()-1);
        
        list.traverse();
        
        list.traverse();
    }
}
/*
class linkedList {
    private ListNode head;

    private static class ListNode {
        int data;
        ListNode next;
        ListNode(int data) {
            this.data = data;
            this.next = null;
        }
    }

    public void addNode(int data) {
        ListNode newNode = new ListNode(data);
        if (head == null) {
            head = newNode;
        } else {
            ListNode current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    public void traverseInReverse() {
        if (head == null) {
            return;
        }

        Stack<ListNode> stack = new Stack<>();
        ListNode current = head;

        // Push nodes onto the stack
        while (current != null) {
            stack.push(current);
            current = current.next;
        }

        // Rebuild the list in reverse order
        head = stack.pop();
        current = head;

        while (!stack.isEmpty()) {
            ListNode nextNode = stack.pop();
            current.next = nextNode;
            current = current.next;
        }
        current.next = null; // End the list
    }

    public void traverse() {
        ListNode current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
}
*/