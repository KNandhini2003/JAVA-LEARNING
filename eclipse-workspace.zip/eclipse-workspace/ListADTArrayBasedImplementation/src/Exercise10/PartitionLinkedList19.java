package Exercise10;

import java.util.Scanner;

import Handson_LinkedList.SinglyLinkedList;

public class PartitionLinkedList19 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);  
		System.out.print("Enter list1 size: ");
	        int n = sc.nextInt();
	        SinglyLinkedList list = new
	        		SinglyLinkedList();
	        System.out.print("Enter list1 elements: ");

	        for (int i = 0; i < n; i++) {
	           list.addNode(sc.nextInt());
	        }
	        System.out.println("Partition value:");
	        int k = sc.nextInt();
	        list.partition(list, k);
//            list.traverse();
	}

}
