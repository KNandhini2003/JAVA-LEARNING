package Exercise10;

import java.util.Scanner;

import Handson_LinkedList.SinglyLinkedList;

public class DetectRemoveCycle17 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);  
		System.out.print("Enter list1 size: ");
	        int n = sc.nextInt();
	        SinglyLinkedList list = new
	        		SinglyLinkedList();
	        System.out.print("Enter list1 elements: ");

	        for (int i = 0; i < n; i++) {
	            list.addNode(sc.nextInt());
	        }
	        int pos = sc.nextInt();
            if (pos >= 0) {
            	list.createCycle(list, pos);
            }
            
            if (list.detectAndRemoveCycle()) {
                System.out.println("True");
            } else {
                System.out.println("False");
            }
	}

}
