package Exercise10;

import java.util.Scanner;

import DoublyLinkedListADT.DoublyLinkedList;

public class RemoveDuplicateInList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);  
		System.out.print("Enter list1 size: ");
	        int n = sc.nextInt();
	        DoublyLinkedList list = new
	        		DoublyLinkedList();
	        System.out.print("Enter list1 elements: ");

	        for (int i = 0; i < n; i++) {
	            list.addNode(sc.nextInt());
	        }
	        list.head = list.removeDuplicate();
	        list.traverse();
	}

}
