package Exercise10;

import java.util.Scanner;

import Handson_LinkedList.SinglyLinkedList;

public class ReverseSubList {

	public static void main(String[] args) {
		  Scanner sc = new Scanner(System.in);
	        System.out.print("Enter number of elements to create: ");
	        int n = sc.nextInt();
	        SinglyLinkedList list = new
	        		SinglyLinkedList();
	        System.out.print("Enter list elements: ");

	        for (int i = 0; i < n; i++) {
	            list.addNode(sc.nextInt());
	        }
	        System.out.println("Enter starting position.");
	        int X = sc.nextInt();
	        System.out.println("Enter ending position.");
	        
	        int Y = sc.nextInt();
	        list.reverseSubList(X, Y);
	        list.traverse();
	        System.out.println(list.isPalindrome());
	        System.out.println();
	}

}
