package Exercise10;

import java.util.Scanner;

import Handson_LinkedList.SinglyLinkedList;

public class MergeList {
	public static void main(String [] args) {
	Scanner sc = new Scanner(System.in);
	
	SinglyLinkedList list1 = new 
			SinglyLinkedList();
	SinglyLinkedList list2 = new 
			SinglyLinkedList();
	
	System.out.print("Enter list size:");
	int n = sc.nextInt();
	System.out.print("Enter list elements:");
	
	for(int i = 0 ; i < n ; i++) {
		list1.addNode(sc.nextInt());
	}
	System.out.print("Enter list size:");
	int m = sc.nextInt();
	System.out.print("Enter list elements:");
	
	for(int i = 0 ; i < m ; i++) {
		list2.addNode(sc.nextInt());
	}
	
	list1.merge(list2);
	list1.traverse();
	}

}
