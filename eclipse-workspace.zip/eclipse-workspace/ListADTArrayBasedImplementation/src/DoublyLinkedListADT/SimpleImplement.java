package DoublyLinkedListADT;
import java.util.*; 

public class SimpleImplement {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        DoublyLinkedList list = new DoublyLinkedList();

        System.out.println("Enter 1 for creation:");
        System.out.println("Enter 2 for InsertAtBeginning:");
        System.out.println("Enter 3 for InsertAtEnd:");
        System.out.println("Enter 4 for InsertAtMiddle:");
        System.out.println("Enter 5 for DeletionAtBeginning:");
        System.out.println("Enter 6 for DeletionAtEnd:");
        System.out.println("Enter 7 for DeletionAtMiddle:");
        System.out.println("Enter 8 for Search:");
        System.out.println("Enter 9 for Size:");
        System.out.println("Enter 10 to Display:");
        System.out.println("Enter 11 to exit:");
        System.out.println("Enter 12 to reverse:");

        while (true) {
            System.out.println("ENTER YOUR OPTION:");
            int option = sc.nextInt();
            switch (option) {
                case 1:
                    System.out.print("Enter the number of elements to create:");
                    int n = sc.nextInt();
                    System.out.println("Enter " + n + " elements:");
                    for (int i = 0; i < n; i++) {
                        list.addNode(sc.nextInt());
                    }
                    break;
                case 2:
                    System.out.print("Enter an element to insert at the beginning:");
                    list.insertAtBegin(sc.nextInt());
                    break;
                case 3:
                    System.out.print("Enter an element to insert at the end:");
                    list.insertAtEnd(sc.nextInt());
                    break;
                case 4:
                    System.out.print("Enter the position to insert:");
                    int pos = sc.nextInt();
                    System.out.print("Enter the element to insert:");
                    list.insertAtSpecificPosition(sc.nextInt(), pos);
                    break;
                case 5:
                    list.deleteAtBegin();
                    break;
                case 6:
                    list.deleteAtEnd();
                    break;
                case 7:
                    System.out.print("Enter the position to delete:");
                    list.deleteAtSpecificPosition(sc.nextInt());
                    break;
                case 8:
                    System.out.print("Enter the element to search:");
                    boolean found = list.search(sc.nextInt());
                    if (found) {
                        System.out.println("Element found in the list.");
                    } else {
                        System.out.println("Element not found in the list.");
                    }
                    break;
                case 9:
                    System.out.println("Size of the list is: " + list.length());
                    break;
                case 10:
                    list.traverse();
                    break;
                case 11:
                    System.out.println("Exiting...");
                    sc.close();
                    return;
                case 12:
                	System.out.println("Reversed Successfully");
                	list.rev();
                	break;
                case 13:
                	list.sort();
                	break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
}
