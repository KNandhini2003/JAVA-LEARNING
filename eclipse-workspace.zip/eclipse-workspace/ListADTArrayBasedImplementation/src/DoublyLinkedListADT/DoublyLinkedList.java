package DoublyLinkedListADT;

class Node {
    Node prev;
    int data;
    Node next;

    Node(int data) {
        this.prev = null;
        this.data = data;
        this.next = null;
    }
}

public class DoublyLinkedList {
    public Node head;

    public Node createNode(int data) {
        return new Node(data);
    }

    public void addNode(int data) {
        Node newNode = createNode(data);
        if (isEmpty()) {
            head = newNode;
        } else {
            Node currentNode = head;
            while (currentNode.next != null) {
                currentNode = currentNode.next;
            }
            currentNode.next = newNode;
            newNode.prev = currentNode;
        }
    }

    public void traverse() {
        if (isEmpty()) {
            System.out.println("List is Empty.");
            return;
        } else {
            Node currentNode = head;
            while (currentNode != null) {
                System.out.print(currentNode.data + " ");
                currentNode = currentNode.next;
            }
            System.out.println();
        }
    }

    public int length() {
        int count = 0;
        if (isEmpty()) {
            System.out.println("List is Empty.");
            return 0;
        } else {
            Node currentNode = head;
            while (currentNode != null) {
                count++;
                currentNode = currentNode.next;
            }
        }
        return count;
    }

    public boolean isEmpty() {
        return head == null;
    }

    public void insertAtBegin(int data) {
        Node newNode = createNode(data);
        if (isEmpty()) {
            head = newNode;
        } else {
            head.prev = newNode;
            newNode.next = head;
            head = newNode;
        }
    }

    public void insertAtSpecificPosition(int data, int pos) {
        if (pos < 1 || pos > length() + 1) {
            System.out.println("Position out of range.");
            return;
        }

        if (pos == 1) {
            insertAtBegin(data);
            return;
        }

        Node newNode = createNode(data);
        Node currentNode = head;
        int currentPos = 1;

        while (currentPos < pos - 1 && currentNode != null) {
            currentNode = currentNode.next;
            currentPos++;
        }
        newNode.next = currentNode.next;
        if (newNode.next != null) {
            newNode.next.prev = newNode;
        }
        newNode.prev = currentNode;
        currentNode.next = newNode;
    }

    public void insertAtEnd(int data) {
        Node newNode = createNode(data);
        if (isEmpty()) {
            head = newNode;
            return;
        }
        Node currentNode = head;
        while (currentNode.next != null) {
            currentNode = currentNode.next;
        }
        currentNode.next = newNode;
        newNode.prev = currentNode;
    }

    public void deleteAtBegin() {
        if (isEmpty()) {
            System.out.println("List is Empty. Can't delete");
            return;
        } else {
            head = head.next;
            if (head != null) {
                head.prev = null;
            }
        }
    }

    public void deleteAtEnd() {
        if (isEmpty()) {
            System.out.println("List is Empty. Can't delete");
            return;
        }
        if (head.next == null) {
            head = null;
            return;
        }
        Node currentNode = head;
        while (currentNode.next.next != null) {
            currentNode = currentNode.next;
        }
        currentNode.next = null;
    }

    public void deleteAtSpecificPosition(int pos) {
        if (isEmpty()) {
            System.out.println("List is Empty. Can't delete");
            return;
        }
        if (pos < 1 || pos > length()) {
            System.out.println("Enter a valid position.");
            return;
        }
        if (pos == 1) {
            deleteAtBegin();
            return;
        }

        Node currentNode = head;
        Node previous = null;
        while (--pos > 0) {
            previous = currentNode;
            currentNode = currentNode.next;
        }
        previous.next = currentNode.next;
        if (currentNode.next != null) {
            currentNode.next.prev = previous;
        }
    }

    public boolean search(int data) {
        if (isEmpty()) {
            return false;
        } else {
            Node current = head;
            while (current != null) {
                if (current.data == data) {
                    return true;
                }
                current = current.next;
            }
            return false;
        }
    }

    public void reverse() {
        Node temp = null;
        Node currentNode = head;
        while (currentNode != null) {
            temp = currentNode.prev;
            currentNode.prev = currentNode.next;
            currentNode.next = temp;
            currentNode = currentNode.prev;
        }
        if (temp != null) {
            head = temp.prev;
        }
    }

    public void rev() {
        if (isEmpty()) {
            System.out.println("List is Empty.");
            return;
        } else {
            Node currentNode = head;
            while (currentNode.next != null) {
                currentNode = currentNode.next;
            }
            while (currentNode != null) {
                System.out.print(currentNode.data + " ");
                currentNode = currentNode.prev;
            }
            System.out.println();
        }
    }

    public void sort() {
        if (isEmpty()) {
            System.out.println("List is Empty.");
            return;
        } else {
            Node currentNode = null;
            int temp = 0;
            Node index = null;
            for (currentNode = head; currentNode.next != null; currentNode = currentNode.next) {
                for (index = currentNode.next; index != null; index = index.next) {
                    if (currentNode.data > index.data) {
                        temp = currentNode.data;
                        currentNode.data = index.data;
                        index.data = temp;
                    }
                }
            }
        }
    }

    public void merge(Node list1, Node list2) {
        // Merge implementation can be added if required
    }
    public Node removeDuplicate() {
        Node current = head;

        while (current != null && current.next != null) {
            if (current.data == current.next.data) {
                Node duplicate = current.next;
                current.next = duplicate.next;
                if (duplicate.next != null) {
                    duplicate.next.prev = current;
                }
            } else {
                current = current.next;
            }
        }
        return head;
    }
    public void insertAtSortedArray(int k) {
        Node newNode = createNode(k);
        if (head == null) {
            head = newNode;
            return;
        }

        Node current = head;
        if (k < current.data) {
            newNode.next = head;
            head.prev = newNode;
            head = newNode;
            return;
        }
        while (current.next != null && current.next.data < k) {
            current = current.next;
        }
        newNode.next = current.next;
        if (current.next != null) {
            current.next.prev = newNode;
        }
        current.next = newNode;
        newNode.prev = current;
    }
}
