package StackQueueSelfPractise211_07_2024;

import java.util.Scanner;

import StackQueueHandson4.StackImplementArray1;

public class MaxDepthParantheses3 {

	public static void main(String[] args) {
	  Scanner sc = new Scanner(System.in);
	  System.out.println("Enter a String:");
	  String str = sc.next();
	  int parentheses = 0,max=0;
	  for(char c : str.toCharArray()) {
		  if(c == '(')
			  parentheses ++;
		  else if(c == ')')
			  parentheses --;
		  max = Math.max(parentheses, max);
	  }
	  System.out.println(max);
	}

}
