package StackQueueSelfPractise211_07_2024;

import java.util.LinkedList;
import java.util.Queue;

public class RecentCounter2 {
    private Queue<Integer> requests;

    public RecentCounter2() {
        requests = new LinkedList<>();
    }

    public int ping(int t) {
        requests.add(t);
        while (requests.peek() < t - 3000) {
            requests.poll();
        }
        return requests.size();
    }

    public static void main(String[] args) {
        RecentCounter2 recentCounter = new RecentCounter2();
        System.out.println(recentCounter.ping(1));
        System.out.println(recentCounter.ping(100)); 
        System.out.println(recentCounter.ping(3001)); 
        System.out.println(recentCounter.ping(3002));
    }
}
