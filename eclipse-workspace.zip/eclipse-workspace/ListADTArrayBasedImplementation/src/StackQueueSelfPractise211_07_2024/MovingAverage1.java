package StackQueueSelfPractise211_07_2024;
import java.util.*;


public class MovingAverage1 {
    private Queue<Integer> window;
    private int maxSize;
    private double sum;

    MovingAverage1(int size) {
        this.window = new LinkedList<>();
        this.maxSize = size;
        this.sum = 0.0;
    }

    public double next(int val) {
        if (window.size() == maxSize) {
            sum -= window.poll();
        }
        window.add(val);
        sum += val;
        return sum / window.size();
    }

    public static void main(String[] args) {
        MovingAverage1 movingAverage = new MovingAverage1(3);
        System.out.println(movingAverage.next(1));  
        System.out.println(movingAverage.next(10));  
        System.out.println(movingAverage.next(3)); 
        System.out.println(movingAverage.next(5));    
    }
}
