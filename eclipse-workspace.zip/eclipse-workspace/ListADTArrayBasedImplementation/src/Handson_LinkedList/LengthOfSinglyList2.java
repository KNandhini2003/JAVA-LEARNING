package Handson_LinkedList;

import java.util.Scanner;

public class LengthOfSinglyList2 {
	public static void main(String [] args) {
		Scanner sc = new Scanner(System.in);
		SinglyLinkedList list = new SinglyLinkedList();
		System.out.print("Enter list elements:");
		boolean valid = true;
		while(valid) {
			int data = sc.nextInt();
			if(data != -1) {
				list.addNode(data);
			}
			else {
				valid = false;
			}
		}
		System.out.print(list.length());
	}
}
