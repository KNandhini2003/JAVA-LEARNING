package Handson_LinkedList;

import java.util.Scanner;

public class InsertNodeSpecificPos3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		SinglyLinkedList list = new SinglyLinkedList();
		System.out.print("Enter list elements:");
		boolean valid = true;
		while(valid) {
			int data = sc.nextInt();
			if(data != -1) {
				list.addNode(data);
			}
			else {
				valid = false;
			}
		}
		System.out.print("Enter a value to insert:");
		int val = sc.nextInt();
		System.out.print("Enter a index:");
		int pos = sc.nextInt();
		list.insertAtSpecificPosition(val, pos+1);
		list.traverse();
	
	}

}