package Handson_LinkedList;

import java.util.Scanner;

public class InsertArMiddle4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter a no.of elements to create:");
		int n = sc.nextInt();
		SinglyLinkedList list = new SinglyLinkedList();
		System.out.print("Enter list elements:");
		
		for(int i = 0 ; i < n ; i++) {
			list.addNode(sc.nextInt());
		}
		System.out.print("Enter a value to insert:");
		int key = sc.nextInt();
		int mid = list.length()/2;
		// if array length is odd mid = mid + 1 
		// insertAtspecific postiton method is position
		// based so pos+1 get crt index pos = mid +1
		//so i assign value is mid + 1 + 1.
		if(list.length() % 2 == 0) {
			list.insertAtSpecificPosition(key, mid+1);
			list.traverse();
		}
		else {
			list.insertAtSpecificPosition(key, mid+1+1);
			list.traverse();
		}
	}

}
