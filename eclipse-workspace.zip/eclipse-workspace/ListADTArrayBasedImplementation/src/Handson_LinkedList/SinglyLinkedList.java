package Handson_LinkedList;
import java.util.*;
class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        next = null;
    }
}

public class SinglyLinkedList {
    public Node head;

    public Node createNode(int data) {
        return new Node(data);
    }

    public void addNode(int data) {
        Node newNode = createNode(data);
        if (isEmpty()) {
            head = newNode;
        } else {
            Node currentNode = head;
            while (currentNode.next != null) {
                currentNode = currentNode.next;
            }
            currentNode.next = newNode;
        }
    }

    public void traverse() {
        if (isEmpty()) {
            System.out.println("List is Empty.");
            return;
        } else {
            Node currentNode = head;
            while (currentNode != null) {
                System.out.print(currentNode.data + " ");
                currentNode = currentNode.next;
            }
            System.out.println();
        }
    }
    public void traverseMid(int mid) {
    	if(isEmpty()) {
    		System.out.println("List is Empty.");
            return;
    	}
    	else {
    		Node current = head;
    		int count = 1;
    		while(current!= null) {
    			
    			if(count >=mid) {
    				System.out.print(current.data + " ");
    			}
    			count ++;
    			current = current.next;
    			
    		}
    		
    	}
    }
    
    public int length() {
        int count = 0;
        if (isEmpty()) {
            System.out.println("List is Empty.");
            return 0;
        } else {
            Node currentNode = head;
            while (currentNode != null) {
                count++;
                currentNode = currentNode.next;
            }
        }
        return count;
    }

    public boolean isEmpty() {
        return head == null;
    }

    public void insertAtBegin(int data) {
        Node newNode = createNode(data);
        if (isEmpty()) {
            head = newNode;
        } else {
            newNode.next = head;
            head = newNode;
        }
    }

    public void insertAtSpecificPosition(int data, int pos) {
        if (pos < 1 || pos > length() + 1) {
            System.out.print("Position out of range.");
            return;
        }

        if (pos == 1) {
            insertAtBegin(data);
            return;
        }

        Node newNode = createNode(data);
        Node currentNode = head;
        int currentPos = 1;

        while (currentPos < pos - 1 && currentNode != null) {
            currentNode = currentNode.next;
            currentPos++;
        }

        newNode.next = currentNode.next;
        currentNode.next = newNode;
    }

    public void deleteAtBegin() {
    	
    	if(isEmpty()) {
    		System.out.println("List is Empty."
    				+ "Cant delete");
    		return;
    	}
    	else {
    		head = head.next;
    	}
    }
    public void deleteAtEnd() {
    	if(isEmpty()) {
    		System.out.println("List is Empty."
    				+ "Cant delete");
    		return;
    	}
    	if(head.next == null) {
    		head = null;
    		return;
    	}
    	Node currentNode = head;
    	while(currentNode.next.next != null) {
    		currentNode = currentNode.next;
    	}
    	currentNode.next = null;
    }
    public void deleteAtSpecificPosition(int pos) {
    	if(isEmpty()) {
    		System.out.println("List is Empty."
    				+ "Cant delete");
    		return;
    	}
    	if(pos < 1 || pos > length()) {
    		System.out.println("Enter a valid position.");
    		return;
    	}
    	Node current = head;
    	Node previous = null;
    	if(pos == 1) {
    		deleteAtBegin();
    		return;
    	}
    	 while (--pos > 0) {
            previous = current; 
            current = current.next;  
        }
         previous.next = current.next;
     

    }
    public boolean search(int data) {
    	if(isEmpty()) {
    		return false;
    	}
    	else {
    		Node current = head;
    		while(current!= null) {
    			if(current.data == data) {
    				return true;
    			}
    			current = current.next;
    		}
    		return false;
    	}
    }
   
    public void removeNthNodeFromEnd(int nthPosition) {
    	if(isEmpty()) {
    		System.out.println("List is Empty.");
    	}
    	Node current = head;
    	int count = 0;
    	//Forward traversal to find the node.
//    	while(current.next!= null) {
//    		if(current.data != data) {
//    			count++;
//    		}
//    		if(current.data == data) {
//    			break;
//    		}
//    		current = current.next;
//    	}
    	int delete = length()-nthPosition;
    	deleteAtSpecificPosition(delete);
    }
   public void FindNthNodeFromEnd(int pos) {
	   int len = length() - pos;
//	   Node 
   }
    	public void deleteAlternateNode() {
    		Node current = head;
    		int count = 1;
    		/*while(current != null) {
//    			if(count % 2 == 0) {
//    				continue;
//    			}
    			System.out.print(current.data + " ");
    			count ++;
    			current = current.next;
    			
    		}
    		*/
    		   if (head == null) {
    		            return;
    		        }
    		   while (current != null && current.next != null) {
    		            current.next = current.next.next;
    		            current = current.next;
    		        }
    		    

    	}
    	public void changeStartNode(int pos) {
    		Node current = head;
    		int data = 0;
    		int delete = length() - pos;
    		int count = length();
    		while(current!=null) {
    			if(delete-1 == count) {
    				data = current.data;
    				break;
    			}
    			count--;
    			current = current.next;
    		}
    		if(delete != 0) {
    		deleteAtSpecificPosition(delete+1);
    		//this function is index based so for position increamenting to 1.
    		insertAtBegin(data);
    		}
    		
    	}
    	public void reverse() {
            if (head == null) {
                return;
            }

            Node prev = null;
            Node current = head;
            Node next = null;

            while (current != null) {
                next = current.next;
                current.next = prev;
                prev = current;
                current = next;
            }
            head = prev;
        }
    	public void sort() {
            for (Node i = head; i != null; i = i.next) {
                Node min = i;
                for (Node j = i.next; j != null; j = j.next) {
                    if (j.data < min.data) {
                        min = j;
                    }
                }
                
                int temp = i.data;
                i.data = min.data;
                min.data = temp;
            }
        }
    	public void reverseSubList(int X, int Y) {
    	    if (head == null || X >= Y) {
    	        return;
    	    }

    	     Node dummy = new Node(0);
    	    dummy.next = head;
    	    Node sublistPrev = dummy;
    	    for (int i = 1; i < X && sublistPrev.next != null; i++) {
    	        sublistPrev = sublistPrev.next;
    	    }
    	    if (sublistPrev == null || sublistPrev.next == null) {
    	        return;
    	    }

    	    Node sublistHead = sublistPrev.next;
    	    Node current = sublistHead.next;
    	    for (int i = X; i < Y && current != null; i++) {
    	        sublistHead.next = current.next;
    	        current.next = sublistPrev.next;
    	        sublistPrev.next = current;
    	        current = sublistHead.next;
    	    }

    	    head = dummy.next;
    	}

    	 public boolean isPalindrome() {
    	        Stack<Integer> stack = new Stack<>();
    	        Node check = head;
    	        Node current = head;
    	        while(current != null) {
    	            stack.push(current.data);
    	            current = current.next;
    	        }
    	        
    	        while(check != null) {
    	        	if(check.data != stack.pop()) {
    	        		return false;
    	        	}
    	            check = check.next;
    	        }
    	        return true;
    	    }
    	 public void DivideLinkedList() {
    		 Node current = head;
    		 Node subList = null;
    		 SinglyLinkedList l1 = new 
    				 SinglyLinkedList();
    		 SinglyLinkedList l2 = new 
    				 SinglyLinkedList();
    		 int count = 1;
    		 while(current != null) {
    			 if(count % 2 == 0) {
    				 l1.addNode(current.data);
    			 }
    			 else {
    				 l2.addNode(current.data);
    			 }
    			 count ++;
    			 current = current.next;
    		 }
    		 l1.traverse();
    		 l2.traverse();
    	 }
    	 public void binaryNumber() {
    		    Node current = head;
    		    String str = "";
    		    int sum = 0;
    		    int j = 0;
    		    // Build the string representation of the binary number
    		    while (current != null) {
    		        str += current.data ; // Prepend current.data to reverse the order
    		        current = current.next;
    		    }
    		    for(int i = str.length()-1 ; i >= 0 ; i--) {
    		    	if(str.charAt(i) == '1') {
    		    		sum = sum + (int)Math.pow(2, j);
    		    	}
    		    	j++;
    		    }
    		    System.out.println(sum);
    	}
    	public int tripleCount(int sum) {
    		Node i = head;
    		Node j = null;
    		Node k = null;
    		int c = 0;
    		for(;i != null ; i = i.next) {
    			for(j = i.next ; j!=null ; j= j.next) {
    				for(k = j.next;k!=null ; k=k.next) {
    					if((i.data + j.data + k.data) == sum){
    						c++;
    					}
    				}
    			}
    		}
    		return c;
    	}
    	public Node addTwoNumbers(SinglyLinkedList l1, SinglyLinkedList l2) {
    	    Node head1 = l1.head;
    	    Node head2 = l2.head;
    	    Node resultHead = null;
    	    Node current = null;
    	    int carry = 0;

    	    while (head1 != null || head2 != null || carry != 0) {
    	        int sum = carry;
    	        
    	        if (head1 != null) {
    	            sum += head1.data;
    	            head1 = head1.next;
    	        }
    	        
    	        if (head2 != null) {
    	            sum += head2.data;
    	            head2 = head2.next;
    	        }

    	        carry = sum / 10;
    	        int digit = sum % 10;

    	        Node newNode = new Node(digit);

    	        if (resultHead == null) {
    	            resultHead = newNode;
    	        } else {
    	            current.next = newNode;
    	        }
    	        current = newNode;
    	    }

    	    return resultHead;
    	}

    	public Node OddEven(SinglyLinkedList list)
    	{
    		SinglyLinkedList o = new 
    				SinglyLinkedList();
    		SinglyLinkedList e = new 
    				SinglyLinkedList();
    		
    		Node current = list.head;
    		Node odd = null;
    		Node even = null;
    		int count = 1;
    		while(current != null) {
    			if(count % 2 != 0) {
    				e.addNode(current.data);
    			}
    			count ++;
    			current = current.next;
    		}
    		count = 1;
    		current = head;
    		while(current != null) {
    			if(count % 2 == 0) {
    				e.addNode(current.data);
    			}
    			count ++;
    			current = current.next;
    		}
    		return e.head;
 }
    	public  Node removeDuplicate(Node head) {
            Node current = head;
            if (head == null) {
                return null;
            }
            while (current != null && current.next != null) {
                if (current.data == current.next.data) {
                    current.next = current.next.next;
                } else {
                    current = current.next;
                }
            }
            return head;
        }
    	public void removeDuplicate() {
            this.head = removeDuplicate(this.head);
        }
    	public void mergeInBetween(SinglyLinkedList l1, SinglyLinkedList l2, int a, int b) {
            Node list1 = l1.head;
            Node list1Start = l1.head;
            Node list2 = l2.head;
            
            int count = 0;
            while (list1 != null && count < a - 1) {
                list1 = list1.next;
                count++;
            }
            
            Node list1End = list1;
            while (list1End != null && count < b) {
                list1End = list1End.next;
                count++;
            }

            list1.next = list2; 
            
            while (list2.next != null) {
                list2 = list2.next;
            }

            list2.next = list1End.next;
        }
    	public void swap(SinglyLinkedList list) {
    		Node current = list.head;
    		
    		while(current != null && current.next != null) {
    			int temp = current.data;
    			current.data = current.next.data;
    			current.next.data = temp;
    			
    			current = current.next.next;//next pair
    		}
    	}
    	public boolean detectAndRemoveCycle() {
            Node slow = head, fast = head;
            
            // Detect cycle
            while (fast != null && fast.next != null) {
                slow = slow.next;
                fast = fast.next.next;
                
                if (slow == fast) {
                    // Cycle detected
                    removeCycle(slow);
                    return true;
                }
            }
            return false;
        }

        private void removeCycle(Node loopNode) {
            Node ptr1 = head;
            
            while (true) {
                Node ptr2 = loopNode;
                while (ptr2.next != loopNode && ptr2.next != ptr1) {
                    ptr2 = ptr2.next;
                }
                if (ptr2.next == ptr1) {
                    break;
                }
                ptr1 = ptr1.next;
            }
            
            Node ptr2 = loopNode;
            while (ptr2.next != ptr1) {
                ptr2 = ptr2.next;
            }
            ptr2.next = null; // Remove cycle
        }
        public void createCycle(SinglyLinkedList 
        		list, int pos) {
            if (pos < 0) return;
            Node cycleNode = null;
            Node current = list.head;
            int index = 0;
            while (current.next != null) {
                if (index == pos) {
                    cycleNode = current;
                }
                current = current.next;
                index++;
            }
            current.next = cycleNode; // Create cycle
        }
        public void partition(SinglyLinkedList list, int x) {
            if (list.head == null) {
                System.out.println("List is Empty.");
                return;
            }
            SinglyLinkedList left = new SinglyLinkedList();
            SinglyLinkedList right = new SinglyLinkedList();
            Node current = list.head;

            while (current != null) {
                if (current.data < x) {
                    left.addNode(current.data);
                } else {
                    right.addNode(current.data);
                }
                current = current.next;
            }
            if(left.head != null || right.head != null) {
            left.merge(right);
            left.traverse();
            }
            
            else  {
            	right.traverse();
            }
            
        }
        public void merge(SinglyLinkedList otherList) {
            if (head == null) {
                head = otherList.head;
            } else {
                Node temp = head;
                while (temp.next != null) {
                    temp = temp.next;
                }
                temp.next = otherList.head;
            }
        }
        public int findNthNode(int pos) {
        	if(pos > length()) {
        		return -1;
        	}
        	int len = length() - pos;
//        	System.out.println(len);
        	int c = 0;
        	Node current = head;
        	while(current != null) {
        		if(c == len) {
        			return current.data;
        		}
        		c++;
        		current = current.next;
        	}
        	return -1;
        }
        public void deleteData(int data) {
        	Node cur = head;
        	int c = 1;
        	while(cur != null ) {
        		if(cur.data == data) {
        			break;
        		}
        		cur = cur.next;c++;
        	}
        
        	deleteAtSpecificPosition(c);
        }
        public int modularNode(int k) {
        	int c = 1;
        	int res = -1;
        	Node cur = head;
        	while(cur != null) {
        		if(c % k == 0) {
        			res = cur.data;
        		}
        		c++;
        		cur = cur.next;
        	}
        	return res;
        }
        public Node nextGreaterElement_I
        (SinglyLinkedList l1,SinglyLinkedList l2) {
        	SinglyLinkedList newlist = new 
        			SinglyLinkedList();
        	Node newNode  = null;
        	Node list1 = l1.head;
        	int c = -1;
        	while(list1 != null) {
        		Node list2 = l2.head;
        		 c = -1;
        		while(list2!=null) {
        			if(list1.data < list2.data) {
        				c++;
        			}
        			list2 = list2.next;
        		}
        		list1 = list1.next;
        		newlist.addNode(c);
        	}
//        	newNode = newlist.head;
        	return newlist.head;
        }
        public void swapKthpositionBothEnd(int k) {
        	int a = 1;
        	Node left = head;
        	Node leftPre = null;
        	while(a < k && left != null) {
        		leftPre = left;
        		left = left.next;
        		a++;
        	}
        	a = 1;
        	Node right = head;
        	Node rightPre = null;
        	while(a < length()-k) {
        		rightPre = right;
        		right = right.next;
        	}
        	leftPre.next = right;
        	right.next = left.next;
        	rightPre.next = left;
        	
        }
//        public void mergeTwoLinkedListAlternatively
}













