package Handson_LinkedList;

import java.util.Scanner;

public class RemoveElement8 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter number of elements to create: ");
        int n = sc.nextInt();
        System.out.print("Enter list elements: ");
        List list = new List();
        for (int i = 0; i < n; i++) {
            list.addNode(sc.nextInt());
        }

        System.out.print("Enter a value to remove: ");
        int value = sc.nextInt();

        list.removeElements(value);

        System.out.print("Updated list: ");
        list.printList();
    }
}

//class Node1 {
//    int data;
//    Node1 next;
//
//    Node(int data) {
//        this.data = data;
//        this.next = null;
//    }
//}

class List {
    Node head;

    public Node createNode(int data) {
        return new Node(data);
    }

    public void addNode(int data) {
        Node newNode = createNode(data);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    public void removeElements(int value) {
        Node dummy = new Node(0);
        dummy.next = head;
        Node current = dummy;

        while (current.next != null) {
            if (current.next.data == value) {
                current.next = current.next.next;
            } else {
                current = current.next;
            }
        }

        head = dummy.next;
    }

    public void printList() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
}
