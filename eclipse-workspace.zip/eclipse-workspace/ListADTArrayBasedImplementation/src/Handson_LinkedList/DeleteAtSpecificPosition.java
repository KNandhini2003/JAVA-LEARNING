package Handson_LinkedList;

import java.util.Scanner;

public class DeleteAtSpecificPosition {

	public static void main(String[] args) {
	
			Scanner sc = new Scanner(System.in);
			System.out.print("Enter a no.of elements to create:");
			int n = sc.nextInt();
			SinglyLinkedList list = new SinglyLinkedList();
			System.out.print("Enter list elements:");
			
			for(int i = 0 ; i < n ; i++) {
				list.addNode(sc.nextInt());
			}
			
			System.out.print("Enter a index:");
			int index= sc.nextInt();
			list.deleteAtSpecificPosition(index);
			list.traverse();
			
			
	}

}
