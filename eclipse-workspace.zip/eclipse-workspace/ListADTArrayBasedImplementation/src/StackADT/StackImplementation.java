package StackADT;

public class StackImplementation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	StackArray stack = new StackArray();
	System.out.println("Enter a element to push:");
	stack.push(100);
	stack.push(200);
	stack.push(300);
	stack.push(400);
	stack.push(500);
	stack.push(600);
	stack.push(700);
	stack.push(800);
	stack.push(900);
	stack.push(1000);
	stack.push(2200);
	stack.push(3300);
	stack.display();
	stack.pop();
	stack.display();
	stack.peek();
	}

}
