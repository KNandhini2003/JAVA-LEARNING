package StackADT;

public class StackArray {
	
	int maxSize = 10;
	int top = -1;
	int stack[] = new int[maxSize];
	
	public boolean isFull() {
		return top == maxSize -1;
	}
	public boolean isEmpty() {
		return top == -1;
	}
	public void push(int data) {
		if(isFull()) {
			System.out.println("Stack is Full.");
			return;
		}
		else {
			stack[++top] = data;
		}
	}
	public void pop() {
		if(isEmpty()) {
			System.out.println("Stack is Empty.");
			return;
		}
		else {
			top--;
		}
	}
	public void peek() {
		if(isEmpty()) {
			System.out.println("Stack is Empty.");
			return;
		}
		System.out.println(stack[top]);
	}
	public void display() {
		if(isEmpty()) {
			System.out.println("Stack is Empty.");
			return;
		}
		for(int  i = top ; i >=0 ; i--) {
			System.out.print(stack[i] + " ");
		}
		System.out.println();
	}
	
}


