package StackADT;
import java.util.*;
public class BalanceBrackets {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Scanner sc = new Scanner(System.in);
	String str = sc.next();
	Queue<Integer> qu= new  LinkedList<Integer>();
	
	Queue<Integer> priority = new PriorityQueue<>();
	qu.add(2);//if queue full it throws error
	qu.offer(3);//it return false if queue full;
	//((([{}])))
	sc.close();
	}
	/*public boolean balance(String str) {
		Stack<Character> stack = new 
				Stack<>();
		for(int i = 0 ; i < str.length() ; i++) {
			char c = str.charAt(i);
			if(c == '(' || c == '[' || c == '{') {
				stack.push(c);
			}
			
		}
	}*/
}
