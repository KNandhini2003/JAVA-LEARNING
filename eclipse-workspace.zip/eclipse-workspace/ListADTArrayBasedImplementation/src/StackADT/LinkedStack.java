package StackADT;
class Node{
	int data ;
	Node next ;
	Node(int data){
		this.data = data;
		next = null;
	}
}
public class LinkedStack {
	public Node top;
	public Node createNode(int data) {
		return new Node(data);
	}
	public boolean isEmpty() {
		return top == null;
	}
	public void push(int data) {
		Node newNode = createNode(data);
		if(isEmpty()) {
			top = newNode;
			return;
		}
		newNode.next = top;
		top = newNode;
	}
	public void pop() {
		if(isEmpty()) {
			System.out.println("Stack is Empty.");
			return;
		}
		top = top.next;
	}
	public int peek() {
		if(isEmpty()) {
			System.out.println("Stack is Empty.");
			return -1;
		}
		return top.data;
		
	}
	public void display() {
		if(isEmpty()) {
			System.out.println("Stack is Empty.");
			return;
		}
		Node current = top;
		for(; current != null ; current = current.next) {
			System.out.print(current.data + " ");
		}
		System.out.println();
	}
	public int size() {
		if(isEmpty()) {
			return -1;
		}
		Node current = top;
		int c = 1;
		for(; current != null ; current = current.next) {
			c++;
		}
		return c;
	}
	public boolean search(int data) {
		if(isEmpty()) {
			return false;
		}
		Node current = top;
		while(current != null) {
			if(current.data == data)
				return true;
		}
		return false;
	}
	public int getMin() {
		if(isEmpty()) {
			return -1;
		}
		int min = Integer.MAX_VALUE;
		Node  current =top;
		while(current != null) {
			if(min >current.data) {
				min = current.data;
			}
			current = current.next;
		}
		return min;
	}
}







