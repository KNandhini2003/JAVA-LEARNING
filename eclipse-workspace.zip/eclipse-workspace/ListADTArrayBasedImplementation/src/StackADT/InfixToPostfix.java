package StackADT;
import java.util.*;

public class InfixToPostfix {
   /* 
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a string:");
        String str = sc.next();
        System.out.println(result(str));

        sc.close();
    }
    */
    public static String result(String s) {
        Stack<Character> stack = new Stack<>();
        StringBuilder result = new StringBuilder();
        
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            
            if (Character.isLetterOrDigit(c)) {
                result.append(c);
            } else if (c == '(') {
                stack.push(c);
            } else if (c == ')') {
                while (!stack.isEmpty() && stack.peek() != '(') {
                    result.append(stack.pop());
                }
                stack.pop();
            } else {
                while (!stack.isEmpty() && checkOperatorPre(c) <= checkOperatorPre(stack.peek())) {
                    if (c == '^' && stack.peek() == '^') {
                        break;
                    } else {
                        result.append(stack.peek());
                        stack.pop();
                    }
                }
                stack.push(c);
            }
        }
        /*
         Enter a string:
			K+L-M*N+(O^P)*W/U/V*T+Q
			KL+MN*-OP^W*U/V/T*+Q+

         */
        while (!stack.isEmpty()) {
            result.append(stack.pop());
        }

        return result.toString();
    }

    static int checkOperatorPre(char c) {
        switch (c) {
            case '+':
            case '-':
                return 1;
            case '*':
            case '/':
                return 2;
            case '^':
                return 3;
        }
        return -1;
    }
}
//K+L-M*N+(O^P)*W/U/V*T+Q