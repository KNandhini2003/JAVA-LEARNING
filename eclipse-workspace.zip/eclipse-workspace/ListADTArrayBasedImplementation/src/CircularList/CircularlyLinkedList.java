package CircularList;

class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        next = null;
    }
}

public class CircularlyLinkedList {
    private Node head;

    public Node createNode(int data) {
        return new Node(data);
    }

    public void addNode(int data) {
        Node newNode = createNode(data);
        if (isEmpty()) {
            head = newNode;
            newNode.next = head;
        } else {
            Node currentNode = head;
            while (currentNode.next != head) {
                currentNode = currentNode.next;
            }
            currentNode.next = newNode;
            newNode.next = head;
        }
    }

    public void traverse() {
        if (isEmpty()) {
            System.out.println("List is Empty.");
        } else {
            Node current = head;
            do {
                System.out.print(current.data + " ");
                current = current.next;
            } while (current != head);
            System.out.println();
        }
    }

    public boolean isEmpty() {
        return head == null;
    }

    public void insertAtBegin(int data) {
        Node newNode = createNode(data);
        if (isEmpty()) {
            head = newNode;
            newNode.next = head;
        } else {
            Node current = head;
            while (current.next != head) {
                current = current.next;
            }
            newNode.next = head;
            head = newNode;
            current.next = head;
        }
    }

    public void insertAtEnd(int data) {
        addNode(data);
    }

    public int length() {
        if (isEmpty()) {
            System.out.println("List is Empty.");
            return 0;
        }
        Node current = head;
        int count = 1;
        while (current.next != head) {
            current = current.next;
            count++;
        }
        return count;
    }

    public void insertAtSpecificPosition(int data, int pos) {
        if (pos < 1 || pos > length() + 1) {
            System.out.println("Invalid Position.");
            return;
        }
        if (pos == 1) {
            insertAtBegin(data);
        } else if (pos == length() + 1) {
            insertAtEnd(data);
        } else {
            Node newNode = createNode(data);
            int currentPos = 1;
            Node current = head;
            while (currentPos < pos - 1) {
                current = current.next;
                currentPos++;
            }
            newNode.next = current.next;
            current.next = newNode;
        }
    }

    public boolean search(int data) {
        if (isEmpty()) {
            return false;
        }
        Node current = head;
        do {
            if (current.data == data) {
                return true;
            }
            current = current.next;
        } while (current != head);
        return false;
    }

    public void deleteAtBegin() {
        if (isEmpty()) {
            System.out.println("List is Empty.");
            return;
        }
        if (head.next == head) {
            head = null;
            return;
        }
        Node current = head;
        while (current.next != head) {
            current = current.next;
        }
        current.next = head.next;
        head = head.next;
    }

    public void deleteAtEnd() {
        if (isEmpty()) {
            System.out.print("List is Empty.");
            return;
        }
        if (length() == 1) {
            head = null;
            return;
        }
        Node current = head;
        while (current.next.next != head) {
            current = current.next;
        }
        current.next = head;
    }

    public void deleteAtSpecificPosition(int pos) {
        if (isEmpty()) {
            System.out.println("List is Empty.");
            return;
        }
        if (pos < 1 || pos > length()) {
            System.out.println("Invalid Position.");
            return;
        }
        if (pos == 1) {
            deleteAtBegin();
        } else {
            Node current = head;
            int currentPos = 1;
            while (currentPos < pos - 1) {
                current = current.next;
                currentPos++;
            }
            current.next = current.next.next;
        }
    }

    public void reverse() {
        if (isEmpty() || head.next == head) {
            return;
        }
        Node prev = null;
        Node current = head;
        Node next;
        Node last = head;
        do {
            next = current.next;
            current.next = prev;
            prev = current;
            current = next;
        } while (current != head);
        head.next = prev;
        head = prev;
    }

    public void sort() {
        if (isEmpty() || head.next == head) {
            return;
        }
        Node current = head;
        Node index;
        int temp;
        do {
            index = current.next;
            while (index != head) {
                if (current.data > index.data) {
                    temp = current.data;
                    current.data = index.data;
                    index.data = temp;
                }
                index = index.next;
            }
            current = current.next;
        } while (current.next != head);
    }
    public void insertSorted(int insertVal) {
        Node newNode = new Node(insertVal);
        if (head == null) {
            head = newNode;
            newNode.next = head;
        } else {
            Node prev = head;
            Node curr = head.next;
            boolean toInsert = false;

            do {
                if (prev.data <= insertVal && insertVal <= curr.data) {
                    // Node is inserted between
                	//two nodes.
                    toInsert = true;
                } else if (prev.data > curr.data) {
                    //  We're at the 
                	//boundary between the 
                	//largest and smallest values.
                    if (insertVal >= prev.data || insertVal <= curr.data) {
                        toInsert = true;
                    }
                }

                if (toInsert) {
                    prev.next = newNode;
                    newNode.next = curr;
                    return;
                }

                prev = curr;
                curr = curr.next;
            } while (prev != head);

            //  All nodes are the same value or
            //we're inserting at the end of the list.
            prev.next = newNode;
            newNode.next = head;
        }
    }
    public void deleteNode(int k){
    	if(head == null) {
    		System.out.println("List is Empty");
    	}
    	Node cur = head;
    	int c = 1;
    	while(cur.next != head) {
    		if(cur.data == k) {
    			break;
    		}
    		c++;
    		cur = cur.next;
    	}
    	deleteAtSpecificPosition(c);
    }//155
  /*  public void nextGreatestII
    (CircularlyLinkedList l) {
    	Node cur = l.head;
    	CircularlyLinkedList list = new
    			CircularlyLinkedList();
    	for(Node i = cur;i!=head;i=i.next) {
    		int c = 0;
    		for(Node j = cur; j!=head;j=j.next) {
    			if(i.data <= j.data) {
    				c++;
    			}
    		}
    		if(c == 0)
    			list.addNode(-1);
    		
    		else
    			list.addNode(c);
    	}
    	list.traverse();
    } */
    
    public void nextGreatestII(CircularlyLinkedList l) {
        if (l.isEmpty()) {
            System.out.println("List is Empty.");
            return;
        }

        Node cur = l.head;
        CircularlyLinkedList resultList = new CircularlyLinkedList();
        Node head = l.head;

        // Outer loop to iterate through each node in the circular list
        while (cur != null) {
            Node next = cur.next;
            int nextGreater = -1;

            // Inner loop to find the next greater element for the current node
            while (next != cur) {
                if (next.data > cur.data) {
                    nextGreater = next.data;
                    break;
                }
                next = next.next;
                if (next == head) break; // Make sure to break if we complete one full cycle
            }

            resultList.addNode(nextGreater);
            cur = cur.next;
            if (cur == head) break; // Make sure to break if we complete one full cycle
        }

        resultList.traverse();
    }

}











