package CircularList;

public class CircularImplement {

	public static void  main(String[] args) {
		// TODO Auto-generated method stub
		CircularlyLinkedList list = new CircularlyLinkedList();
		list.addNode(210);
		list.addNode(120);
		list.addNode(330);
		list.addNode(140);
		list.addNode(150);
		list.traverse();
		list.insertAtBegin(1020);
		list.traverse();
		list.insertAtEnd(2010);
		list.traverse();
		System.out.println(list.length());
		System.out.println(list.search(0));
		list.deleteAtBegin();
		list.traverse();
		list.deleteAtEnd();
		list.traverse();
		list.deleteAtSpecificPosition(3);
		list.traverse();
//		list.reverse();
		list.sort();
		list.traverse();
		return ;
	}

}

