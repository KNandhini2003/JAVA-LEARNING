package SelfPractise_Exercise11;
import java.util.*;
public class MinimumCostRopes2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter a "
			+ "array size:");
	int n = sc.nextInt();
	System.out.println("Enter a array"
			+ "elements:");
	int arr[] = new int[n];
	for(int i = 0 ; i < n ; i++) {
		
		arr[i] = sc.nextInt();
	}
//	System.out.println(minCostOfRopes(arr));
	minCost(arr,n);
	
	}

	 static void minCost(int arr[], int n) 
	    {
	    
	        int totalCost = 0;
	    PriorityQueue<Integer> pq = new 
	    		PriorityQueue<Integer>();
	    for(int i=0;i<n;i++){
	      pq.add(arr[i]);
	    }
	    while(pq.size() > 1){
	       int first = pq.poll();
	      int second = pq.poll();
	      int cost = first + second;
	      totalCost += cost;
	      pq.add(cost);
	    }
//	    for(int a:pq) {
//	    	System.out.print(a + " ");
//	    }
	    System.out.println( totalCost);
        
	      
	}
    

}
