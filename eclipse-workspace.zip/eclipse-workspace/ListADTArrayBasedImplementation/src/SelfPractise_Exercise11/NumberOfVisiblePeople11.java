package SelfPractise_Exercise11;

import java.util.*;

public class NumberOfVisiblePeople11 {
  public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);
	        System.out.println("Enter the number of people:");
	        int n = sc.nextInt();
	        int[] heights = new int[n];
	        System.out.println("Enter the heights of people:");
	        for (int i = 0; i < n; i++) {
	            heights[i] = sc.nextInt();
	        }
	        int[] result = canSeePersonsCount(heights);
	        System.out.println(Arrays.toString(result));
	    }

	    public static int[] canSeePersonsCount(int[] heights) {
	        int n = heights.length;
	        int[] answer = new int[n];
	        Stack<Integer> stack = new Stack<>();
	        for (int i = n - 1; i >= 0; i--) {
	            int count = 0;
	            while (!stack.isEmpty() && heights[i] > heights[stack.peek()]) {
	                stack.pop();
	                count++;
	            }
	            if (!stack.isEmpty()) {
	                count++;
	            }
	            answer[i] = count;
	           stack.push(i);
	        }
	        return answer;
	    }
	}
