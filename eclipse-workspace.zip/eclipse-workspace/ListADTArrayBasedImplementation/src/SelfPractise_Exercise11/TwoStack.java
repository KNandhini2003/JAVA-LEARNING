package SelfPractise_Exercise11;
import java.util.*;
public class TwoStack {

	    int size;
	    int top1, top2;
	    int arr[];

	    TwoStack(int n) {
	        size = n;
	        top1 = -1;
	        top2 = n;
	        arr = new int[n];
	    }

	    void push1(int x) {
	        if (top1 < top2 - 1) {
	            arr[++top1] = x;
	        }
	    }

	    void push2(int x) {
	        if (top1 < top2 - 1) {
	            arr[--top2] = x;
	        }
	    }

	   int pop1() {
	        if (top1 >= 0) {
	            return arr[top1--];
	        } else {
	            return -1;
	        }
	    }

	  int pop2() {
	        if (top2 < size) {
	            return arr[top2++];
	        } else {
	            return -1;
	        }
	    }

	    public static void main(String[] args) {
	       TwoStack ts = new TwoStack(10);

	        ts.push1(2);
	        ts.push1(3);
	        ts.push2(4);

	        System.out.println(ts.pop1()); 
	        System.out.println(ts.pop2()); 
	        System.out.println(ts.pop2()); 
	        ts.push1(1);
	        ts.push2(2);

//	        System.out.println(ts.pop1());
//	        ts.push1(3);
//	        System.out.println(ts.pop1()); 
//	        System.out.println(ts.pop1()); 
	        }
	}
