package SelfPractise_Exercise11;
import java.util.Scanner;

public class NextGreaterElement1 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        // Input for nums1 array
        System.out.println("Enter the size of the first array:");
        int n = sc.nextInt();
        int list1[] = new int[n];
        System.out.println("Enter the elements of the first array:");
        for (int i = 0; i < n; i++) {
            list1[i] = sc.nextInt();
        }

        // Input for nums2 array
        System.out.println("Enter the size of the second array:");
        int m = sc.nextInt();
        int list2[] = new int[m];
        System.out.println("Enter the elements of the second array:");
        for (int i = 0; i < m; i++) {
            list2[i] = sc.nextInt();
        }
        
        // Call the method to find next greater elements
        nextGreaterElement(list1, list2);
    }

    public static void nextGreaterElement(int[] nums1, int[] nums2) {
        int[] result = new int[nums1.length];
        
        for (int i = 0; i < nums1.length; i++) {
            int nextGreater = -1;
            boolean found = false;
            
            for (int j = 0; j < nums2.length; j++) {
                if (nums2[j] == nums1[i]) {
                    found = true;
                }
                
                if (found && nums2[j] > nums1[i]) {
                    nextGreater = nums2[j];
                    break;
                }
            }
            
            result[i] = nextGreater;
        }
        
        // Print the result array
        for (int i : result) {
            System.out.print(i + " ");
        }
    }
}
