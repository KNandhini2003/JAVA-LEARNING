package SelfPractise_Exercise11;
import java.util.*;
import CircularList.CircularlyLinkedList;
public class NextGreaterElementII7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Scanner sc = new Scanner(System.in);
	System.out.print("Enter a array size:");
	int n = sc.nextInt();
	CircularlyLinkedList list = new 
			CircularlyLinkedList();
	System.out.print("Enter a array elements:");
	for(int i = 0 ; i < n ; i++) {
		list.addNode(sc.nextInt());
	}
	list.nextGreatestII(list);
	}

}
