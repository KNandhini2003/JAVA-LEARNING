package SelfPractise_Exercise11;

public class BreakNumber9 {

}
