package SelfPractise_Exercise11;
import java.util.*;
import Handson_LinkedList.*;
public class GenerateBinaryNumber5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter a number:");
	int n = sc.nextInt();
	
	SinglyLinkedList list  = new
				SinglyLinkedList();
	
	for(int i = 1 ; i <= n ; i++) {
		list.addNode(binary(i));
	}
	list.traverse();
	}
	static int binary(int n) {
		String dup = "";
		while(n>0) {
			dup = n%2 + dup;
			n/=2;
		}
		int e = Integer.parseInt(dup);
		return e;
	}
}


