package SelfPractise_Exercise11;

import java.util.Scanner;
import java.util.Stack;

class MaxStack {
    Stack<Integer> stack;
    int currentMax;

    public MaxStack() {
        stack = new Stack<>();
        currentMax = Integer.MIN_VALUE;
    }

    public void specialPush(int value) {
        if (stack.isEmpty()) {
            stack.push(value);
            currentMax = value;
        } else {
            if (value > currentMax) {
                stack.push(currentMax);
                currentMax = value;
            }
            stack.push(value);
        }
    }

    public int specialPop() {
        if (stack.isEmpty()) {
            return -1; // Stack is empty
        }
        int poppedValue = stack.pop();
        if (poppedValue == currentMax && !stack.isEmpty()) {
            currentMax = stack.pop();
        }
        return poppedValue;
    }

    public int specialTop() {
        if (stack.isEmpty()) {
            return -1;
        }
        return stack.peek();
    }

     public int specialMax() {
        if (stack.isEmpty()) {
            return -1;    }
        return currentMax;
    }

    public static void main(String[] args) {
        MaxStack stack = new MaxStack();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Choose an operation:");
            System.out.println("1. Push");
            System.out.println("2. Pop");
            System.out.println("3. Top");
            System.out.println("4. Max");
            System.out.println("5. Exit");

            int choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    System.out.print("Enter value to push: ");
                    int value = scanner.nextInt();
                    stack.specialPush(value);
                    System.out.println("Pushed " + value);
                    break;
                case 2:
                    int poppedValue = stack.specialPop();
                    if (poppedValue == -1) {
                        System.out.println("Stack is empty");
                    } else {
                        System.out.println("Popped " + poppedValue);
                    }
                    break;
                case 3:
                    int topValue = stack.specialTop();
                    if (topValue == -1) {
                        System.out.println("Stack is empty");
                    } else {
                        System.out.println("Top element is " + topValue);
                    }
                    break;
                case 4:
                    int maxValue = stack.specialMax();
                    if (maxValue == -1) {
                        System.out.println("Stack is empty");
                    } else {
                        System.out.println("Max element is " + maxValue);
                    }
                    break;
                case 5:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }
    }
}
