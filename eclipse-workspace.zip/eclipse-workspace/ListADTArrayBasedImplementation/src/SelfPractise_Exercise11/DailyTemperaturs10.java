package SelfPractise_Exercise11;

import java.util.*;

import Handson_LinkedList.SinglyLinkedList;

public class DailyTemperaturs10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a array size:");
		int n = sc.nextInt();
		System.out.println("Enter a array elements:");
		int temp[] = new int[n];
		for(int i = 0 ; i < n ; i++) {
			temp[i] = sc.nextInt();
		}
//		ArrayList<Integer> arr = new
//				ArrayList<Integer>();
		int arr[] = new int[n];
		for(int i = 0 ; i < n-1 ; i++) {
			int c = 0;
			for (int j = i+1 ; j < n ; j++) {
				c++;
				if(temp[i] < temp[j]) {
					arr[i]=c;
					break;
				}
				
			}//73 74 75 71 69 72 76 73
		}
		for(int i : arr) {
			System.out.print(i + " ");
		}
	}

}
