package SelfPractise_Exercise11;
import java.util.*;
public class BasicCalculator12 {


	    public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);
	        System.out.println("Enter an expression to calculate:");
	        String infix = sc.nextLine();
	         if (!areParenthesesBalanced(infix)) {
	            System.out.println("The expression has unbalanced parentheses.");
	            return;
	        }
	        
	        String postfix = infixToPostfix(infix);
	        int result = evaluatePostfix(postfix);  
	      //  System.out.println("Postfix Expression: " + postfix);
	        System.out.println(" Result: " + result);

	        sc.close();
	    }

	    public static boolean areParenthesesBalanced
	    (String infix) {
	        Stack<Character> stack = new Stack<>();
	        for (char ch : infix.toCharArray()) {
	            if (ch == '(') {
	                stack.push(ch);
	            } else if (ch == ')') {
	                if (stack.isEmpty()) {
	                    return false;
	                }
	                stack.pop();
	            }
	        }
	        return stack.isEmpty();
	    }

	    public static String infixToPostfix(String infix) {
	        Stack<String> stack = new Stack<>();
	        StringBuilder postfix = new StringBuilder();
	        String[] tokens = infix.split(" ");
	        	char a = 'a';
	        
	        for (String token : tokens) {
	            if (isNumeric(token)) {
	                postfix.append(token).append(" ");
	            } else if (token.equals("(")) {
	                stack.push(token);
	            } else if (token.equals(")")) {
	                while (!stack.isEmpty() && !stack.peek().equals("(")) {
	                    postfix.append(stack.pop()).append(" ");
	                }
	                if (!stack.isEmpty()) {
	                    stack.pop(); // Pop '('
	                }
	            } else if (isOperator(token)) {
	                while (!stack.isEmpty() && precedence(token) <= precedence(stack.peek())) {
	                    postfix.append(stack.pop()).append(" ");
	                }
	                stack.push(token);
	            }
	        }

	        while (!stack.isEmpty()) {
	            postfix.append(stack.pop()).append(" ");
	        }

	        return postfix.toString().trim();
	    }

	     static boolean isNumeric(String str) {
	        try {
	           Integer.parseInt(str);  
	            return true;
	        } catch (NumberFormatException e) {
	            return false;
	        }
	    }
  public static boolean isOperator(String str) {
	        return str.equals("+") || str.equals("-") || str.equals("*") || str.equals("/");
	    }

	     public static int precedence(String str) {
	        switch (str) {
	            case "+":
	            case "-":
	                return 1;
	            case "*":
	            case "/":
	                return 2;
	        }
	        return -1;
	    }

	   public static int evaluatePostfix(String postfix) {
		   Stack<Integer> stack = new Stack<>();
	        String[] tokens = postfix.split(" ");

	        for (String token : tokens) {
	            if (isNumeric(token)) {
	                stack.push(Integer.parseInt(token)); 
	                } 
	            else {
	               int val1 = stack.pop();
	                int val2 = stack.pop();

	                switch (token) {
	                    case "+":
	                        stack.push(val2 + val1);
	                        break;
	                    case "-":
	                        stack.push(val2 - val1);
	                        break;
	                    case "*":
	                        stack.push(val2 * val1);
	                        break;
	                    case "/":
	                        stack.push(val2 / val1); 
	                        break;
	                }
	            }
	        }
	        return stack.pop();
	    }
	}
