package SelfPractise_Exercise11;
import java.util.*;

public class MaxFrequencyStack {
	public static void main(String[] args) {
	    FreqStack freqStack = new FreqStack();
	    
	    freqStack.push(5);
	    freqStack.push(7);
	    freqStack.push(5);
	    freqStack.push(7);
	    freqStack.push(4);
	    freqStack.push(5);
	    
	    System.out.println(freqStack.pop());
	    System.out.println(freqStack.pop()); 
	    System.out.println(freqStack.pop()); 
	    System.out.println(freqStack.pop());
	    }
}


	class FreqStack {
	    // Map to store frequency of each element
	    Map<Integer, Integer> freq;
	    // Map to group elements by their frequency
	    Map<Integer, Stack<Integer>> freqGroup;
	    // Variable to track the maximum frequency observed
	    int maxFreq;

	    public FreqStack() {
	        freq = new HashMap<>();
	        freqGroup = new HashMap<>();
	        maxFreq = 0;
	    }
	    
	    public void push(int val) {
	        // Update frequency of val
	        int count = freq.getOrDefault(val, 0) + 1;
	        freq.put(val, count);
	        
	        // Update maxFreq if necessary
	        maxFreq = Math.max(maxFreq, count);
	        
	        // Update or create the stack for the new frequency
	        freqGroup.computeIfAbsent(count, k -> new Stack<>()).push(val);
	    }
	    
	    public int pop() {
	        // Get the stack of elements with the maximum frequency
	        Stack<Integer> maxFreqStack = freqGroup.get(maxFreq);
	        
	        // Pop the element from the maxFreqStack
	        int val = maxFreqStack.pop();
	        
	        // Update frequency map
	        freq.put(val, freq.get(val) - 1);
	        
	        // If the stack for maxFreq becomes empty, decrement maxFreq
	        if (maxFreqStack.isEmpty()) {
	            maxFreq--;
	        }
	        
	        return val;
	    
	}


	}
