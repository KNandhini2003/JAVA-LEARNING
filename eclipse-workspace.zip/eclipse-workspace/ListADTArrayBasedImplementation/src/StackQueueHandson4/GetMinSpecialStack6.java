package StackQueueHandson4;

import java.util.Scanner;

import StackADT.LinkedStack;

public class GetMinSpecialStack6 {

	public static void main(String[] args) {
	 
	  Scanner sc = new Scanner(System.in);
		System.out.println("Enter a queue size:");
		LinkedStack stack = new 
				LinkedStack();
		int n = sc.nextInt();
		System.out.println("Enter a queue elements:");
		for(int i = 0 ; i < n ; i++) {
			stack.push(sc.nextInt());
		}   
		System.out.println(stack.getMin());
		sc.close();
	}
	

}
