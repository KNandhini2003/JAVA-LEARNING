package StackQueueHandson4;
import java.util.*;
public class StackImplementArray1 {

   int maxSize = 10;
    int top = -1;
    int stack[] = new int[maxSize];

    public boolean isFull() {
        return top == maxSize - 1;
    }

    public boolean isEmpty() {
        return top == -1;
    }

    public void push(int data) {
        if (isFull()) {
            System.out.println("Stack is Full.");
            return;
        } else {
            stack[++top] = data;
        }
    }

    public void pop() {
        if (isEmpty()) {
            System.out.println("Stack is Empty.");
            System.out.println("-1");
            return;
        } else {
            System.out.println(stack[top--]);
        }
    }

    public void peek() {
        if (isEmpty()) {
            System.out.println("Stack is Empty.");
            System.out.println("-1");
            return;
        }
        System.out.println(stack[top]);
    }

    public void display() {
        if (isEmpty()) {
            System.out.println("Stack is Empty.");
            return;
        }
        for (int i = top; i >= 0; i--) {
            System.out.print(stack[i] + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        StackImplementArray1 stack = new StackImplementArray1();
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Menu:");
            System.out.println("1. Push");
            System.out.println("2. Pop");
            System.out.println("3. Top");
            System.out.println("4. Is Empty");
            System.out.println("5. Is Full");
            System.out.println("6. Display");
            System.out.println("7. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    System.out.print("Enter number to push: ");
                    int num = scanner.nextInt();
                    stack.push(num);
                    break;
                case 2:
                    stack.pop();
                    break;
                case 3:
                    stack.peek();
                    break;
                case 4:
                    System.out.println(stack.isEmpty() ? "1" : "0");
                    break;
                case 5:
                    System.out.println(stack.isFull() ? "1" : "0");
                    break;
                case 6:
                    stack.display();
                    break;
                case 7:
                    scanner.close();
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
