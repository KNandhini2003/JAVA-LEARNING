package StackQueueHandson4;
import StackADT.LinkedStack;
import java.util.*;
public class StackUsingTwoQueue2 {

	public static void main(String[] args) {
		// TODO Auto-generated method 
		TwoQueue queue = new TwoQueue();
		queue.push(2);
		System.out.println(queue.pop());
		System.out.println(queue.pop());
		queue.push(3);
		
	}
}
class TwoQueue{	
			Queue<Integer> q1 = new LinkedList<>();
		    Queue<Integer> q2 = new LinkedList<>();

		    public void push(int data) {
		        q1.add(data);
		    }

		    public int pop() {
		        if (q1.isEmpty()) {
		            return -1;
		        }
		       
		        while (q1.size() != 1) {
		            q2.add(q1.remove());
		        }
		        int poppedValue = q1.remove();
		        Queue<Integer> temp = q1;
		        q1 = q2;
		        q2 = temp;
		        return poppedValue;
		    }
	

}
