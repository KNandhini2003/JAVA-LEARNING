package StackQueueHandson4;
import java.util.*;

public class PostfixToPrefix8 {
    public static void main(String [] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter string:");
        String str = prefix(sc.next());
        System.out.println("Prefix: " + str);
        sc.close();
    }

    static String prefix(String s) {
        Stack<String> stack = new Stack<>();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (Character.isLetterOrDigit(c)) {
                stack.push(Character.toString(c));
            } else if (c == '+' || c == '-' || c == '*' || c == '/') {
                String s1 = stack.pop();
                String s2 = stack.pop();
                String temp = c + s2 + s1;
                stack.push(temp);
            }
        }
        return stack.pop();
    }
}
