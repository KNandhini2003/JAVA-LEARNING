package StackQueueHandson4;

import java.util.Scanner;

import QueueADT.LinkedQueueChar;

public class RemoveBackSpaceCompare {
	 public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);
	        System.out.println("Enter a string1:");
	        String str = sc.next();
	        System.out.println("Enter a string1:");
	        String str2 = sc.next();

	        LinkedQueueChar queue = new LinkedQueueChar();
	        
	        
	        System.out.println(queue.backspaceCompare(str, str2));
	    }
}
