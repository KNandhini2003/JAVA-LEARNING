package StackQueueHandson4;
import QueueADT.LinkedQueue;
import java.util.*;
public class QueueReversal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter a queue size:");
	LinkedQueue queue = new 
			LinkedQueue();
	int n = sc.nextInt();
	System.out.println("Enter a queue elements:");
	for(int i = 0 ; i < n ; i++) {
		queue.enqueue(sc.nextInt());
	}
	queue.queueReversal();
	queue.dequeue();
	
	queue.display();
	}

}
