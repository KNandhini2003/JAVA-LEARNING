package StackQueueHandson4;
import java.util.*;
import QueueADT.LinkedQueueChar;

public class RemoveAdjacentDuplicate4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a string:");
        String str = sc.next();

        LinkedQueueChar queue = new LinkedQueueChar();
        queue.removeAdjacentDuplicate(str);

        sc.close();
    }
}
