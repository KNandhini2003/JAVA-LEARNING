package ArrayListADT;

import java.util.Scanner;

public class ArrayInteger {
    public static void main(String[] args) {
        Array.creation();
        Array.display();
        Array.insertAtBegin();
        Array.display();
        Array.insertAtEnd();
        Array.display();
        Array.insertAtMiddle();
        Array.display();
        Array.deleteAtBegin();
        Array.display();
        Array.deleteAtEnd();
        Array.display();
        Array.deleteAtMiddle();
        Array.display();
    }
}

class Array {
    static int size;
    static final int capacity = 10;
    static int[] arr = new int[capacity];

    static Scanner sc = new Scanner(System.in);

    public static void display() {
        if (size == 0) {
            System.out.println("List is Empty.");
        } else {
            System.out.println("List elements:");
            for (int i = 0; i < size; i++) {
                System.out.print(arr[i] + " ");
            }
            System.out.println();
        }
    }

    public static void creation() {
        System.out.print("Enter a size: ");
        int n = sc.nextInt();
        if (n > capacity) {
            System.out.println("Array can be created within the capacity: " + capacity);
            return;
        }
        System.out.println("Enter array elements:");
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }
        size = n;
    }

    public static void insertAtBegin() {
        if (isFull()) {
            System.out.println("Element can't be added. List is full.");
            return;
        }

        System.out.print("Enter an element to add at the beginning: ");
        int element = sc.nextInt();

        for (int i = size; i > 0; i--) {
            arr[i] = arr[i - 1];
        }

        arr[0] = element;
        size++;
    }

    public static boolean isFull() {
        return size >= capacity;
    }

    public static void insertAtEnd() {
        if (isFull()) {
            System.out.println("Element can't be added. List is full.");
            return;
        }
        System.out.print("Enter an element to add at the end: ");
        int element = sc.nextInt();

        arr[size] = element;
        size++;
    }

    public static void insertAtMiddle() {
        if (isFull()) {
            System.out.println("Element can't be added. List is full.");
            return;
        }
        System.out.print("Enter an element to add to the array: ");
        int element = sc.nextInt();
        System.out.print("Enter a position to insert the element: ");
        int pos = sc.nextInt();

        if (pos < 1 || pos > size + 1) {
            System.out.println("Invalid position.");
            return;
        }

        for (int i = size; i >= pos; i--) {
            arr[i] = arr[i - 1];
        }
        arr[pos - 1] = element;
        size++;
    }

    public static boolean isEmpty() {
        return size == 0;
    }

    public static void deleteAtBegin() {
        if (isEmpty()) {
            System.out.println("Element can't be deleted. List is empty.");
            return;
        }

        for (int i = 0; i < size - 1; i++) {
            arr[i] = arr[i + 1];
        }

        size--;
        System.out.println("Element deleted successfully.");
    }

    public static void deleteAtEnd() {
        if (isEmpty()) {
            System.out.println("Element can't be deleted. List is empty.");
            return;
        }

        size--;
        System.out.println("Element deleted successfully.");
    }

    public static void deleteAtMiddle() {
        if (isEmpty()) {
            System.out.println("Element can't be deleted. List is empty.");
            return;
        }

        System.out.print("Enter a position to delete the element: ");
        int pos = sc.nextInt();

        if (pos < 1 || pos > size) {
            System.out.println("Invalid position.");
            return;
        }

        for (int i = pos - 1; i < size - 1; i++) {
            arr[i] = arr[i + 1];
        }

        size--;
        System.out.println("Element deleted successfully.");
    }
}
