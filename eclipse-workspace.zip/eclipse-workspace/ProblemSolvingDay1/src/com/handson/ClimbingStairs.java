package com.handson;

import java.util.Scanner;

public class ClimbingStairs {
	public static void main(String [] args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a number:");
		int number=input.nextInt();
		int  climb = 0 ;
		//step1 = 0 ,step2 = 1;
		for(int i = 1 ; i < number ; i++) {
			climb = i + climb;
//			step1 = step2;
//			step2 = climb;
		}
		System.out.println(climb);
		input.close();
	}
}
