package com.handson;

import java.util.Scanner;

public class UniqueSumUpToZero {
	public void display(int size) {
		int range = -(size / 2);
		int array[] = new int[size];
		for(int i = 0 ; i < size ; i++) {
			array[i] = range;
			System.out.print(array[i]+" ");
			range++;
		}
		
	}
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a size of Array:");
		int size=input.nextInt();
		UniqueSumUpToZero obj = new UniqueSumUpToZero();
		obj.display(size);
		input.close();
		
	}
}
