package com.handson;

import java.util.Scanner;

public class DecodeXOR {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a size1:");
		int size1=input.nextInt();
		int arr[] = new int[size1];
		System.out.println("Enter a array elements:");
		for(int i = 0 ; i < size1 ; i++) {
			arr[i]=input.nextInt();
		}
		System.out.println("ENter a first number:");
		int first = input.nextInt();
		
        int[] arr1 = new int[arr.length + 1];
        
        arr1[0] = first;
        System.out.print(arr[0]+" ");
        for (int i = 1; i < arr.length + 1; i++) {
            arr1[i] = arr[i - 1] ^ arr1[i - 1];
            System.out.print(arr1[i]+" ");
        }
		input.close();
	}
}
