package com.handson;

import java.util.Scanner;

public class GrayCode {
    public static void main(String[] args) {
		Scanner input = new Scanner(System.in);	
		System.out.println("Enter a number:");
		int number = input.nextInt();
		int bin = number;
		while(number != 0) {
			number >>= 1;
			bin^=number;
		}
		System.out.print("Binary number:"+bin);    }
}
