package com.handson;

import java.util.Scanner;

public class SquarePattern {
	public static void main(String [] args) {
	Scanner input=new Scanner(System.in);
	
	System.out.println("Enter a range for pattern:");
	int times=input.nextInt();	
	
	for(int i = 1 ; i <= times ; i++ ) {
		for(int k = 1 ; k <= times ; k++) {
			
			System.out.print(times);
			
		}
		System.out.println();
	}
	input.close();
}
}


