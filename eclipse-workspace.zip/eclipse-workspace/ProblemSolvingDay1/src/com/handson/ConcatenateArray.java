package com.handson;

import java.util.Scanner;

public class ConcatenateArray {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a size:");
		int size=input.nextInt();
		int arr[] = new int[size];
		System.out.println("Enter a array elements:");
		for(int i = 0 ; i < size ; i++) {
			arr[i]=input.nextInt();
		}
		int array[] = new int[size+size];
		for(int i = 0 ; i < size ; i++) {
			array[i]=arr[i];
		}
		int j=0;
		for(int i = size ; i < size*2 ; i++) {
			array[i]=arr[j];
			j++;
		}
		for(int i = 0 ; i < size*2 ; i++) {
			System.out.print(array[i] + " ");
		}
		input.close();
	}
}
