package com.handson;

import java.util.Scanner;

public class NumberOfBits {
	public static void main(String [] args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a number:");
		int number=input.nextInt();	
		int bit = 0,c = 0;
		while(number != 0) {
			bit=number % 2;
			
			if(bit == 1) {
				c++;
			}
			number /= 2;
		}
		
		System.out.print(c);
		input.close();
	}
}
