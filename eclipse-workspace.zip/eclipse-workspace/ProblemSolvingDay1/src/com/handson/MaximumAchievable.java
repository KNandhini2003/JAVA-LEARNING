package com.handson;

import java.util.Scanner;

public class MaximumAchievable {
	public static void main(String [] args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a number:");
		int number=input.nextInt();	
		System.out.println("Enter a times:");
		int time=input.nextInt();
//		int x = number + time;
		for(int i = 0 ; i < time ; i++) {
//			x--;
			number++;
		}
		System.out.println("Achievable Number:"+ (number+time));
		input.close();
	}

}
