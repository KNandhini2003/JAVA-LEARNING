package com.handson;

import java.util.Scanner;

public class ArrayPermutation {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a size:");
		int size=input.nextInt();
		int arr[] = new int[size];
		System.out.println("Enter a array elements:");
		for(int i = 0 ; i < size ; i++) {
			arr[i]=input.nextInt();
		}
		System.out.println("array permutation:\n");
		for(int i = 0 ; i < size ; i++) {
			System.out.print(arr[arr[i]]+" ");
		}
		input.close();
	}
}
