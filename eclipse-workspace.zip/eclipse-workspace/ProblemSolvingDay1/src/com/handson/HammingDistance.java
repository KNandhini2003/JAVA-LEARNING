package com.handson;

import java.util.Scanner;

public class HammingDistance {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a x_number:");
		int x = input.nextInt();
		System.out.println("Enter a y_number:");
		int y = input.nextInt();
				
				String bit1="";
				while(x != 0) {
					bit1=(x%2) +bit1;
					x/=2;
				}
				String bit2="";
				while(y != 0) {
					bit2=(y%2) +bit2;
					y/=2;
				}
//				System.out.println(bit1+"bet"+bit2);
//				System.out.println("bet"*3);
				int length = Math.abs(bit1.length() - bit2.length());
				for (int i = 0; i < length; i++) {
		            if (bit1.length() < bit2.length()) {
		                bit1 = "0" + bit1; 
		            } else {
		                bit2 = "0" + bit2; 
		            }
		        }
		       // System.out.println(bit1 + "bet" + bit2);
				//System.out.println(bit1+"bet"+bit2);
				int count=0;
//				char temp;
				for( int i = 0 ; i < bit1.length() ; i++) {
					
					if( bit1.charAt(i) != bit2.charAt(i)) {
						count ++;
					}
					
				}
				System.out.print(count);
				input.close();
			}
		}

