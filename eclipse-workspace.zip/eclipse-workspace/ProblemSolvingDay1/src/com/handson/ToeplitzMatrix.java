package com.handson;

import java.util.Scanner;

public class ToeplitzMatrix {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a row:");
		int row=input.nextInt();
		System.out.println("Enter a column:");
		int column=input.nextInt();
		int arr[][] = new int[row][column];
		System.out.println("Enter a array elements:");
		
		for(int i = 0 ; i < row ;i++ ) {
			for(int j = 0 ; j < column ; j++) {
				arr[i][j]=input.nextInt();
			}
		}
		display(arr,row,column);
		input.close();
	}
	static void display(int arr[][] , int row , int column) {
		boolean matrix = true;
		for(int i = 0 ; i < row - 1 ;i++ ) {
			for(int j = 0 ; j < column - 1 ; j++) {
				
				if(arr[i][j]!=arr[i+1][j+1]) {
					matrix = false;
					break;
				}
			}
		}
		System.out.println("MAtrix:");
		for(int i = 0 ; i < row ;i++ ) {
			for(int j = 0 ; j < column ; j++) {
				System.out.print(arr[i][j]+" ");
			}
			System.out.println();
		}
		if(matrix) {
			System.out.println("It is Toeplitz matrix.");
		}
		else {
			System.out.println("It is Not Toeplitz matrix.");
		}
		
	}
}
