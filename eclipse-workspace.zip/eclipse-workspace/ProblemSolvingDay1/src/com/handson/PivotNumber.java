package com.handson;

import java.util.Scanner;

public class PivotNumber {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a size:");
		int size=input.nextInt();
		System.out.println("Enter a array elements:");
		int arr[] = new int[size];
		int sum = 0 , sum1 = 0 , c = 0 , pivot = 0;
		for(int i = 0 ; i < size ; i++) {
			arr[i] = input.nextInt();
			sum=sum+arr[i];
		}
		
		for(int i = 0 ; i < size ; i++) {
			
			sum1+=arr[i];
			pivot=(sum-sum1)+arr[i];
			if(pivot == sum) {
				System.out.print("Pivot");
				c=1;
			}
			
		}
		if(c==0) {
			System.out.print("Not Pivot");
		}
		input.close();
	}
		
}

//int sum=0,sum1=0,c=0,less=size/2;
//for(int i = 0 ; i < size ; i++) {
//	
//	sum=arr[i]+sum;
//	
//	sum1=arr[size-1-i]+sum1;
//	if(sum == sum1) {
//		System.out.print(sum+"true");
//		c=1;
//		break;
//		
//	}
////	less--;
//}
//if(c==0) {
//	System.out.print(false);
//}
//