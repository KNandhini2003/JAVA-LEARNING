package com.handson;

import java.util.Scanner;

public class TrailingZero {
	public static void main(String[]args) {
		
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a array size:");
		int size = input.nextInt();
		int arr[] = new int[size];
		System.out.println("Enter a array elements:");
		for(int i=0 ; i < size ; i++) {
			
			arr[i] = input.nextInt();
		}
		int bitwise = 0 , count = 0;
		for(int i = 0 ; i < size ; i++) {
			
			for( int j = i+1 ; j < size ; j++) {
				 
				bitwise = arr[i]|arr[j];
				if(bitwise % 2 == 0) {
				
					count=1;
					break;
				}
			}
		}
		if(count == 0) {
			System.out.print(false);
		}
		else{
			System.out.print(true);
		}
		
	input.close();
	}
}





//String dup="";
//while(size !=0) {
//	System.out.print(size%2);
//	size=size/2;
//}








