package com.handson;

import java.util.Scanner;

public class MatrixDiagonal {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a row:");
		int size=input.nextInt();
//		System.out.println("Enter a column:");
//		int column=input.nextInt();
		int mat[][] = new int[size][size];
		System.out.println("Enter a array elements:");
		
		for(int i = 0 ; i < size ;i++ ) {
			for(int j = 0 ; j < size ; j++) {
				mat[i][j]=input.nextInt();
			}
		}
		int first=0,second=0;
		System.out.println("Diagonal Sum:\n");
	      for (int i = 0; i < size; i++) {
	          for (int j = 0; j < size; j++) {
	             if (i == j)
	                first += mat[i][j];
	             if ((i + j) == (size - 1) && i!=j)
	                second += mat[i][j];
	          }
	       }
			System.out.println(first+second);
			input.close();
	      
	}
}
////		int c = 0;
//		for(int i = 0 ; i < row ;i++ ) {
//			for(int j = 0 ; j < column ; j++) {
//				if(i == j) {
//					
////					System.out.println("f:"+mat[i][j]);
//					first+=mat[i][j];
//					
//					
//				}
////				if(i!=(column- 1 - i) && c == 0)
////					System.out.println("l:"+mat[i][column - 1 - i]);
////					second=second + mat[i][column - 1 - j];
////					c++;
////			}
////			c=0;
//				   if ((i + j) == (row - 1))
//		               second += mat[i][j];
//		         }
//		
//		}
//		System.out.println(first+second);
//		input.close();
//	
//	}
//		
//}
