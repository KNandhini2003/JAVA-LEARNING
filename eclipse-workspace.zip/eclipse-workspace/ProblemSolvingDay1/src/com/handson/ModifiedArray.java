package com.handson;

import java.util.Scanner;

	public class ModifiedArray {
	    public static void main(String[] args) {
	        Scanner input = new Scanner(System.in);
	        System.out.println("Enter number of rows and columns:");
	        int rows = input.nextInt();
	        int cols = input.nextInt();
	        int[][] matrix = new int[rows][cols];
	        System.out.println("Enter matrix elements:");

	        for (int i = 0; i < rows; i++) {
	            for (int j = 0; j < cols; j++) {
	                matrix[i][j] = input.nextInt();
	            }
	        }
	        int[] maxInCols = new int[cols];
	        for (int j = 0; j < cols; j++) {
	            int max = 0;
	            for (int i = 0; i < rows; i++) {
	                max = Math.max(max, matrix[i][j]);
	            }
	            maxInCols[j] = max;
	        }
	        for (int i = 0; i < rows; i++) {
	            for (int j = 0; j < cols; j++) {
	                if (matrix[i][j] == -1) {
	                    matrix[i][j] = maxInCols[j];
	                }
	            }
	        }
	        System.out.println("Modified Matrix:");
	        for (int i = 0; i < rows; i++) {
	            for (int j = 0; j < cols; j++) {
	                System.out.print(matrix[i][j] + " ");
	            }
	            System.out.println();
	        }
	        input.close();
	    }
	}


//	public static void main(String[]args) {
//		Scanner input=new Scanner(System.in);
//		System.out.println("Enter a row:");
//		int size=input.nextInt();
//		int mat[][] = new int[size][size];
//		System.out.println("Enter a array elements:");
//		
//		for(int i = 0 ; i < size ;i++ ) {
//			for(int j = 0 ; j < size ; j++) {
//				mat[i][j]=input.nextInt();
//			}
//		}
//		int max=mat[0][0];
//		for(int i = 0 ; i < size ;i++ ) {
//			
//			for(int j = 0 ; j < size ; j++) {
//				if(max < mat[j][i]) {
//					max=mat[j][i];
//				}
//			}
//			for(int j = 0 ; j < size ;j++) {
//				if(mat[j][i]== -1) {
//					mat[i][j]=max;
//				}
//			}
//			max=mat[0][0];
//		}
//		System.out.println("MOdified Matrix:");
//		for(int i = 0 ; i < size ;i++ ) {
//			for(int j = 0 ; j < size ; j++) {
//				System.out.print(mat[i][j]+" ");
//			}System.out.println();
//		}
//		input.close();
//	}
//}
