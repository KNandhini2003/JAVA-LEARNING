package com.handson;

import java.util.Scanner;

public class StudentHomeWork {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a size1:");
		int size1=input.nextInt();
		int arr[] = new int[size1];
		System.out.println("Enter a array elements:");
		for(int i = 0 ; i < size1 ; i++) {
			arr[i]=input.nextInt();
		}
		System.out.println("Enter a size2:");
		int size2=input.nextInt();
		int arr1[] = new int[size2];
		System.out.println("Enter a array elements:");
		for(int i = 0 ; i < size2 ; i++) {
			arr1[i]=input.nextInt();
		}
		System.out.println("QueryTime:");
		int queryTime=input.nextInt();
		int c = 0;
		for(int i = 0 ; i < size2 ; i++) {
			int time=Math.abs(arr[i]-arr1[i]);
		//	System.out.print(time);
			if(time == queryTime) {
				c++;
			}
		}
		System.out.println(c);
		input.close();
	}
}
