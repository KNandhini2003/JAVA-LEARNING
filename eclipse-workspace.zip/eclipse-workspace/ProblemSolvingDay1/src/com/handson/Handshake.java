package com.handson;

import java.util.Scanner;

public class Handshake {
	public static void main(String [] args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a number:");
		int number=input.nextInt();
		int handshake = ((number - 1) * number) / 2;
		System.out.println("Possible number"
				+ " of handshake:" + handshake);
		input.close();
	}
}
