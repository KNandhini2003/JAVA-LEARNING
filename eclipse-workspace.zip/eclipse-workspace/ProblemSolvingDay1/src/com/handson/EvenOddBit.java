package com.handson;

import java.util.Scanner;

public class EvenOddBit {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a number:");
		int number=input.nextInt();
		int bit = 0,c = 0 , even = 0 , odd = 0;
		while(number != 0) {
			bit=number % 2;
			if(c % 2 == 0 && bit == 1)
				even++;
			if(c % 2 != 0 && bit == 1)
				odd++;
			number /= 2;
		}
		System.out.print("["+even+","+odd+"]");
		input.close();
	}
}
