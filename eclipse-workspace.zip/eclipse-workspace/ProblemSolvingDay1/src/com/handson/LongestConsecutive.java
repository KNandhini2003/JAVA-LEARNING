package com.handson;

import java.util.Scanner;

public class LongestConsecutive {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a number:");
		int number=input.nextInt();
		String bit="";
		while(number != 0) {
			bit=(number%2) +bit;
			number/=2;
		}
		//System.out.print(bit);
		String str[]=bit.split("0");
		int max = 0;
		for(int i = 0; i < str.length ; i++) {
			//System.out.print(str[i]+" ");
			if(max < str[i].length()) {
				max = str[i].length();
			}
			
		}
//		int decimal=4;
//		System.out.println(decimal ^ (decimal >> 1));
		System.out.println("Longest consecutive bit :"+max);
		input.close();
	}
}
