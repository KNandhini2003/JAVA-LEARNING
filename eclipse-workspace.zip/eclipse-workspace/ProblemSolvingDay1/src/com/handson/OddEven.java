package com.handson;

import java.util.Scanner;

public class OddEven {
	public static void main(String [] args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a number:");
		int number=input.nextInt();
		if(number % 2 == 0) {
			System.out.print(true);
		}
		else {
			System.out.print(false);
		}
		input.close();
	}
}
