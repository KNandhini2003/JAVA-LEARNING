package com.handson;
import java.util.*;
public class CubeSumPairs {
		public static int display(int num) {
			int sum = 0 , a = 1, b = 0;
			boolean condition = true;
			int c = 0;
			while(condition) {
				sum = (int)Math.pow(a, 3)+(int)Math.pow(b, 3);
				c++;
				if(sum == num) {
//					return false;
					return c;
				}
				else {
					a++;
					b++;
				}
				if(sum > num) {
					break;
				}
			}
			return 1;
		}
		public static void main(String [] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter a number:");
		int n = input.nextInt();
//		if(!display(n)) 
//		if(){
			System.out.print(display(n));
//		}
		
//			System.out.print("Not found");
		
		input.close();
		}

}
