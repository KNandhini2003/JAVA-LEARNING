package com.handson;

import java.util.Scanner;

public class ValleysHills {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a size:");
		int size=input.nextInt();
		int arr[] = new int[size];
		System.out.println("Enter a array elements:");
		for(int i = 0 ; i < size ; i++) {
			arr[i]=input.nextInt();
		}
		int hills = 0, valleys = 0;
        for (int i = 1; i < arr.length - 1; i++) {
            if (arr[i - 1] < arr[i] && arr[i + 1] < arr[i]) {
                hills++;
            }
            if (arr[i - 1] > arr[i] && arr[i + 1] > arr[i]) {
                valleys++;
            }
        }
		
	
		System.out.println("No of Valleys and Hills:"+(hills+valleys));
		input.close();
	}
}
