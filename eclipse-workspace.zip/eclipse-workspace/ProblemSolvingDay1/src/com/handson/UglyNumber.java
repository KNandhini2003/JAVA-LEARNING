package com.handson;

import java.util.Scanner;

public class UglyNumber {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a number:");
		int number=input.nextInt();
		while(number % 2 == 0 ) {
			number/=2;
		}
		while(number % 3 == 0 ) {
			number/=3;
		}
		while(number % 5 == 0 ) {
			number/=5;
		}
		if(number == 1) {
			System.out.println("Ugly Number");
		}
		else {
			System.out.println("Not Ugly Number");
		}
		input.close();
	}
}
