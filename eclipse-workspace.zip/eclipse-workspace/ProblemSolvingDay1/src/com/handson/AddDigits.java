package com.handson;

import java.util.Scanner;

public class AddDigits {

	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a number:");
		int number=input.nextInt();
		if(number>9) {
		display(number);
		}
		else {
			System.out.print(number);
		}
		input.close();
		
	}
	static void display(int number) {
		int rev=0,sum=0;
		while(number!=0) {
			rev=number%10;
			sum=rev+sum;
			number/=10;
			
		}
	
		if(sum > 9) {
			display(sum);
		}
	
		else {
			System.out.println(sum);
			}
		}
		
	
}
