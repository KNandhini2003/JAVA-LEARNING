package com.handson;

import java.util.Scanner;

public class AlternativeDigitSum {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a number:");
		int number=input.nextInt();
		int rev=0,numberNew=0;
		while(number!=0) {
			rev=number%10;
			numberNew=numberNew*10+rev;
			number/=10;
		}
		//System.out.println(numberNew);
		int count=0,split=0,sum=0;
		while(numberNew!=0) {
			split=numberNew % 10;
			count++;
			if(count%2!=0) {
				sum=sum+split;
			}
			else {
				sum=sum-split;
			}
			numberNew/=10;
		}
		System.out.println(sum);
		input.close();
	}
}
