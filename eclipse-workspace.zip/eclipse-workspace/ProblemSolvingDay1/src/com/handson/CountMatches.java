/*
 Example 1:
Input: n = 7
Output: 6
Explanation: Details of the tournament: - 
1st Round: Teams = 7, Matches = 3, and 4 teams advance.
2nd Round: Teams = 4, Matches = 2, and 2 teams advance.
3rd Round: Teams = 2, Matches = 1, and 1 team is 
declared the winner.
Total number of matches = 3 + 2 + 1 = 6.*/
package com.handson;

import java.util.Scanner;

public class CountMatches {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a number:");
		int number=input.nextInt();
		if(number> 0) {
		System.out.println("Total number of matches:"+(number-1));
		}
		else {
			System.out.print("Total number of matches:"+number);
		}
		input.close();
		
	}
}
//	static void display(int number) {
//		int sum=number,total=0;
//		while(sum>1) {
//			if(sum % 2 == 0) {
//				
//				sum=sum/2;
//				total=sum+total;
//				
//			}
//			else {
//				sum=((sum-1)/2)+1;
//				total=sum/2+total;
//				
//			}
//			
//		}
//		System.out.println(total);
//	}
//		
//		
//	
//}
//
//

