package com.handson;
import java.util.*;
public class EncryptNumber {

    public static int encryptNumber(int num) {
        int result = 0;
        int operation = 1; // 1 for multiplication, 2 for division, 3 for addition, 4 for subtraction

        for (int i = num - 1 ; i >= 1; i--) {
            switch (operation) {
                case 1:
                    result = num * i;
                    break;
                case 2:
                    result /= i;
                    break;
                case 3:
                    result += i;
                    break;
                case 4:
                    result -= i;
                    break;
            }
            operation = (operation %4)+1;
        }
        return result;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter a number:");
        int n = input.nextInt();
        int result = encryptNumber(n);
        System.out.println("Encrypted form of " + n + " is: " + result);
        input.close();
    }
}
