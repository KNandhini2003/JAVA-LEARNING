package com.selfpractise;

import java.util.Scanner;

public class WaterBottles {

	    public static int numWaterBottles(int numBottles, int numExchange) {
	       int ans = 0;
	    	for(int i = numExchange ; i>=1;i--) {
	    	  	 ans= numBottles + (numBottles) / (numExchange);
		          
	       }

	        return ans;
	    }
	  public static void main(String[] args) {
		    
	    		Scanner input = new Scanner(System.in);	
	    		System.out.println("Enter a numBottles:");
	     int numBottles = input.nextInt();
	     System.out.println("Enter a numExchange:");
	     int  numExchange = input.nextInt();
	     int ans=numWaterBottles(numBottles,numExchange); 
	        System.out.println(ans+1);
	        input.close();
	  }
	}

