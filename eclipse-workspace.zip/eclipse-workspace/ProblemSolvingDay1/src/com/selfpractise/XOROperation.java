package com.selfpractise;

import java.util.Scanner;

public class XOROperation {
	public static void main(String [] args) {
	Scanner input = new Scanner(System.in);
	System.out.println("Enter a range:");
	int range = input.nextInt();
	int arr[] = new int[range];
	System.out.println("Enter a array elements:");
	for(int i = 0 ;i < range ; i++) {
		arr[i] = input.nextInt();
	}
	int sum = 0;
	for(int i = 0 ;i < range ; i++) {
		sum ^= sum ^ arr[i] ;
	}
	System.out.println(sum);
	input.close();
	}
}
