package com.selfpractise;
import java.util.*;
public class ValidMountainArray {


	    public static boolean display(int[] arr) {
	        if (arr == null || arr.length < 3) {
	            return false; 
	        }
	        int i = 0;
	        while (i < arr.length - 1 && arr[i] < arr[i + 1]) {
	            i++;
	        }
	        if (i == 0 || i == arr.length - 1) {
	            return false;
	        }
	        while (i < arr.length - 1 && arr[i] > arr[i + 1]) {
	            i++;
	        }
	        return i == arr.length - 1;
	    }

	    public static void main(String[] args) {
	    		Scanner input = new Scanner(System.in);	
	    		System.out.println("Enter a size:");
	    		int size = input.nextInt();

	    		int arr[] = new int[size];
	    			System.out.println("Enter a array elements:");
	    				for(int j = 0 ;j < size ; j++) {
	    					arr[j] = input.nextInt();
	    				}
	    				System.out.print(display(arr));
	    	   
	    				input.close();	  
	    				
	    }
	}
