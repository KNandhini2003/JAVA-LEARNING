package com.selfpractise;

import java.util.Scanner;

public class OddOccuranceElement {

	public static int display(int arr[]) {
		int max =arr[0];
		for(int i = 0;i < arr.length ;i++) {
			if(arr[i] > max)
				max = arr[i];
		}
		
		int f[] = new int[max + 1];
		for(int i = 0;i < arr.length ;i++) {
			f[arr[i]]++;
		}
		for(int i = 0;i < f.length ;i++) {
				if(f[i] % 2 != 0)
					return i;
			}
		return -1;
	}
	
	
	public static void main(String [] args) {
	Scanner input = new Scanner(System.in);	
	System.out.println("Enter a size:");
	int size = input.nextInt();
	
	for(int i = 0 ;i < size ; i++) {
		System.out.println("Enter a nested size:");
		int subsize = input.nextInt();
		int arr[] = new int[subsize];
		System.out.println("Enter a array elements:");
			for(int j = 0 ;j < subsize ; j++) {
				arr[j] = input.nextInt();
			}
			System.out.print(display(arr));
   
    }
	input.close();
	}
}
