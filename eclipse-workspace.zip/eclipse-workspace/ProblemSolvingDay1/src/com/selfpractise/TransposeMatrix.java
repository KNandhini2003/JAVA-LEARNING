package com.selfpractise;

import java.util.Scanner;

public class TransposeMatrix {
	public static void main(String [] args) {
	Scanner input = new Scanner(System.in);	
	System.out.println("Enter a size:");
	int size = input.nextInt();
	int arr[][] = new int[size][size];
	System.out.println("Enter a array elements:");
	for(int i = 0 ;i < size ; i++) {
		for(int j = 0 ;j < size ; j++) {
			arr[i][j] = input.nextInt();
		}
	}		
	for(int i = 0 ;i < size ; i++) {
		for(int j = 0 ;j < size ; j++) {
			System.out.print(arr[j][i]);
		}
		System.out.println();
	}		
   
    
	input.close();
	}
}

