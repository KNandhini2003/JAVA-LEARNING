package com.selfpractise;

import java.util.Scanner;

public class CalculateDelayArrival {
	public static void main(String [] args) {
	Scanner input = new Scanner(System.in);	
	System.out.println("Enter a arrivalTime:");
	int arrivalTime = input.nextInt();
	
	System.out.println("Enter a delayedTime:");
	int delayedTime = input.nextInt();
	System.out.println((arrivalTime+delayedTime)%24);
	input.close();
	}
}
