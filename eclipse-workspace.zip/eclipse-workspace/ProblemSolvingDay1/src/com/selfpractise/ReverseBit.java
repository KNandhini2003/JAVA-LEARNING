package com.selfpractise;

import java.util.Scanner;
public class ReverseBit {
	public static void main(String [] args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a number:");
		int number =input.nextInt();
		String bit = "";
		int i=31 ;
		long unsigned = 0;
		while(number!=0) {
		bit=bit+(number%2);
		if(number % 2 == 1) {
			unsigned +=(long)Math.pow(2, i);
		}
		i--;
		number/=2;
	}
//	System.out.println(bit);
	System.out.println(unsigned);
	
	input.close();
}
}
