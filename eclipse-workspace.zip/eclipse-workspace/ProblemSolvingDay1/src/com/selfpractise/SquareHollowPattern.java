package com.selfpractise;

import java.util.Scanner;

public class SquareHollowPattern {
	public static void main(String [] args) {
	Scanner input = new Scanner(System.in);
	System.out.println("Enter a range:");
	int range = input.nextInt();
	for(int i = 1 ;i <= range ; i++) {
		for(int j = 1 ;j <= range ; j++) {
			if(i == 1|| i == range || j == 1 || j == range)
				System.out.print("*");
			else
				System.out.print(" ");
		}
		System.out.println();
	}
	input.close();
	}
}
