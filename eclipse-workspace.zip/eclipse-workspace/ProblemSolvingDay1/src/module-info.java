/**
 * 
 */
/**
 * 
 */
module ProblemSolvingDay1 {
}