package com.handson;

import java.util.Scanner;

public class Anagram {
	
	public static void main(String [] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter a String element1:");
		String str1 = input.next();
		System.out.println("Enter a String element2:");
		String str2 = input.next();
		int arr1[]=new int[26];
		for(int i = 0 ; i < str1.length() ; i++) {
			arr1[str1.charAt(i)-97]++;
		}
		int arr2[]=new int[26];
		for(int i = 0 ; i < str2.length() ; i++) {
			arr2[str1.charAt(i)-97]++;
		}
		int diff = 0;
		for(int i = 0 ; i < arr1.length ; i++) {
			
			diff += Math.abs(arr1[i] - arr2[i]);
			
		}
		System.out.println(diff);
		input.close();
	}
}
