package com.handson;

import java.util.Scanner;

public class ClosestPalindrome {
	public static void main(String [] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter a String element1:");
		String str1 = input.next();
		int number = Integer.valueOf(str1);
		int small = Smaller(number);
		int larger = Larger(number);
		        int diff1 = Math.abs(number - small);
		        int diff2 = Math.abs(number - larger);
		        
		 
		        if (diff1 <= diff2 || larger == 0) {
		            System.out.println(small);
		        } else {
		            System.out.println(larger);
		        }
		        input.close();
		    }
		    public static int Smaller(int n) {
		        while (!isPalindrome(n)) {
		            n--;
		        }
		        return n;
		    }
		    public static int Larger(int n) {
		        while (!isPalindrome(n)) {
		        	n++;
		            }
		        return n;
		        }
		    public static boolean isPalindrome(int n) {
		        int original = n;
		        int reversed = 0;
		        while (n != 0) {
		            reversed = reversed * 10 + n % 10;
		            n /= 10;
		        }
		        return original == reversed;
		    }
		    
		}

