package com.handson;

import java.util.Scanner;

public class BinaryString {
	public static void main(String [] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter a size:");
		int size = input.nextInt();
		char arr[] = new char[size];
		System.out.println("Enter a characters:");
		for(int i = 0 ; i < size ; i++) {
			
			arr[i]=input.next().charAt(0);
		}
		int c = 0;
		for(int i = 0 ; i < size ; i++) {
			
			if(arr[i] == '1') {
				c++;
			}
		}
		int subStrings = (c*(c-1))/2;
		System.out.println(subStrings);
		input.close();
		
	}
}
