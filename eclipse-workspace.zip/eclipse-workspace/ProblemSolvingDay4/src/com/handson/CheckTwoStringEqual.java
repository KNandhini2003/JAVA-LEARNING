package com.handson;

import java.util.Scanner;

public class CheckTwoStringEqual {
	static void display(String str1[] ,String str2[]) {
		String temp1="";
		String temp2="";
	
		for(int i = 0 ; i < str1.length ; i++) {
			
			for(int j = 0 ; j < str1[i].length(); j++) {
				temp1 =temp1 + str1[i].charAt(j);
				
			}
			for(int j = 0 ; j < str2[i].length(); j++) {
				temp2 =temp2 + str2[i].charAt(j);
				
			}
		}
		if(temp1.equals(temp2)) {
			System.out.println(true);
		}
		else {
			System.out.println(false);
		}
	}
		
	
	public static void main(String [] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter a size");
		int size = input.nextInt();
		System.out.println("Enter a String elements"
				+ " in array 1:");
		String str1[]= new String[size];
		for(int i = 0 ; i < size ; i++) {
			
				str1[i] = input.next();
				
		}
		System.out.println("Enter a String elements"
				+ " in array 2:");
		String str2[]= new String[size];
		for(int i = 0 ; i < size ; i++) {
			
			str2[i] = input.next();
			
		}
		display(str1,str2);
		input.close();
	}
}
