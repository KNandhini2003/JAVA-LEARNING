package com.handson;

import java.util.Scanner;

public class DefangingIPAddress {
	public static void main(String [] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter a IP address:");
		String ip = input.next();
		String replace =ip.replace(".", "[.]");
		System.out.println("\""+replace+"\"");
		input.close();
	}
}
