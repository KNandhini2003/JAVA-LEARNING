package com.handson;
import java.util.*;
public class CountAndSay {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
//        
//        System.out.println("Enter a String:");
        String current = "1";
        System.out.println("Enter a number:");
        int n = input.nextInt();
        for(int k = 1; k < n;k++) {
        	String next = "";
        	int i = 0;
        	while(i < current.length())
        	{
        		int c = 1;
        		while(i < current.length()-1 && 
        		current.charAt(i) == current.charAt(i+1)){
        			c++;
        			i++;
        		}
        		next +=Integer.toString(c)+current.charAt(i);
        		i++;
        	}
        	current = next;
        }
        System.out.println(current);
        input.close();
    }
}
