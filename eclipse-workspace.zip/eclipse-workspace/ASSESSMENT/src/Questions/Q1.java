package Questions;

public class Q1 {

}
