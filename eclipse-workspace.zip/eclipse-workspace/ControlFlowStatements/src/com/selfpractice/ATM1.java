package com.selfpractice;

import java.util.*;

public class ATM1 {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);

		System.out.println("Enter a Amount:");
		int amount=input.nextInt();
		
		if(amount%500==0 &&amount>0) {

					System.out.println("please dispatch "+amount/100+ 
							" notes of 100");
					//System.out.println(amount/100);
				
		}
		
		
		else {
			System.out.println("Please enter amount"
					+ " multiple of 500");
		}
		input.close();

	}
}
