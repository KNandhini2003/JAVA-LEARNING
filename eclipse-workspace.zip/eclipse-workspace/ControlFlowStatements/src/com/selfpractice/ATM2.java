package com.selfpractice;
import java.util.*;
public class ATM2 {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a amont in ATM:");
		int amount=input.nextInt();
		if(amount%500==0) {
			if(amount==500) {
				System.out.println(amount/100+" notes of 100.");
			}
			else if(amount>500&&amount<=2000) {
				int five=amount-500;
				System.out.println(500/100+" notes of 100.");
				System.out.println(five/500+" notes of 500");
			}
			else if(amount>2000) {
				System.out.println(500/100+" notes of 100.");
				
				System.out.println(amount/2000+
						"notes of 2000");
				System.out.println(((amount%2000)-500)/500
						+" notes of 500.");
			}
		}
		input.close();
	}
		
}
