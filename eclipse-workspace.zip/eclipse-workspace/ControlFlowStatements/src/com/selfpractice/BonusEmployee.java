package com.selfpractice;
import java.util.*;
public class BonusEmployee {
		public static void main(String[]args) {
			Scanner input=new Scanner(System.in);
			System.out.println("Enter a Employee Salary:");
			double salary=input.nextDouble();
			System.out.println("Enter a Employee year of service:");
			double services=input.nextDouble();
			if(services > 5) {
			double netBonus=salary*0.05;
			System.out.printf("Bonus Amount:%.2f",netBonus);
			}
			input.close();
			
		}
		
}
