package com.selfpractice;

import java.util.Scanner;

public class ReverseStarPattern {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.print("Enter a range for "
				+ "star pattern:");
		int number=input.nextInt();
		for(int i=number;i>=1;i--) {
			for(int j=1;j<=i;j++) {
				System.out.print("* ");
			}
			System.out.println();
		}
		input.close();
	}
}
