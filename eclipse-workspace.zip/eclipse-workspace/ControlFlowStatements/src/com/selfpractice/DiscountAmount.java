package com.selfpractice;

import java.util.Scanner;

public class DiscountAmount {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.print("Enter a shopping amount: ");
		int amount=input.nextInt();
		int discount;
		if(amount>=5000) {
			discount=(int)(amount*0.25);
			System.out.println("final amount:"+(amount-discount));
		}
		else if(amount>=1000 && amount<=4999) {
			discount=(int)(amount*0.10);
			System.out.println("final amount:"+(amount-discount));
		}
		else {
			discount=(int)(amount*0.05);
			System.out.println("final amount:"+(amount-discount));
		}
		input.close();
	}

}
