package com.selfpractice;

public class Array {
	    public static void main(String[] args) {
	        // Creating a jagged array
	        int[][] jaggedArray = new int[3][];
	        
	        // Initializing rows with different lengths
//	               // Row 0 has 3 elements
	        jaggedArray[1] = new int[]{4, 5, 6, 7};     // Row 1 has 4 elements
	        jaggedArray[2] = new int[]{8, 9};           // Row 2 has 2 elements
	        
	        // Accessing elements of the jagged array
	        for (int i = 0; i < jaggedArray.length; i++) {
	            for (int j = 0; j < jaggedArray[i].length; j++) {
	                System.out.print(jaggedArray[i][j] + " ");
	            }
	            System.out.println();
	        }
	    }
	}

