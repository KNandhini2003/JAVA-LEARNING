package com.selfpractice;
import java.util.Scanner;
public class DateOfBirth {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your date of birth (DD MM YYYY): ");
        int day = scanner.nextInt();
        int month = scanner.nextInt();
        int year = scanner.nextInt();
        
        int currentDay = 5;
        int currentMonth = 5;
        int currentYear = 2024;
        int ageYears = currentYear - year;
        int ageMonths = currentMonth - month;
        int ageDays = currentDay - day;
 
        if (ageMonths < 0) {
            ageYears--;
            ageMonths += 12;
        }
        if (ageDays < 0) {
            ageMonths--;
            ageDays += 30;
        }      
        System.out.printf("%d years %d months %d days%n", ageYears, ageMonths, ageDays);
        
        scanner.close();
    }
}
