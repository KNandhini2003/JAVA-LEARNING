package com.selfpractice;

import java.util.*;

public class ArmstrongNumber {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.print("Enter a number: ");
		int number=input.nextInt();
		int temporyNumber=number;
		int splitNumber=0,armstrong=0;
		while(number!=0) {
			splitNumber=number%10;
			armstrong+=Math.pow(splitNumber, 3);
			number/=10;
		}
		if(armstrong == temporyNumber) {
			System.out.println(true);
		}
		else {
			System.out.println(false);
		}
		input.close();
		
	}
		
}
