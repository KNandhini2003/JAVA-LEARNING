package com.selfpractice;
import java.util.*;
public class TaxAmount1 {
		public static void main(String[]args) {
			Scanner input=new Scanner(System.in);
			System.out.println("Enter a annual income");
			int amount=input.nextInt();
			int tax;
			if(amount<=250000) {
				System.out.print("You are exempted from tax");
			}
			else if(amount>250000 && amount<=500000) {
				
				tax=(int)((amount-250000)*0.1);
				System.out.print(tax);
			}
			else if(amount>500000 && amount<=1200000) {
				int amountnew=amount-500000;
				tax=(int)(amountnew*0.2)+(int)((500000-250000)*0.1);
			
				System.out.print(tax);
			}
			else if(amount>1200000) {
				int amountnew1=amount-1200000;
				int amount20=1200000-500000;
				tax=(int)(amountnew1*0.3)+(int)(amount20*0.2)+(int)((500000-250000)*0.1);
				System.out.print(tax);
			}
			
			
			input.close();
		}
}
/*
Income between 2.5 to 5 lacs (250000 to 500000):
For this range, the tax rate is 10%.
The taxable amount in this range is 500,000 - 250,000 = 250,000.
So, the tax amount for this range is 250,000 * 0.10 = 25,000.
Income between 5 to 12 lacs (500000 to 1200000):
For this range, the tax rate is 20%.
The taxable amount in this range is 800,000 - 500,000 = 300,000.
But, the tax on the first 500,000 (up to 5 lacs) is already calculated at 10%.
So, the additional tax for this range is (300,000 * 0.20) = 60,000.
However, we also need to add the tax amount for the income range between 2.5 to 5 lacs, which is 25,000.
Therefore, the total tax amount for this range is 60,000 + 25,000 = 85,000.
Income above 12 lacs (1200000 and above):
Since the income (800,000) is not in this range, this condition does not apply.
So, for an income of 800,000, the total tax amount is 85,000, as calculated above. 

*/