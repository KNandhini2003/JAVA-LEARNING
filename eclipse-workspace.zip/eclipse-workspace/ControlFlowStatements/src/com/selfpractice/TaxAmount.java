package com.selfpractice;

import java.util.Scanner;

public class TaxAmount {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.print("Enter a income of "
				+ "person annually ");
		double income=input.nextDouble();
		if(income<=250000) {
			System.out.println("You are exempted from tax");
		}
		else {
			int tax=(int)((income-250000)*0.1);
			System.out.printf("Tax amount is %d",tax);
		}
		input.close();
	}
			
}
