package com.selfpractice;
import java.util.*;
public class ArrayFrequency {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
    int[] digitFrequency = new int[10];
    System.out.println("Enter an number:");
    int number=input.nextInt();
    while (number != 0) {
        int digit = number % 10;
        digitFrequency[digit]++;
        number /= 10;
    }
    for (int i = 0; i < digitFrequency.length; i++) {
        if (digitFrequency[i] != 0) {
            System.out.println(i + " occurs " + digitFrequency[i] + " times");
        }
    }
    input.close();
}
}
