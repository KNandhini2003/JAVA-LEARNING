package com.selfpractice;
import java.util.*;
public class GroupSelection {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a number:");
		int number=input.nextInt();
		if(number%10==0) {
			System.out.println("Group Leader.");
		}
		else {
			System.out.println("Group Member.");
		}
		input.close();
	}
	
}
