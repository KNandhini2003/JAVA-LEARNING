package com.selfpractice;
import java.util.*;
public class GradeDescription {
		public static void main(String[]args) {
			Scanner input=new Scanner(System.in);
			System.out.println("Enter a number:");
			int number=input.nextInt();
			switch(number) {
			case 9:
			case 10:
				System.out.print("Excellent");
				break;
			case 7:
			case 8:
				System.out.print("Notable");
				break;
			case 6:
				System.out.print("Good");
				break;
			case 5:
				System.out.print("Approved");
				break;
			case 0:
			case 1:
			case 2:
			case 3:
				System.out.print("Fail");
				break;
			default:
				System.out.print("Invalid");
				break;
			
			}
			input.close();
		}
}
