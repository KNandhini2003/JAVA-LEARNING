package com.selfpractice;
import java.util.*;
public class Stock {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter available stock:");
		int avail=input.nextInt();
		
		System.out.println("Enter customer stock:");
		int customer=input.nextInt();
		
		System.out.println("Enter N/y");
		Character condition=input.next().charAt(0);
		if(avail>customer && condition=='N') {
			System.out.println(customer+"supplied");
		}
		else if(avail>customer && condition=='Y') {
			System.out.println(customer+"Not supplied");
		}
		else{
			System.out.println("150 supplied. Out of stock. Balance will be refunded.");
		}
input.close();
	}
}
