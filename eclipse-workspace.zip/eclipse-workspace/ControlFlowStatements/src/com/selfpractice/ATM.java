package com.selfpractice;

import java.util.Scanner;

public class ATM {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a Amount:");
		int amount=input.nextInt();
		if(amount%500==0 &&amount>0) {
			System.out.println("Valid amount, transaction in"
					+ " process");
		}
		else {
			System.out.println("Please enter amount"
					+ " multiple of 500");
		}
		input.close();
	}
}
