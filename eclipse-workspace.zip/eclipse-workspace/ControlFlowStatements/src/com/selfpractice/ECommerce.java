package com.selfpractice;

import java.util.*;

public class ECommerce {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a book name");
		String book=input.nextLine();
		System.out.println("Enter a cost of book");
		int cost=input.nextInt();
		int individualDiscount=(int)(cost*0.1);
		int finalAmount=cost-Math.max(individualDiscount, 500);
		System.out.println("Final amount after discount for "+book+":"+finalAmount);
		input.close();
	}
}
		
