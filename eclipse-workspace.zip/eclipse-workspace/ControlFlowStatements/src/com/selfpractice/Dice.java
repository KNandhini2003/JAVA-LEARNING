package com.selfpractice;
import java.util.*;
public class Dice {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.print("Enter a sides of dice:");
		int side=input.nextInt();
		for(int i=1;i<=side;i++) {
			for(int j=1;j<=side;j++) {
				System.out.print("("+i+","+j+") ");
			}
			System.out.println();
		}
		input.close();
	}

}
