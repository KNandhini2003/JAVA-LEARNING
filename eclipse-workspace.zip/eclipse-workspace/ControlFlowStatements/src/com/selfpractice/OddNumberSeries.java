package com.selfpractice;
import java.util.*;
public class OddNumberSeries {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.print("Enter a number:");
		int number=input.nextInt();
		int total=0;
		for(int i=1;i<=number;i++) {
			if(i%2==1) {
				total+=i;
			}
		}
		System.out.println("Sum of first N odd "
				+ "numbers:"+total);
		input.close();
	}
		
}
