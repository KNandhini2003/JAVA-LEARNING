package com.selfpractice;
import java.util.*;
public class CurrencyQuiz {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);

		System.out.println("What is the unit of currency in India?");
		
		int c=1;
		while(c<=3)
		{
			String unit=input.next();
			if(unit.toLowerCase().equals("rupee")) {
				System.out.print("Answer is correct");
				break;
			}
			else if(c!=3){
			System.out.print("Try Again!\n");
			}
			else if(c==3) {
				System.out.print("Sorry.");
			}
			c++;
		}
		if(c>3) {
			System.out.println("Answer:\nRupee is the unit "
					+ "of curreny in India");
		}
		input.close();
	}
		
}
