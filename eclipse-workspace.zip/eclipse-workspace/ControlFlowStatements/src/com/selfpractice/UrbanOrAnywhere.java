package com.selfpractice;
import java.util.*;
public class UrbanOrAnywhere {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a age:");
		int age=input.nextInt();
		System.out.println("Enter a gender:");
		String gender=input.next();
		if(gender.toLowerCase().equals("female")) {
			System.out.println("Work only in urban areas.");
		}
		else if(gender.toLowerCase().equals("male")){
			if(age>=20&&age<40) {
				System.out.println("Work anywhere.");
			}
			else if(age>=40&&age <=60) {
				System.out.println("Work only in urban areas.");
				
			}
			else {
				System.out.println("ERROR");
			}
		}
		else {
			System.out.println("Enter valid gender.");
		}
		input.close();
	}
}
				
		
		
		
	
