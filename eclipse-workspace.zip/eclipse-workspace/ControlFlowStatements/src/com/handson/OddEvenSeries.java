package com.handson;
import java.util.*;
public class OddEvenSeries {
	public static void main(String[]args) {
		System.out.println("Enter a number:\n");
		Scanner input=new Scanner(System.in);
		int number =input.nextInt();
		if(number%2==0) {
			System.out.println("Enter a even number series:\n");
			for(int i=1;i<=number;i++) {
				if(i%2==0) {
					System.out.print(i+" ");
				}
			}
		}
		else {
			System.out.println("Enter a odd number series:\n");
			for(int i=1;i<=number;i++) {
				if(i%2!=0) {
					System.out.print(i+" ");
				}
			}
		}
		input.close();
	}
}
		
