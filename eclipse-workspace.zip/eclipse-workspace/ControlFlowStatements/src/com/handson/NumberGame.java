package com.handson;
import java.util.*;
public class NumberGame {
		public static void main(String[]args) {
			System.out.println("Enter a number series:\n");
			Scanner input=new Scanner(System.in);
			int number,sum=0;
			while(true) {
				number=input.nextInt();
				sum+=number;
				if(number==0) {
					break;
				}
			}
			System.out.println(sum);
			input.close();
			
		}
}
