package com.handson;
import java.util.*;
public class GiantAntKittu {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a starrting room of Gaint Ant:");
		int start=input.nextInt();
		System.out.println("Number of rooms jumped:\n");
		int room=start;
		while(room<=100) {
			System.out.print(room+" ");
			room+=10;
		}
		input.close();
	}
}
