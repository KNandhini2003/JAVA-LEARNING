package com.handson;
import java.util.*;

public class BirthRight {
	public static void main(String[]args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter a Choi Sung age:");
		int first_son=scanner.nextInt();
		System.out.println("Enter a Moui Sung age:");
		int second_son=scanner.nextInt();
		System.out.println("Enter a Bhoi Sung age:");
		int third_son=scanner.nextInt();
		if(first_son>second_son && first_son>third_son) {
			System.out.println("Choi Sung");
		}
		else if(second_son>first_son&&second_son>third_son) {
			System.out.println("Moui Sung");
		}
		else {
			System.out.println("Bhoi Sung");
		}
		scanner.close();
	}
	
}
