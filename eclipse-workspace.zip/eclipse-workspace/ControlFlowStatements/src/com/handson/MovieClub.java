package com.handson;

import java.util.Scanner;

public class MovieClub {
	public static void main(String []args) {
	System.out.println("Enter a age:\n");
	Scanner input=new Scanner(System.in);
	int age =input.nextInt();
	if(age<=10&&age>0) {
		System.out.println("Cartoon Club.");
	}
	else if(age>10&&age<=20) {
		System.out.println("Teens Club.");
	}
	else if(age>20) {
		System.out.println("Not Allowed");
	}
	else {
		System.out.println("Invalid age.");
	}
	input.close();
	}

}
