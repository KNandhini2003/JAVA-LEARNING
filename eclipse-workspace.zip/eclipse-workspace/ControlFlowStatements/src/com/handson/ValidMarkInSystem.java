package com.handson;
import java.util.*;
public class ValidMarkInSystem {
		public static void main(String[]args) {
			Scanner input=new Scanner(System.in);
			System.out.println("Enter a Mark:");
			int mark=input.nextInt();
			if(mark>0&&mark<=100) {
				System.out.println("Valid Entry.");
			}
			else if(mark<0||mark>100) {
				System.out.println("Invalid Entry.");
			}
			
			input.close();
		}
}
