package com.handson;

import java.util.Scanner;

public class CheckPrime {
	public static void main(String[]args) {
	System.out.print("Enter a number:");
	Scanner input=new Scanner(System.in);
	int number=input.nextInt();
	int count=0;
	for(int i=1;i<=number;i++) {
		if(number%i==0) {
			count++;
		}
	}
	if(count==2) {
		System.out.print("Prime Number.");
	}
	else {
		System.out.print("Not a Prime Number.");
		
	}
	input.close();
	}
}
