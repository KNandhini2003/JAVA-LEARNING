package com.handson;
import java.util.*;
public class Prime {
	public static void main(String[]args) {
		System.out.print("Enter a number:");
		Scanner input=new Scanner(System.in);
		int number=input.nextInt();
		int count=0;
		for(int i=1;i<=number;i++) {
			
			for(int j=1;j<=i;j++) {
				if(i%j==0) {
					count++;
				}
				
			}
			
			if(count==2) {
				System.out.print(i+" ");
			}
			count=0;
			
		}
		input.close();
	}
		
}
