package com.handson;

import java.util.Scanner;

public class CodeGame {
	
		public static void main(String[]args) {
		System.out.print("Enter a number:");
		Scanner input=new Scanner(System.in);
		int number=input.nextInt();
		if(number==1) {
			System.out.println("Enter a double number1:");
			double a=input.nextDouble();
			System.out.println("Enter a double number2:");
			double b=input.nextDouble();
			System.out.print(a+b);
		}
		else if(number==2) {
			System.out.println("Enter a  number1:");
			int a=input.nextInt();
			System.out.println("Enter a  number2:");
			int b=input.nextInt();
			System.out.print(a*b);
		}
		else if(number==3) {
			System.out.println("Enter a  string1:");
			String a=input.next();
			System.out.println("Enter a  string2:");
			String b=input.next();
			System.out.print(a+b);
		}
		input.close();
		}
}
