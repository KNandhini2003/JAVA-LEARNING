package com.handson;

import java.util.Scanner;

public class TotalOddEven {
	public static void main(String[]args) {
	System.out.print("Enter a number:");
	Scanner input=new Scanner(System.in);
	int number=input.nextInt();
	int even=0,odd=0;
	for(int i=1;i<=number;i++) {
		if(i%2==0) {
			even+=i;
		}
		else {
			odd+=i;
		}
	}
	System.out.println(odd+" "+even);
	input.close();
	}
}
