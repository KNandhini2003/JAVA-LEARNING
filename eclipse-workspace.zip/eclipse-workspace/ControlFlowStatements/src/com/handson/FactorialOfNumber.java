package com.handson;
import java.util.*;
public class FactorialOfNumber {
	public static void main(String []args) {
	System.out.println("Enter a number:\n");
	Scanner input=new Scanner(System.in);
	int number =input.nextInt();
	int factorial=1;
	for(int i=1 ;i<=number;i++) {
		factorial*=i;
	}
	System.out.println("Factorial of number:"+factorial);
	input.close();
	
	}
}
