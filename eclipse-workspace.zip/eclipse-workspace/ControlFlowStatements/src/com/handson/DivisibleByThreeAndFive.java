package com.handson;
import java.util.*;
public class DivisibleByThreeAndFive {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a number:");
		int number=input.nextInt();
		System.out.println("NumberSeries divided by 3 and 5:\n");
		for(int i=1;i<=number;i++) {
			if(i%3==0 ||i%5==0)
			{
				System.out.print(i+" ");
			}
		}
		input.close();
	}
}
	
