//Take values of length and breadth of a rectangle from user and check if it is square or not.
//Sample Input: 5, 3
//Sample Output: Not a Square
//Sample Input: 7, 7
//Sample Output: Square
package com.handson;
import java.util.*;
public class CheckSquare {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a length of a rectangle:");
		int length=input.nextInt();
		System.out.println("Enter a breadth of a rectangle:");
		int breadth=input.nextInt();
		if(length==breadth) {
			System.out.println("It is square");
		}
		else {
			System.out.println("It is not a square");
		}
		input.close();
	}

}
