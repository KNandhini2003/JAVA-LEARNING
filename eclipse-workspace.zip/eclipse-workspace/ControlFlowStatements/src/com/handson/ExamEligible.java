package com.handson;
import java.util.*;
public class ExamEligible {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.print("Enter total class held:");
		double held=input.nextDouble();
		System.out.print("Enter total class attended:");
		double attend=input.nextDouble();
		double eligible=attend/held*100;
		if(eligible>=75) {
			System.out.println(eligible+"% Allowed");
		}
		else {
			System.out.print("Any health issue(N/Y):");
			Character issue=input.next().charAt(0); 
			if(issue=='N')
				System.out.print(eligible+"% not allowed");
			else
				System.out.print(eligible+"% allowed");
			
		}
		input.close();
		
	}
}
