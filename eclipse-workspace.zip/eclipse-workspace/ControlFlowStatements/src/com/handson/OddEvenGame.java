package com.handson;

import java.util.Scanner;

public class OddEvenGame {
	public static void main(String []args) {
	System.out.print("Enter a number:\n");
	Scanner input=new Scanner(System.in);
	int number =input.nextInt();
	if(number%2==0) {
		System.out.print(number/2);
	}
	else {
		System.out.print((number*3)+1);
	}
	input.close();
	}
}
