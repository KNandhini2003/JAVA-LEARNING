package com.handson;
import java.util.*;
public class BabyLion {
    public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
	System.out.println("Enter the total number of animals:");
    int totalAnimals=input.nextInt();
    System.out.println("Enter the count of rabbits:");
    int rabbits=input.nextInt();
    System.out.println("Enter the count of deer:");
    int deer=input.nextInt();
    System.out.println("Enter the count of birds:");
    int birds=input.nextInt();
    System.out.println("Enter the count of squirrels:");
    int squirrels=input.nextInt();
    if (totalAnimals ==rabbits+deer+birds+squirrels) {
    	System.out.println("Baby lion is well behaved");
    }
    else if(totalAnimals >rabbits+deer+birds+squirrels) {
      	System.out.println("Baby lion is well behaved");
        
    }
    else {
      	System.out.println("Counted Wrongly");
        
    }
    input.close();
    }
}