package com.handson;

import java.util.Scanner;

public class StoreCost {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.print("Enter a user name:");
		String name=input.nextLine();
		System.out.print("Enter a items buyed:");
//		Scanner input=new Scanner(System.in);
		int item=input.nextInt();
		if(item<10) {
			System.out.print(name+","+item*12);
			
		}
		else if(item>=10&&item<100) {
			System.out.print(name+","+item*10);
			
		}
		else {
			System.out.print(name+","+item*7);
		}
	
		input.close();
	}
}
