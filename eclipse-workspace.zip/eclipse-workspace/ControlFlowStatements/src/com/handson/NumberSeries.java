package com.handson;
import java.util.*;

public class NumberSeries {
	
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a number:");
		int number=input.nextInt();
		System.out.println("Number Series except number "+number);
		if(number<=20) {
			for(int i=1 ;i<=20 ; i++) {
				if(i==number) {
					continue;
				}
				System.out.print(i+" ");
			}
		}
		else {
			System.out.println("Invalid Input.");
		}
		input.close();
		
	}
	
}
