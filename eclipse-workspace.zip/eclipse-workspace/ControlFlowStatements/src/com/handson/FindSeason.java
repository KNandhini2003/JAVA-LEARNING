package com.handson;

import java.util.Scanner;

public class FindSeason {
	public static void main(String []args) {
	System.out.print("Enter a month number:\n");
	Scanner input=new Scanner(System.in);
	int month =input.nextInt();
	switch(month) {
	case 3:
	case 4:
	case 5:
		System.out.println("Spring.");
		break;
	case 6:
	case 7:
	case 8:
		System.out.println("Summer.");
		break;
	case 9:
	case 10:
	case 11:
		System.out.println("Autumn.");
		break;
	case 12:
	case 1:
	case 2:
		System.out.println("Winter.");
		break;	
	default:
		System.out.println("Invalid month.");
		
	input.close();
	}
	}
}
