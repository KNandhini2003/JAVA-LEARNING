
package com.handson;
import java.util.*;
public class IncreaseDecrease {
		public static void main(String[]args) {
			Scanner input=new Scanner(System.in);
			System.out.println("Enter a number1:");
			int number1=input.nextInt();
			System.out.println("Enter a number2:");
			int number2=input.nextInt();
			System.out.println("Enter a number3:");
			int number3=input.nextInt();
			if(number1<number2 && number2<number3 && number1<number3 ) {
				System.out.println("Increasing");
			}
			else if(number1>number2 && number2>number3 && number1>number3 ) {
				System.out.println("Decreasing");
			}
			else {
				System.out.println("Neither Increasing nor decreasing order");
			}
			input.close();
		}
}
