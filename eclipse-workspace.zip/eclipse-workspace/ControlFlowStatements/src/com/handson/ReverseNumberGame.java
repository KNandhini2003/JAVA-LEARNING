package com.handson;

import java.util.Scanner;

public class ReverseNumberGame {
	public static void main(String[]args) {
	System.out.print("Enter a number:");
	Scanner input=new Scanner(System.in);
	int number=input.nextInt();
	int count=0,number1=number,reverse=0,sum=0;

	while(number1!=0) {
		
		number1/=10;
		count++;
	}
	
	if(count==5) {
		while(number>0) {
			reverse=number%10;
			sum=sum*10+reverse;
			number/=10;
		}
		System.out.println(sum);
	}
	else {
		System.out.println("Not a valid number’");
	}
	input.close();
	}
}
