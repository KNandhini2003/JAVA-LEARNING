package com.handson;
import java.util.*;
public class PlayingNumberGrade {
		public static void main(String[]args) {
			Scanner input=new Scanner(System.in);
			System.out.println("Enter a number to play with Smith :");
			int number=input.nextInt();
			int total=0;
			System.out.println("John says natural number:");
			for(int i=number;i>=1;i--) {
				System.out.print(i+" ");
				total+=i;
			}
			System.out.println("Shia says sum of those number:"+total);
			input.close();
		}
}
