	package com.handson;
	
	import java.util.Scanner;
	
	public class Quadrant {
			public static void main(String[]args) {
			System.out.print("Enter a Xaxis:");
			Scanner input=new Scanner(System.in);
			int x=input.nextInt();
			System.out.print("Enter a Yaxis:");
			int y=input.nextInt();
			
			if (x > 0 && y > 0) {
	            System.out.println(1);
	        } else if (x < 0 && y > 0) {
	        	System.out.println(2);
	        } else if (x < 0 && y < 0) {
	        	System.out.println(3);
	        } else if (x > 0 && y < 0) {
	        	System.out.println(4);
	        }
			input.close();
			}
			
	}
