package com.handson;
import java.util.*;
public class KinderGarden {
	public static void main(String[]args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter a age of kid:");
		int age=input.nextInt();
		if(age>=4) {
			System.out.println("The kid is eligible for KinderGarden.");
		}
		else {
			System.out.println("The kid is not eligible for KinderGarden.");
		}
		input.close();
}
}
