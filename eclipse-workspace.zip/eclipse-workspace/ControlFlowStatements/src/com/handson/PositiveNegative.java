package com.handson;
import java.util.*;
public class PositiveNegative {
		public static void main(String[]args) {
			Scanner input=new Scanner(System.in);
			System.out.println("Enter a number:");
			int number=input.nextInt();
			if(number==0) {
				System.out.println("Zero");
			}
			else if(number>0) {
				System.out.println("Positive Number");
			}
			else if(number<0) {
				System.out.println("Negative Number");
			}
			input.close();
		}
}
